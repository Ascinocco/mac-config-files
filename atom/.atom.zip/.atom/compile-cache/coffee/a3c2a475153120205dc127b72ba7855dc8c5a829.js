(function() {
  var config, plugins, proxy;

  proxy = require("../services/php-proxy.coffee");

  config = require("../config.coffee");

  plugins = require("../services/plugin-manager.coffee");

  module.exports = {
    structureStartRegex: /(?:abstract class|class|trait|interface)\s+(\w+)/,
    useStatementRegex: /(?:use)(?:[^\w\\])([\w\\]+)(?![\w\\])(?:(?:[ ]+as[ ]+)(\w+))?(?:;)/,
    cache: [],
    isFunction: false,

    /**
     * Retrieves the class the specified term (method or property) is being invoked on.
     *
     * @param  {TextEditor} editor         TextEditor to search for namespace of term.
     * @param  {string}     term           Term to search for.
     * @param  {Point}      bufferPosition The cursor location the term is at.
     *
     * @return {string}
     *
     * @example Invoking it on MyMethod::foo()->bar() will ask what class 'bar' is invoked on, which will whatever type
     *          foo returns.
     */
    getCalledClass: function(editor, term, bufferPosition) {
      var fullCall;
      fullCall = this.getStackClasses(editor, bufferPosition);
      if ((fullCall != null ? fullCall.length : void 0) === 0 || !term) {
        return;
      }
      return this.parseElements(editor, bufferPosition, fullCall);
    },

    /**
     * Get all variables declared in the current function
     * @param {TextEdutir} editor         Atom text editor
     * @param {Range}      bufferPosition Position of the current buffer
     */
    getAllVariablesInFunction: function(editor, bufferPosition) {
      var isInFunction, matches, regex, startPosition, text;
      isInFunction = this.isInFunction(editor, bufferPosition);
      startPosition = null;
      if (isInFunction) {
        startPosition = this.cache['functionPosition'];
      } else {
        startPosition = [0, 0];
      }
      text = editor.getTextInBufferRange([startPosition, [bufferPosition.row, bufferPosition.column - 1]]);
      regex = /(\$[a-zA-Z_]+)/g;
      matches = text.match(regex);
      if (matches == null) {
        return [];
      }
      if (isInFunction) {
        matches.push("$this");
      }
      return matches;
    },

    /**
     * Retrieves the full class name. If the class name is a FQCN (Fully Qualified Class Name), it already is a full
     * name and it is returned as is. Otherwise, the current namespace and use statements are scanned.
     *
     * @param {TextEditor}  editor    Text editor instance.
     * @param {string|null} className Name of the class to retrieve the full name of. If null, the current class will
     *                                be returned (if any).
     * @param {boolean}     noCurrent Do not use the current class if className is empty
     *
     * @return string
     */
    getFullClassName: function(editor, className, noCurrent) {
      var classNameParts, definitionPattern, found, fullClass, i, importNameParts, isAliasedImport, j, len, line, lines, matches, methodsRequest, namespacePattern, text, usePattern;
      if (className == null) {
        className = null;
      }
      if (noCurrent == null) {
        noCurrent = false;
      }
      if (className === null) {
        className = '';
        if (noCurrent) {
          return null;
        }
      }
      if (className && className[0] === "\\") {
        return className.substr(1);
      }
      usePattern = /(?:use)(?:[^\w\\\\])([\w\\\\]+)(?![\w\\\\])(?:(?:[ ]+as[ ]+)(\w+))?(?:;)/;
      namespacePattern = /(?:namespace)(?:[^\w\\\\])([\w\\\\]+)(?![\w\\\\])(?:;)/;
      definitionPattern = /(?:abstract class|class|trait|interface)\s+(\w+)/;
      text = editor.getText();
      lines = text.split('\n');
      fullClass = className;
      found = false;
      for (i = j = 0, len = lines.length; j < len; i = ++j) {
        line = lines[i];
        matches = line.match(namespacePattern);
        if (matches) {
          fullClass = matches[1] + '\\' + className;
        } else if (className) {
          matches = line.match(usePattern);
          if (matches) {
            classNameParts = className.split('\\');
            importNameParts = matches[1].split('\\');
            isAliasedImport = matches[2] ? true : false;
            if (className === matches[1]) {
              fullClass = className;
              break;
            } else if ((isAliasedImport && matches[2] === classNameParts[0]) || (!isAliasedImport && importNameParts[importNameParts.length - 1] === classNameParts[0])) {
              found = true;
              fullClass = matches[1];
              classNameParts = classNameParts.slice(1, +classNameParts.length + 1 || 9e9);
              if (classNameParts.length > 0) {
                fullClass += '\\' + classNameParts.join('\\');
              }
              break;
            }
          }
        }
        matches = line.match(definitionPattern);
        if (matches) {
          if (!className) {
            found = true;
            fullClass += matches[1];
          }
          break;
        }
      }
      if (fullClass && fullClass[0] === '\\') {
        fullClass = fullClass.substr(1);
      }
      if (!found) {
        methodsRequest = proxy.methods(fullClass);
        if (!(methodsRequest != null ? methodsRequest.filename : void 0)) {
          fullClass = className;
        }
      }
      return fullClass;
    },

    /**
     * Add the use for the given class if not already added.
     *
     * @param {TextEditor} editor                  Atom text editor.
     * @param {string}     className               Name of the class to add.
     * @param {boolean}    allowAdditionalNewlines Whether to allow adding additional newlines to attempt to group use
     *                                             statements.
     *
     * @return {int}       The amount of lines added (including newlines), so you can reliably and easily offset your
     *                     rows. This could be zero if a use statement was already present.
     */
    addUseClass: function(editor, className, allowAdditionalNewlines) {
      var bestScore, bestUse, doNewLine, i, j, line, lineCount, lineEnding, lineToInsertAt, matches, placeBelow, ref, scopeDescriptor, score, textToInsert;
      if (className.split('\\').length === 1 || className.indexOf('\\') === 0) {
        return null;
      }
      bestUse = 0;
      bestScore = 0;
      placeBelow = true;
      doNewLine = true;
      lineCount = editor.getLineCount();
      for (i = j = 0, ref = lineCount - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
        line = editor.lineTextForBufferRow(i).trim();
        if (line.length === 0) {
          continue;
        }
        scopeDescriptor = editor.scopeDescriptorForBufferPosition([i, line.length]).getScopeChain();
        if (scopeDescriptor.indexOf('.comment') >= 0) {
          continue;
        }
        if (line.match(this.structureStartRegex)) {
          break;
        }
        if (line.indexOf('namespace ') >= 0) {
          bestUse = i;
        }
        matches = this.useStatementRegex.exec(line);
        if ((matches != null) && (matches[1] != null)) {
          if (matches[1] === className) {
            return 0;
          }
          score = this.scoreClassName(className, matches[1]);
          if (score >= bestScore) {
            bestUse = i;
            bestScore = score;
            if (this.doShareCommonNamespacePrefix(className, matches[1])) {
              doNewLine = false;
              placeBelow = className.length >= matches[1].length ? true : false;
            } else {
              doNewLine = true;
              placeBelow = true;
            }
          }
        }
      }
      lineEnding = editor.getBuffer().lineEndingForRow(0);
      if (!allowAdditionalNewlines) {
        doNewLine = false;
      }
      if (!lineEnding) {
        lineEnding = "\n";
      }
      textToInsert = '';
      if (doNewLine && placeBelow) {
        textToInsert += lineEnding;
      }
      textToInsert += ("use " + className + ";") + lineEnding;
      if (doNewLine && !placeBelow) {
        textToInsert += lineEnding;
      }
      lineToInsertAt = bestUse + (placeBelow ? 1 : 0);
      editor.setTextInBufferRange([[lineToInsertAt, 0], [lineToInsertAt, 0]], textToInsert);
      return 1 + (doNewLine ? 1 : 0);
    },

    /**
     * Returns a boolean indicating if the specified class names share a common namespace prefix.
     *
     * @param {string} firstClassName
     * @param {string} secondClassName
     *
     * @return {boolean}
     */
    doShareCommonNamespacePrefix: function(firstClassName, secondClassName) {
      var firstClassNameParts, secondClassNameParts;
      firstClassNameParts = firstClassName.split('\\');
      secondClassNameParts = secondClassName.split('\\');
      firstClassNameParts.pop();
      secondClassNameParts.pop();
      if (firstClassNameParts.join('\\') === secondClassNameParts.join('\\')) {
        return true;
      } else {
        return false;
      }
    },

    /**
     * Scores the first class name against the second, indicating how much they 'match' each other. This can be used
     * to e.g. find an appropriate location to place a class in an existing list of classes.
     *
     * @param {string} firstClassName
     * @param {string} secondClassName
     *
     * @return {float}
     */
    scoreClassName: function(firstClassName, secondClassName) {
      var firstClassNameParts, i, j, maxLength, ref, secondClassNameParts, totalScore;
      firstClassNameParts = firstClassName.split('\\');
      secondClassNameParts = secondClassName.split('\\');
      maxLength = 0;
      if (firstClassNameParts.length > secondClassNameParts.length) {
        maxLength = secondClassNameParts.length;
      } else {
        maxLength = firstClassNameParts.length;
      }
      totalScore = 0;
      for (i = j = 0, ref = maxLength - 2; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
        if (firstClassNameParts[i] === secondClassNameParts[i]) {
          totalScore += 2;
        }
      }
      if (this.doShareCommonNamespacePrefix(firstClassName, secondClassName)) {
        if (firstClassName.length === secondClassName.length) {
          totalScore += 2;
        } else {
          totalScore -= 0.001 * Math.abs(secondClassName.length - firstClassName.length);
        }
      }
      return totalScore;
    },

    /**
     * Checks if the given name is a class or not
     * @param  {string}  name Name to check
     * @return {Boolean}
     */
    isClass: function(name) {
      return name.substr(0, 1).toUpperCase() + name.substr(1) === name;
    },

    /**
     * Checks if the current buffer is in a functon or not
     * @param {TextEditor} editor         Atom text editor
     * @param {Range}      bufferPosition Position of the current buffer
     * @return bool
     */
    isInFunction: function(editor, bufferPosition) {
      var chain, character, closedBlocks, lastChain, line, lineLength, openedBlocks, result, row, rows, text;
      text = editor.getTextInBufferRange([[0, 0], bufferPosition]);
      if (this.cache[text] != null) {
        return this.cache[text];
      }
      this.cache = [];
      row = bufferPosition.row;
      rows = text.split('\n');
      openedBlocks = 0;
      closedBlocks = 0;
      result = false;
      while (row !== -1) {
        line = rows[row];
        if (!line) {
          row--;
          continue;
        }
        character = 0;
        lineLength = line.length;
        lastChain = null;
        while (character <= line.length) {
          chain = editor.scopeDescriptorForBufferPosition([row, character]).getScopeChain();
          if (!(character === line.length && chain === lastChain)) {
            if (chain.indexOf("scope.end") !== -1) {
              closedBlocks++;
            } else if (chain.indexOf("scope.begin") !== -1) {
              openedBlocks++;
            }
          }
          lastChain = chain;
          character++;
        }
        chain = editor.scopeDescriptorForBufferPosition([row, line.length]).getScopeChain();
        if (chain.indexOf("function") !== -1) {
          if (openedBlocks > closedBlocks) {
            result = true;
            this.cache["functionPosition"] = [row, 0];
            break;
          }
        }
        row--;
      }
      this.cache[text] = result;
      return result;
    },

    /**
     * Retrieves the stack of elements in a stack of calls such as "self::xxx->xxxx".
     *
     * @param  {TextEditor} editor
     * @param  {Point}       position
     *
     * @return {Object}
     */
    getStackClasses: function(editor, position) {
      var finished, i, line, lineText, parenthesesClosed, parenthesesOpened, scopeDescriptor, squiggleBracketsClosed, squiggleBracketsOpened, textSlice;
      if (position == null) {
        return;
      }
      line = position.row;
      finished = false;
      parenthesesOpened = 0;
      parenthesesClosed = 0;
      squiggleBracketsOpened = 0;
      squiggleBracketsClosed = 0;
      while (line > 0) {
        lineText = editor.lineTextForBufferRow(line);
        if (!lineText) {
          return;
        }
        if (line !== position.row) {
          i = lineText.length - 1;
        } else {
          i = position.column - 1;
        }
        while (i >= 0) {
          if (lineText[i] === '(') {
            ++parenthesesOpened;
            if (parenthesesOpened > parenthesesClosed) {
              ++i;
              finished = true;
              break;
            }
          } else if (lineText[i] === ')') {
            ++parenthesesClosed;
          } else if (lineText[i] === '{') {
            ++squiggleBracketsOpened;
            if (squiggleBracketsOpened > squiggleBracketsClosed) {
              ++i;
              finished = true;
              break;
            }
          } else if (lineText[i] === '}') {
            ++squiggleBracketsClosed;
          } else if (parenthesesOpened === parenthesesClosed && squiggleBracketsOpened === squiggleBracketsClosed) {
            if (lineText[i] === '$') {
              finished = true;
              break;
            } else if (lineText[i] === ';' || lineText[i] === '=') {
              ++i;
              finished = true;
              break;
            } else {
              scopeDescriptor = editor.scopeDescriptorForBufferPosition([line, i]).getScopeChain();
              if (scopeDescriptor.indexOf('.function.construct') > 0) {
                ++i;
                finished = true;
                break;
              }
            }
          }
          --i;
        }
        if (finished) {
          break;
        }
        --line;
      }
      textSlice = editor.getTextInBufferRange([[line, i], position]).trim();
      return this.parseStackClass(textSlice);
    },

    /**
     * Removes content inside parantheses (including nested parantheses).
     * @param {string}  text String to analyze.
     * @param {boolean} keep string inside parenthesis
     * @return String
     */
    stripParanthesesContent: function(text, keepString) {
      var closeCount, content, i, openCount, originalLength, reg, startIndex;
      i = 0;
      openCount = 0;
      closeCount = 0;
      startIndex = -1;
      while (i < text.length) {
        if (text[i] === '(') {
          ++openCount;
          if (openCount === 1) {
            startIndex = i;
          }
        } else if (text[i] === ')') {
          ++closeCount;
          if (closeCount === openCount) {
            originalLength = text.length;
            content = text.substring(startIndex, i + 1);
            reg = /["(][\s]*[\'\"][\s]*([^\"\']+)[\s]*[\"\'][\s]*[")]/g;
            if (openCount === 1 && reg.exec(content)) {
              continue;
            }
            text = text.substr(0, startIndex + 1) + text.substr(i, text.length);
            i -= originalLength - text.length;
            openCount = 0;
            closeCount = 0;
          }
        }
        ++i;
      }
      return text;
    },

    /**
     * Parse stack class elements
     * @param {string} text String of the stack class
     * @return Array
     */
    parseStackClass: function(text) {
      var element, elements, key, regx;
      regx = /\/\/.*\n/g;
      text = text.replace(regx, (function(_this) {
        return function(match) {
          return '';
        };
      })(this));
      regx = /\/\*[^(\*\/)]*\*\//g;
      text = text.replace(regx, (function(_this) {
        return function(match) {
          return '';
        };
      })(this));
      text = this.stripParanthesesContent(text, true);
      if (!text) {
        return [];
      }
      elements = text.split(/(?:\-\>|::)/);
      if (elements.length === 1) {
        this.isFunction = true;
      } else {
        this.isFunction = false;
      }
      for (key in elements) {
        element = elements[key];
        element = element.replace(/^\s+|\s+$/g, "");
        if (element[0] === '{' || element[0] === '[') {
          element = element.substring(1);
        } else if (element.indexOf('return ') === 0) {
          element = element.substring('return '.length);
        }
        elements[key] = element;
      }
      return elements;
    },

    /**
     * Get the type of a variable
     *
     * @param {TextEditor} editor
     * @param {Range}      bufferPosition
     * @param {string}     element        Variable to search
     */
    getVariableType: function(editor, bufferPosition, element) {
      var bestMatch, bestMatchRow, chain, elements, funcName, line, lineNumber, matches, matchesCatch, matchesNew, newPosition, params, regexCatch, regexElement, regexFunction, regexNewInstance, regexVar, regexVarWithVarName, typeHint, value;
      if (element.replace(/[\$][a-zA-Z0-9_]+/g, "").trim().length > 0) {
        return null;
      }
      if (element.trim().length === 0) {
        return null;
      }
      bestMatch = null;
      bestMatchRow = null;
      regexElement = new RegExp("\\" + element + "[\\s]*=[\\s]*([^;]+);", "g");
      regexNewInstance = new RegExp("\\" + element + "[\\s]*=[\\s]*new[\\s]*\\\\?([a-zA-Z][a-zA-Z_\\\\]*)+(?:(.+)?);", "g");
      regexCatch = new RegExp("catch[\\s]*\\([\\s]*([A-Za-z0-9_\\\\]+)[\\s]+\\" + element + "[\\s]*\\)", "g");
      lineNumber = bufferPosition.row - 1;
      while (lineNumber > 0) {
        line = editor.lineTextForBufferRow(lineNumber);
        if (!bestMatch) {
          matchesNew = regexNewInstance.exec(line);
          if (null !== matchesNew) {
            bestMatchRow = lineNumber;
            bestMatch = this.getFullClassName(editor, matchesNew[1]);
          }
        }
        if (!bestMatch) {
          matchesCatch = regexCatch.exec(line);
          if (null !== matchesCatch) {
            bestMatchRow = lineNumber;
            bestMatch = this.getFullClassName(editor, matchesCatch[1]);
          }
        }
        if (!bestMatch) {
          matches = regexElement.exec(line);
          if (null !== matches) {
            value = matches[1];
            elements = this.parseStackClass(value);
            elements.push("");
            newPosition = {
              row: lineNumber,
              column: bufferPosition.column
            };
            bestMatchRow = lineNumber;
            bestMatch = this.parseElements(editor, newPosition, elements);
          }
        }
        if (!bestMatch) {
          regexFunction = new RegExp("function(?:[\\s]+([a-zA-Z]+))?[\\s]*[\\(](?:(?![a-zA-Z\\_\\\\]*[\\s]*\\" + element + ").)*[,\\s]?([a-zA-Z\\_\\\\]*)[\\s]*\\" + element + "[a-zA-Z0-9\\s\\$\\\\,=\\\"\\\'\(\)]*[\\s]*[\\)]", "g");
          matches = regexFunction.exec(line);
          if (null !== matches) {
            typeHint = matches[2];
            if (typeHint.length > 0) {
              return this.getFullClassName(editor, typeHint);
            }
            funcName = matches[1];
            if (funcName && funcName.length > 0) {
              params = proxy.docParams(this.getFullClassName(editor), funcName);
              if ((params.params != null) && (params.params[element] != null)) {
                return this.getFullClassName(editor, params.params[element].type, true);
              }
            }
          }
        }
        chain = editor.scopeDescriptorForBufferPosition([lineNumber, line.length]).getScopeChain();
        if (chain.indexOf("comment") !== -1) {
          if (bestMatchRow && lineNumber === (bestMatchRow - 1)) {
            regexVar = /\@var[\s]+([a-zA-Z_\\]+)(?![\w]+\$)/g;
            matches = regexVar.exec(line);
            if (null !== matches) {
              return this.getFullClassName(editor, matches[1]);
            }
          }
          regexVarWithVarName = new RegExp("\\@var[\\s]+([a-zA-Z_\\\\]+)[\\s]+\\" + element, "g");
          matches = regexVarWithVarName.exec(line);
          if (null !== matches) {
            return this.getFullClassName(editor, matches[1]);
          }
          regexVarWithVarName = new RegExp("\\@var[\\s]+\\" + element + "[\\s]+([a-zA-Z_\\\\]+)", "g");
          matches = regexVarWithVarName.exec(line);
          if (null !== matches) {
            return this.getFullClassName(editor, matches[1]);
          }
        }
        if (chain.indexOf("function") !== -1) {
          break;
        }
        --lineNumber;
      }
      return bestMatch;
    },

    /**
     * Retrieves contextual information about the class member at the specified location in the editor.
     *
     * @param {TextEditor} editor         TextEditor to search for namespace of term.
     * @param {string}     term           Term to search for.
     * @param {Point}      bufferPosition The cursor location the term is at.
     * @param {Object}     calledClass    Information about the called class (optional).
     */
    getMemberContext: function(editor, term, bufferPosition, calledClass) {
      var j, len, methods, ref, val, value;
      if (!calledClass) {
        calledClass = this.getCalledClass(editor, term, bufferPosition);
      }
      if (!calledClass && !this.isFunction) {
        return;
      }
      proxy = require('../services/php-proxy.coffee');
      if (this.isFunction) {
        methods = proxy.functions();
      } else {
        methods = proxy.methods(calledClass);
      }
      if (!methods || (methods == null)) {
        return;
      }
      if ((methods.error != null) && methods.error !== '') {
        if (config.config.verboseErrors) {
          atom.notifications.addError('Failed to get methods for ' + calledClass, {
            'detail': methods.error.message
          });
        } else {
          console.log('Failed to get methods for ' + calledClass + ' : ' + methods.error.message);
        }
        return;
      }
      if (!((ref = methods.values) != null ? ref.hasOwnProperty(term) : void 0)) {
        return;
      }
      value = methods.values[term];
      if (value instanceof Array) {
        for (j = 0, len = value.length; j < len; j++) {
          val = value[j];
          if (val.isMethod) {
            value = val;
            break;
          }
        }
      }
      return value;
    },

    /**
     * Parse all elements from the given array to return the last className (if any)
     * @param  Array elements Elements to parse
     * @return string|null full class name of the last element
     */
    parseElements: function(editor, bufferPosition, elements) {
      var className, element, found, j, k, len, len1, loop_index, methods, plugin, ref;
      loop_index = 0;
      className = null;
      if (elements == null) {
        return;
      }
      for (j = 0, len = elements.length; j < len; j++) {
        element = elements[j];
        if (loop_index === 0) {
          if (element[0] === '$') {
            className = this.getVariableType(editor, bufferPosition, element);
            if (element === '$this' && !className) {
              className = this.getFullClassName(editor);
            }
            loop_index++;
            continue;
          } else if (element === 'static' || element === 'self') {
            className = this.getFullClassName(editor);
            loop_index++;
            continue;
          } else if (element === 'parent') {
            className = this.getParentClass(editor);
            loop_index++;
            continue;
          } else {
            className = this.getFullClassName(editor, element);
            loop_index++;
            continue;
          }
        }
        if (loop_index >= elements.length - 1) {
          break;
        }
        if (className === null) {
          break;
        }
        found = null;
        ref = plugins.plugins;
        for (k = 0, len1 = ref.length; k < len1; k++) {
          plugin = ref[k];
          if (plugin.autocomplete == null) {
            continue;
          }
          found = plugin.autocomplete(className, element);
          if (found) {
            break;
          }
        }
        if (found) {
          className = found;
        } else {
          methods = proxy.autocomplete(className, element);
          if ((methods["class"] == null) || !this.isClass(methods["class"])) {
            className = null;
            break;
          }
          className = methods["class"];
        }
        loop_index++;
      }
      if (elements.length > 0 && (elements[elements.length - 1].length === 0 || elements[elements.length - 1].match(/([a-zA-Z0-9]$)/g))) {
        return className;
      }
      return null;
    },

    /**
     * Gets the full words from the buffer position given.
     * E.g. Getting a class with its namespace.
     * @param  {TextEditor}     editor   TextEditor to search.
     * @param  {BufferPosition} position BufferPosition to start searching from.
     * @return {string}  Returns a string of the class.
     */
    getFullWordFromBufferPosition: function(editor, position) {
      var backwardRegex, currentText, endBufferPosition, forwardRegex, foundEnd, foundStart, index, previousText, range, startBufferPosition;
      foundStart = false;
      foundEnd = false;
      startBufferPosition = [];
      endBufferPosition = [];
      forwardRegex = /-|(?:\()[\w\[\$\(\\]|\s|\)|;|'|,|"|\|/;
      backwardRegex = /\(|\s|\)|;|'|,|"|\|/;
      index = -1;
      previousText = '';
      while (true) {
        index++;
        startBufferPosition = [position.row, position.column - index - 1];
        range = [[position.row, position.column], [startBufferPosition[0], startBufferPosition[1]]];
        currentText = editor.getTextInBufferRange(range);
        if (backwardRegex.test(editor.getTextInBufferRange(range)) || startBufferPosition[1] === -1 || currentText === previousText) {
          foundStart = true;
        }
        previousText = editor.getTextInBufferRange(range);
        if (foundStart) {
          break;
        }
      }
      index = -1;
      while (true) {
        index++;
        endBufferPosition = [position.row, position.column + index + 1];
        range = [[position.row, position.column], [endBufferPosition[0], endBufferPosition[1]]];
        currentText = editor.getTextInBufferRange(range);
        if (forwardRegex.test(currentText) || endBufferPosition[1] === 500 || currentText === previousText) {
          foundEnd = true;
        }
        previousText = editor.getTextInBufferRange(range);
        if (foundEnd) {
          break;
        }
      }
      startBufferPosition[1] += 1;
      endBufferPosition[1] -= 1;
      return editor.getTextInBufferRange([startBufferPosition, endBufferPosition]);
    },

    /**
     * Gets the correct selector when a class or namespace is clicked.
     *
     * @param  {jQuery.Event}  event  A jQuery event.
     *
     * @return {object|null} A selector to be used with jQuery.
     */
    getClassSelectorFromEvent: function(event) {
      var $, selector;
      selector = event.currentTarget;
      $ = require('jquery');
      if ($(selector).hasClass('builtin') || $(selector).children('.builtin').length > 0) {
        return null;
      }
      if ($(selector).parent().hasClass('function argument')) {
        return $(selector).parent().children('.namespace, .class:not(.operator):not(.constant)');
      }
      if ($(selector).prev().hasClass('namespace') && $(selector).hasClass('class')) {
        return $([$(selector).prev()[0], selector]);
      }
      if ($(selector).next().hasClass('class') && $(selector).hasClass('namespace')) {
        return $([selector, $(selector).next()[0]]);
      }
      if ($(selector).prev().hasClass('namespace') || $(selector).next().hasClass('inherited-class')) {
        return $(selector).parent().children('.namespace, .inherited-class');
      }
      return selector;
    },

    /**
     * Gets the parent class of the current class opened in the editor
     * @param  {TextEditor} editor Editor with the class in.
     * @return {string}            The namespace and class of the parent
     */
    getParentClass: function(editor) {
      var extendsIndex, j, len, line, lines, text, words;
      text = editor.getText();
      lines = text.split('\n');
      for (j = 0, len = lines.length; j < len; j++) {
        line = lines[j];
        line = line.trim();
        if (line.indexOf('extends ') !== -1) {
          words = line.split(' ');
          extendsIndex = words.indexOf('extends');
          return this.getFullClassName(editor, words[extendsIndex + 1]);
        }
      }
    },

    /**
     * Finds the buffer position of the word given
     * @param  {TextEditor} editor TextEditor to search
     * @param  {string}     term   The function name to search for
     * @return {mixed}             Either null or the buffer position of the function.
     */
    findBufferPositionOfWord: function(editor, term, regex, line) {
      var j, len, lineText, lines, result, row, text;
      if (line == null) {
        line = null;
      }
      if (line !== null) {
        lineText = editor.lineTextForBufferRow(line);
        result = this.checkLineForWord(lineText, term, regex);
        if (result !== null) {
          return [line, result];
        }
      } else {
        text = editor.getText();
        row = 0;
        lines = text.split('\n');
        for (j = 0, len = lines.length; j < len; j++) {
          line = lines[j];
          result = this.checkLineForWord(line, term, regex);
          if (result !== null) {
            return [row, result];
          }
          row++;
        }
      }
      return null;
    },

    /**
     * Checks the lineText for the term and regex matches
     * @param  {string}   lineText The line of text to check.
     * @param  {string}   term     Term to look for.
     * @param  {regex}    regex    Regex to run on the line to make sure it's valid
     * @return {null|int}          Returns null if nothing was found or an
     *                             int of the column the term is on.
     */
    checkLineForWord: function(lineText, term, regex) {
      var element, j, len, propertyIndex, reducedWords, words;
      if (regex.test(lineText)) {
        words = lineText.split(' ');
        propertyIndex = 0;
        for (j = 0, len = words.length; j < len; j++) {
          element = words[j];
          if (element.indexOf(term) !== -1) {
            break;
          }
          propertyIndex++;
        }
        reducedWords = words.slice(0, propertyIndex).join(' ');
        return reducedWords.length + 1;
      }
      return null;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9zZXJ2aWNlcy9waHAtZmlsZS1wYXJzZXIuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxLQUFBLEdBQVEsT0FBQSxDQUFRLDhCQUFSOztFQUNSLE1BQUEsR0FBUyxPQUFBLENBQVEsa0JBQVI7O0VBQ1QsT0FBQSxHQUFVLE9BQUEsQ0FBUSxtQ0FBUjs7RUFFVixNQUFNLENBQUMsT0FBUCxHQUNJO0lBQUEsbUJBQUEsRUFBcUIsa0RBQXJCO0lBQ0EsaUJBQUEsRUFBbUIsb0VBRG5CO0lBSUEsS0FBQSxFQUFPLEVBSlA7SUFPQSxVQUFBLEVBQVksS0FQWjs7QUFTQTs7Ozs7Ozs7Ozs7O0lBWUEsY0FBQSxFQUFnQixTQUFDLE1BQUQsRUFBUyxJQUFULEVBQWUsY0FBZjtBQUNaLFVBQUE7TUFBQSxRQUFBLEdBQVcsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsTUFBakIsRUFBeUIsY0FBekI7TUFFWCx3QkFBRyxRQUFRLENBQUUsZ0JBQVYsS0FBb0IsQ0FBcEIsSUFBeUIsQ0FBQyxJQUE3QjtBQUNJLGVBREo7O0FBR0EsYUFBTyxJQUFDLENBQUEsYUFBRCxDQUFlLE1BQWYsRUFBdUIsY0FBdkIsRUFBdUMsUUFBdkM7SUFOSyxDQXJCaEI7O0FBNkJBOzs7OztJQUtBLHlCQUFBLEVBQTJCLFNBQUMsTUFBRCxFQUFTLGNBQVQ7QUFFdkIsVUFBQTtNQUFBLFlBQUEsR0FBZSxJQUFDLENBQUEsWUFBRCxDQUFjLE1BQWQsRUFBc0IsY0FBdEI7TUFFZixhQUFBLEdBQWdCO01BRWhCLElBQUcsWUFBSDtRQUNJLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLEtBQU0sQ0FBQSxrQkFBQSxFQUQzQjtPQUFBLE1BQUE7UUFJSSxhQUFBLEdBQWdCLENBQUMsQ0FBRCxFQUFJLENBQUosRUFKcEI7O01BTUEsSUFBQSxHQUFPLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixDQUFDLGFBQUQsRUFBZ0IsQ0FBQyxjQUFjLENBQUMsR0FBaEIsRUFBcUIsY0FBYyxDQUFDLE1BQWYsR0FBc0IsQ0FBM0MsQ0FBaEIsQ0FBNUI7TUFDUCxLQUFBLEdBQVE7TUFFUixPQUFBLEdBQVUsSUFBSSxDQUFDLEtBQUwsQ0FBVyxLQUFYO01BQ1YsSUFBaUIsZUFBakI7QUFBQSxlQUFPLEdBQVA7O01BRUEsSUFBRyxZQUFIO1FBQ0ksT0FBTyxDQUFDLElBQVIsQ0FBYSxPQUFiLEVBREo7O0FBR0EsYUFBTztJQXJCZ0IsQ0FsQzNCOztBQXlEQTs7Ozs7Ozs7Ozs7SUFXQSxnQkFBQSxFQUFrQixTQUFDLE1BQUQsRUFBUyxTQUFULEVBQTJCLFNBQTNCO0FBQ2QsVUFBQTs7UUFEdUIsWUFBWTs7O1FBQU0sWUFBWTs7TUFDckQsSUFBRyxTQUFBLEtBQWEsSUFBaEI7UUFDSSxTQUFBLEdBQVk7UUFFWixJQUFHLFNBQUg7QUFDSSxpQkFBTyxLQURYO1NBSEo7O01BTUEsSUFBRyxTQUFBLElBQWMsU0FBVSxDQUFBLENBQUEsQ0FBVixLQUFnQixJQUFqQztBQUNJLGVBQU8sU0FBUyxDQUFDLE1BQVYsQ0FBaUIsQ0FBakIsRUFEWDs7TUFHQSxVQUFBLEdBQWE7TUFDYixnQkFBQSxHQUFtQjtNQUNuQixpQkFBQSxHQUFvQjtNQUVwQixJQUFBLEdBQU8sTUFBTSxDQUFDLE9BQVAsQ0FBQTtNQUVQLEtBQUEsR0FBUSxJQUFJLENBQUMsS0FBTCxDQUFXLElBQVg7TUFDUixTQUFBLEdBQVk7TUFFWixLQUFBLEdBQVE7QUFFUixXQUFBLCtDQUFBOztRQUNJLE9BQUEsR0FBVSxJQUFJLENBQUMsS0FBTCxDQUFXLGdCQUFYO1FBRVYsSUFBRyxPQUFIO1VBQ0ksU0FBQSxHQUFZLE9BQVEsQ0FBQSxDQUFBLENBQVIsR0FBYSxJQUFiLEdBQW9CLFVBRHBDO1NBQUEsTUFHSyxJQUFHLFNBQUg7VUFDRCxPQUFBLEdBQVUsSUFBSSxDQUFDLEtBQUwsQ0FBVyxVQUFYO1VBQ1YsSUFBRyxPQUFIO1lBQ0ksY0FBQSxHQUFpQixTQUFTLENBQUMsS0FBVixDQUFnQixJQUFoQjtZQUNqQixlQUFBLEdBQWtCLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxLQUFYLENBQWlCLElBQWpCO1lBRWxCLGVBQUEsR0FBcUIsT0FBUSxDQUFBLENBQUEsQ0FBWCxHQUFtQixJQUFuQixHQUE2QjtZQUUvQyxJQUFHLFNBQUEsS0FBYSxPQUFRLENBQUEsQ0FBQSxDQUF4QjtjQUNJLFNBQUEsR0FBWTtBQUVaLG9CQUhKO2FBQUEsTUFLSyxJQUFHLENBQUMsZUFBQSxJQUFvQixPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsY0FBZSxDQUFBLENBQUEsQ0FBbEQsQ0FBQSxJQUF5RCxDQUFDLENBQUMsZUFBRCxJQUFxQixlQUFnQixDQUFBLGVBQWUsQ0FBQyxNQUFoQixHQUF5QixDQUF6QixDQUFoQixLQUErQyxjQUFlLENBQUEsQ0FBQSxDQUFwRixDQUE1RDtjQUNELEtBQUEsR0FBUTtjQUVSLFNBQUEsR0FBWSxPQUFRLENBQUEsQ0FBQTtjQUNwQixjQUFBLEdBQWlCLGNBQWU7Y0FFaEMsSUFBSSxjQUFjLENBQUMsTUFBZixHQUF3QixDQUE1QjtnQkFDSSxTQUFBLElBQWEsSUFBQSxHQUFPLGNBQWMsQ0FBQyxJQUFmLENBQW9CLElBQXBCLEVBRHhCOztBQUdBLG9CQVRDO2FBWFQ7V0FGQzs7UUF3QkwsT0FBQSxHQUFVLElBQUksQ0FBQyxLQUFMLENBQVcsaUJBQVg7UUFFVixJQUFHLE9BQUg7VUFDSSxJQUFHLENBQUksU0FBUDtZQUNJLEtBQUEsR0FBUTtZQUNSLFNBQUEsSUFBYSxPQUFRLENBQUEsQ0FBQSxFQUZ6Qjs7QUFJQSxnQkFMSjs7QUFoQ0o7TUF5Q0EsSUFBRyxTQUFBLElBQWMsU0FBVSxDQUFBLENBQUEsQ0FBVixLQUFnQixJQUFqQztRQUNJLFNBQUEsR0FBWSxTQUFTLENBQUMsTUFBVixDQUFpQixDQUFqQixFQURoQjs7TUFHQSxJQUFHLENBQUksS0FBUDtRQUlJLGNBQUEsR0FBaUIsS0FBSyxDQUFDLE9BQU4sQ0FBYyxTQUFkO1FBRWpCLElBQUcsMkJBQUksY0FBYyxDQUFFLGtCQUF2QjtVQUdJLFNBQUEsR0FBWSxVQUhoQjtTQU5KOztBQVdBLGFBQU87SUE1RU8sQ0FwRWxCOztBQWtKQTs7Ozs7Ozs7Ozs7SUFXQSxXQUFBLEVBQWEsU0FBQyxNQUFELEVBQVMsU0FBVCxFQUFvQix1QkFBcEI7QUFDVCxVQUFBO01BQUEsSUFBRyxTQUFTLENBQUMsS0FBVixDQUFnQixJQUFoQixDQUFxQixDQUFDLE1BQXRCLEtBQWdDLENBQWhDLElBQXFDLFNBQVMsQ0FBQyxPQUFWLENBQWtCLElBQWxCLENBQUEsS0FBMkIsQ0FBbkU7QUFDSSxlQUFPLEtBRFg7O01BR0EsT0FBQSxHQUFVO01BQ1YsU0FBQSxHQUFZO01BQ1osVUFBQSxHQUFhO01BQ2IsU0FBQSxHQUFZO01BQ1osU0FBQSxHQUFZLE1BQU0sQ0FBQyxZQUFQLENBQUE7QUFHWixXQUFTLHdGQUFUO1FBQ0ksSUFBQSxHQUFPLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixDQUE1QixDQUE4QixDQUFDLElBQS9CLENBQUE7UUFFUCxJQUFHLElBQUksQ0FBQyxNQUFMLEtBQWUsQ0FBbEI7QUFDSSxtQkFESjs7UUFHQSxlQUFBLEdBQWtCLE1BQU0sQ0FBQyxnQ0FBUCxDQUF3QyxDQUFDLENBQUQsRUFBSSxJQUFJLENBQUMsTUFBVCxDQUF4QyxDQUF5RCxDQUFDLGFBQTFELENBQUE7UUFFbEIsSUFBRyxlQUFlLENBQUMsT0FBaEIsQ0FBd0IsVUFBeEIsQ0FBQSxJQUF1QyxDQUExQztBQUNJLG1CQURKOztRQUdBLElBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFDLENBQUEsbUJBQVosQ0FBSDtBQUNJLGdCQURKOztRQUdBLElBQUcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxZQUFiLENBQUEsSUFBOEIsQ0FBakM7VUFDSSxPQUFBLEdBQVUsRUFEZDs7UUFHQSxPQUFBLEdBQVUsSUFBQyxDQUFBLGlCQUFpQixDQUFDLElBQW5CLENBQXdCLElBQXhCO1FBRVYsSUFBRyxpQkFBQSxJQUFhLG9CQUFoQjtVQUNJLElBQUcsT0FBUSxDQUFBLENBQUEsQ0FBUixLQUFjLFNBQWpCO0FBQ0ksbUJBQU8sRUFEWDs7VUFHQSxLQUFBLEdBQVEsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsU0FBaEIsRUFBMkIsT0FBUSxDQUFBLENBQUEsQ0FBbkM7VUFFUixJQUFHLEtBQUEsSUFBUyxTQUFaO1lBQ0ksT0FBQSxHQUFVO1lBQ1YsU0FBQSxHQUFZO1lBRVosSUFBRyxJQUFDLENBQUEsNEJBQUQsQ0FBOEIsU0FBOUIsRUFBeUMsT0FBUSxDQUFBLENBQUEsQ0FBakQsQ0FBSDtjQUNJLFNBQUEsR0FBWTtjQUNaLFVBQUEsR0FBZ0IsU0FBUyxDQUFDLE1BQVYsSUFBb0IsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLE1BQWxDLEdBQThDLElBQTlDLEdBQXdELE1BRnpFO2FBQUEsTUFBQTtjQUtJLFNBQUEsR0FBWTtjQUNaLFVBQUEsR0FBYSxLQU5qQjthQUpKO1dBTko7O0FBbkJKO01Bc0NBLFVBQUEsR0FBYSxNQUFNLENBQUMsU0FBUCxDQUFBLENBQWtCLENBQUMsZ0JBQW5CLENBQW9DLENBQXBDO01BRWIsSUFBRyxDQUFJLHVCQUFQO1FBQ0ksU0FBQSxHQUFZLE1BRGhCOztNQUdBLElBQUcsQ0FBSSxVQUFQO1FBQ0ksVUFBQSxHQUFhLEtBRGpCOztNQUdBLFlBQUEsR0FBZTtNQUVmLElBQUcsU0FBQSxJQUFjLFVBQWpCO1FBQ0ksWUFBQSxJQUFnQixXQURwQjs7TUFHQSxZQUFBLElBQWdCLENBQUEsTUFBQSxHQUFPLFNBQVAsR0FBaUIsR0FBakIsQ0FBQSxHQUFzQjtNQUV0QyxJQUFHLFNBQUEsSUFBYyxDQUFJLFVBQXJCO1FBQ0ksWUFBQSxJQUFnQixXQURwQjs7TUFHQSxjQUFBLEdBQWlCLE9BQUEsR0FBVSxDQUFJLFVBQUgsR0FBbUIsQ0FBbkIsR0FBMEIsQ0FBM0I7TUFDM0IsTUFBTSxDQUFDLG9CQUFQLENBQTRCLENBQUMsQ0FBQyxjQUFELEVBQWlCLENBQWpCLENBQUQsRUFBc0IsQ0FBQyxjQUFELEVBQWlCLENBQWpCLENBQXRCLENBQTVCLEVBQXdFLFlBQXhFO0FBRUEsYUFBUSxDQUFBLEdBQUksQ0FBSSxTQUFILEdBQWtCLENBQWxCLEdBQXlCLENBQTFCO0lBdEVILENBN0piOztBQXFPQTs7Ozs7Ozs7SUFRQSw0QkFBQSxFQUE4QixTQUFDLGNBQUQsRUFBaUIsZUFBakI7QUFDMUIsVUFBQTtNQUFBLG1CQUFBLEdBQXNCLGNBQWMsQ0FBQyxLQUFmLENBQXFCLElBQXJCO01BQ3RCLG9CQUFBLEdBQXVCLGVBQWUsQ0FBQyxLQUFoQixDQUFzQixJQUF0QjtNQUV2QixtQkFBbUIsQ0FBQyxHQUFwQixDQUFBO01BQ0Esb0JBQW9CLENBQUMsR0FBckIsQ0FBQTtNQUVPLElBQUcsbUJBQW1CLENBQUMsSUFBcEIsQ0FBeUIsSUFBekIsQ0FBQSxLQUFrQyxvQkFBb0IsQ0FBQyxJQUFyQixDQUEwQixJQUExQixDQUFyQztlQUEwRSxLQUExRTtPQUFBLE1BQUE7ZUFBb0YsTUFBcEY7O0lBUG1CLENBN085Qjs7QUF1UEE7Ozs7Ozs7OztJQVNBLGNBQUEsRUFBZ0IsU0FBQyxjQUFELEVBQWlCLGVBQWpCO0FBQ1osVUFBQTtNQUFBLG1CQUFBLEdBQXNCLGNBQWMsQ0FBQyxLQUFmLENBQXFCLElBQXJCO01BQ3RCLG9CQUFBLEdBQXVCLGVBQWUsQ0FBQyxLQUFoQixDQUFzQixJQUF0QjtNQUV2QixTQUFBLEdBQVk7TUFFWixJQUFHLG1CQUFtQixDQUFDLE1BQXBCLEdBQTZCLG9CQUFvQixDQUFDLE1BQXJEO1FBQ0ksU0FBQSxHQUFZLG9CQUFvQixDQUFDLE9BRHJDO09BQUEsTUFBQTtRQUlJLFNBQUEsR0FBWSxtQkFBbUIsQ0FBQyxPQUpwQzs7TUFNQSxVQUFBLEdBQWE7QUFHYixXQUFTLHdGQUFUO1FBQ0ksSUFBRyxtQkFBb0IsQ0FBQSxDQUFBLENBQXBCLEtBQTBCLG9CQUFxQixDQUFBLENBQUEsQ0FBbEQ7VUFDSSxVQUFBLElBQWMsRUFEbEI7O0FBREo7TUFJQSxJQUFHLElBQUMsQ0FBQSw0QkFBRCxDQUE4QixjQUE5QixFQUE4QyxlQUE5QyxDQUFIO1FBQ0ksSUFBRyxjQUFjLENBQUMsTUFBZixLQUF5QixlQUFlLENBQUMsTUFBNUM7VUFDSSxVQUFBLElBQWMsRUFEbEI7U0FBQSxNQUFBO1VBS0ksVUFBQSxJQUFjLEtBQUEsR0FBUSxJQUFJLENBQUMsR0FBTCxDQUFTLGVBQWUsQ0FBQyxNQUFoQixHQUF5QixjQUFjLENBQUMsTUFBakQsRUFMMUI7U0FESjs7QUFRQSxhQUFPO0lBM0JLLENBaFFoQjs7QUE2UkE7Ozs7O0lBS0EsT0FBQSxFQUFTLFNBQUMsSUFBRDtBQUNMLGFBQU8sSUFBSSxDQUFDLE1BQUwsQ0FBWSxDQUFaLEVBQWMsQ0FBZCxDQUFnQixDQUFDLFdBQWpCLENBQUEsQ0FBQSxHQUFpQyxJQUFJLENBQUMsTUFBTCxDQUFZLENBQVosQ0FBakMsS0FBbUQ7SUFEckQsQ0FsU1Q7O0FBcVNBOzs7Ozs7SUFNQSxZQUFBLEVBQWMsU0FBQyxNQUFELEVBQVMsY0FBVDtBQUNWLFVBQUE7TUFBQSxJQUFBLEdBQU8sTUFBTSxDQUFDLG9CQUFQLENBQTRCLENBQUMsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFELEVBQVMsY0FBVCxDQUE1QjtNQUdQLElBQUcsd0JBQUg7QUFDRSxlQUFPLElBQUMsQ0FBQSxLQUFNLENBQUEsSUFBQSxFQURoQjs7TUFJQSxJQUFDLENBQUEsS0FBRCxHQUFTO01BRVQsR0FBQSxHQUFNLGNBQWMsQ0FBQztNQUNyQixJQUFBLEdBQU8sSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFYO01BRVAsWUFBQSxHQUFlO01BQ2YsWUFBQSxHQUFlO01BRWYsTUFBQSxHQUFTO0FBR1QsYUFBTSxHQUFBLEtBQU8sQ0FBQyxDQUFkO1FBQ0ksSUFBQSxHQUFPLElBQUssQ0FBQSxHQUFBO1FBR1osSUFBRyxDQUFJLElBQVA7VUFDSSxHQUFBO0FBQ0EsbUJBRko7O1FBSUEsU0FBQSxHQUFZO1FBQ1osVUFBQSxHQUFhLElBQUksQ0FBQztRQUNsQixTQUFBLEdBQVk7QUFLWixlQUFNLFNBQUEsSUFBYSxJQUFJLENBQUMsTUFBeEI7VUFFSSxLQUFBLEdBQVEsTUFBTSxDQUFDLGdDQUFQLENBQXdDLENBQUMsR0FBRCxFQUFNLFNBQU4sQ0FBeEMsQ0FBeUQsQ0FBQyxhQUExRCxDQUFBO1VBSVIsSUFBRyxDQUFJLENBQUMsU0FBQSxLQUFhLElBQUksQ0FBQyxNQUFsQixJQUE2QixLQUFBLEtBQVMsU0FBdkMsQ0FBUDtZQUVJLElBQUcsS0FBSyxDQUFDLE9BQU4sQ0FBYyxXQUFkLENBQUEsS0FBOEIsQ0FBQyxDQUFsQztjQUNJLFlBQUEsR0FESjthQUFBLE1BR0ssSUFBRyxLQUFLLENBQUMsT0FBTixDQUFjLGFBQWQsQ0FBQSxLQUFnQyxDQUFDLENBQXBDO2NBQ0QsWUFBQSxHQURDO2FBTFQ7O1VBUUEsU0FBQSxHQUFZO1VBQ1osU0FBQTtRQWZKO1FBa0JBLEtBQUEsR0FBUSxNQUFNLENBQUMsZ0NBQVAsQ0FBd0MsQ0FBQyxHQUFELEVBQU0sSUFBSSxDQUFDLE1BQVgsQ0FBeEMsQ0FBMkQsQ0FBQyxhQUE1RCxDQUFBO1FBR1IsSUFBRyxLQUFLLENBQUMsT0FBTixDQUFjLFVBQWQsQ0FBQSxLQUE2QixDQUFDLENBQWpDO1VBRUksSUFBRyxZQUFBLEdBQWUsWUFBbEI7WUFDSSxNQUFBLEdBQVM7WUFDVCxJQUFDLENBQUEsS0FBTSxDQUFBLGtCQUFBLENBQVAsR0FBNkIsQ0FBQyxHQUFELEVBQU0sQ0FBTjtBQUU3QixrQkFKSjtXQUZKOztRQVFBLEdBQUE7TUE1Q0o7TUE4Q0EsSUFBQyxDQUFBLEtBQU0sQ0FBQSxJQUFBLENBQVAsR0FBZTtBQUNmLGFBQU87SUFsRUcsQ0EzU2Q7O0FBK1dBOzs7Ozs7OztJQVFBLGVBQUEsRUFBaUIsU0FBQyxNQUFELEVBQVMsUUFBVDtBQUNiLFVBQUE7TUFBQSxJQUFjLGdCQUFkO0FBQUEsZUFBQTs7TUFFQSxJQUFBLEdBQU8sUUFBUSxDQUFDO01BRWhCLFFBQUEsR0FBVztNQUNYLGlCQUFBLEdBQW9CO01BQ3BCLGlCQUFBLEdBQW9CO01BQ3BCLHNCQUFBLEdBQXlCO01BQ3pCLHNCQUFBLEdBQXlCO0FBRXpCLGFBQU0sSUFBQSxHQUFPLENBQWI7UUFDSSxRQUFBLEdBQVcsTUFBTSxDQUFDLG9CQUFQLENBQTRCLElBQTVCO1FBQ1gsSUFBQSxDQUFjLFFBQWQ7QUFBQSxpQkFBQTs7UUFFQSxJQUFHLElBQUEsS0FBUSxRQUFRLENBQUMsR0FBcEI7VUFDSSxDQUFBLEdBQUssUUFBUSxDQUFDLE1BQVQsR0FBa0IsRUFEM0I7U0FBQSxNQUFBO1VBSUksQ0FBQSxHQUFJLFFBQVEsQ0FBQyxNQUFULEdBQWtCLEVBSjFCOztBQU1BLGVBQU0sQ0FBQSxJQUFLLENBQVg7VUFDSSxJQUFHLFFBQVMsQ0FBQSxDQUFBLENBQVQsS0FBZSxHQUFsQjtZQUNJLEVBQUU7WUFJRixJQUFHLGlCQUFBLEdBQW9CLGlCQUF2QjtjQUNJLEVBQUU7Y0FDRixRQUFBLEdBQVc7QUFDWCxvQkFISjthQUxKO1dBQUEsTUFVSyxJQUFHLFFBQVMsQ0FBQSxDQUFBLENBQVQsS0FBZSxHQUFsQjtZQUNELEVBQUUsa0JBREQ7V0FBQSxNQUdBLElBQUcsUUFBUyxDQUFBLENBQUEsQ0FBVCxLQUFlLEdBQWxCO1lBQ0QsRUFBRTtZQUdGLElBQUcsc0JBQUEsR0FBeUIsc0JBQTVCO2NBQ0ksRUFBRTtjQUNGLFFBQUEsR0FBVztBQUNYLG9CQUhKO2FBSkM7V0FBQSxNQVNBLElBQUcsUUFBUyxDQUFBLENBQUEsQ0FBVCxLQUFlLEdBQWxCO1lBQ0QsRUFBRSx1QkFERDtXQUFBLE1BSUEsSUFBRyxpQkFBQSxLQUFxQixpQkFBckIsSUFBMkMsc0JBQUEsS0FBMEIsc0JBQXhFO1lBRUQsSUFBRyxRQUFTLENBQUEsQ0FBQSxDQUFULEtBQWUsR0FBbEI7Y0FDSSxRQUFBLEdBQVc7QUFDWCxvQkFGSjthQUFBLE1BSUssSUFBRyxRQUFTLENBQUEsQ0FBQSxDQUFULEtBQWUsR0FBZixJQUFzQixRQUFTLENBQUEsQ0FBQSxDQUFULEtBQWUsR0FBeEM7Y0FDRCxFQUFFO2NBQ0YsUUFBQSxHQUFXO0FBQ1gsb0JBSEM7YUFBQSxNQUFBO2NBTUQsZUFBQSxHQUFrQixNQUFNLENBQUMsZ0NBQVAsQ0FBd0MsQ0FBQyxJQUFELEVBQU8sQ0FBUCxDQUF4QyxDQUFrRCxDQUFDLGFBQW5ELENBQUE7Y0FHbEIsSUFBRyxlQUFlLENBQUMsT0FBaEIsQ0FBd0IscUJBQXhCLENBQUEsR0FBaUQsQ0FBcEQ7Z0JBQ0ksRUFBRTtnQkFDRixRQUFBLEdBQVc7QUFDWCxzQkFISjtlQVRDO2FBTko7O1VBb0JMLEVBQUU7UUEvQ047UUFpREEsSUFBRyxRQUFIO0FBQ0ksZ0JBREo7O1FBR0EsRUFBRTtNQTlETjtNQWlFQSxTQUFBLEdBQVksTUFBTSxDQUFDLG9CQUFQLENBQTRCLENBQUMsQ0FBQyxJQUFELEVBQU8sQ0FBUCxDQUFELEVBQVksUUFBWixDQUE1QixDQUFrRCxDQUFDLElBQW5ELENBQUE7QUFFWixhQUFPLElBQUMsQ0FBQSxlQUFELENBQWlCLFNBQWpCO0lBOUVNLENBdlhqQjs7QUF1Y0E7Ozs7OztJQU1BLHVCQUFBLEVBQXlCLFNBQUMsSUFBRCxFQUFPLFVBQVA7QUFDckIsVUFBQTtNQUFBLENBQUEsR0FBSTtNQUNKLFNBQUEsR0FBWTtNQUNaLFVBQUEsR0FBYTtNQUNiLFVBQUEsR0FBYSxDQUFDO0FBRWQsYUFBTSxDQUFBLEdBQUksSUFBSSxDQUFDLE1BQWY7UUFDSSxJQUFHLElBQUssQ0FBQSxDQUFBLENBQUwsS0FBVyxHQUFkO1VBQ0ksRUFBRTtVQUVGLElBQUcsU0FBQSxLQUFhLENBQWhCO1lBQ0ksVUFBQSxHQUFhLEVBRGpCO1dBSEo7U0FBQSxNQU1LLElBQUcsSUFBSyxDQUFBLENBQUEsQ0FBTCxLQUFXLEdBQWQ7VUFDRCxFQUFFO1VBRUYsSUFBRyxVQUFBLEtBQWMsU0FBakI7WUFDSSxjQUFBLEdBQWlCLElBQUksQ0FBQztZQUV0QixPQUFBLEdBQVUsSUFBSSxDQUFDLFNBQUwsQ0FBZSxVQUFmLEVBQTJCLENBQUEsR0FBRSxDQUE3QjtZQUNWLEdBQUEsR0FBTTtZQUVOLElBQUcsU0FBQSxLQUFhLENBQWIsSUFBbUIsR0FBRyxDQUFDLElBQUosQ0FBUyxPQUFULENBQXRCO0FBQ0ksdUJBREo7O1lBR0EsSUFBQSxHQUFPLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBWixFQUFlLFVBQUEsR0FBYSxDQUE1QixDQUFBLEdBQWlDLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBWixFQUFlLElBQUksQ0FBQyxNQUFwQjtZQUV4QyxDQUFBLElBQU0sY0FBQSxHQUFpQixJQUFJLENBQUM7WUFFNUIsU0FBQSxHQUFZO1lBQ1osVUFBQSxHQUFhLEVBZGpCO1dBSEM7O1FBbUJMLEVBQUU7TUExQk47QUE0QkEsYUFBTztJQWxDYyxDQTdjekI7O0FBaWZBOzs7OztJQUtBLGVBQUEsRUFBaUIsU0FBQyxJQUFEO0FBRWIsVUFBQTtNQUFBLElBQUEsR0FBTztNQUNQLElBQUEsR0FBTyxJQUFJLENBQUMsT0FBTCxDQUFhLElBQWIsRUFBbUIsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFDLEtBQUQ7QUFDdEIsaUJBQU87UUFEZTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkI7TUFJUCxJQUFBLEdBQU87TUFDUCxJQUFBLEdBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFiLEVBQW1CLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxLQUFEO0FBQ3RCLGlCQUFPO1FBRGU7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQW5CO01BSVAsSUFBQSxHQUFPLElBQUMsQ0FBQSx1QkFBRCxDQUF5QixJQUF6QixFQUErQixJQUEvQjtNQUdQLElBQWEsQ0FBSSxJQUFqQjtBQUFBLGVBQU8sR0FBUDs7TUFFQSxRQUFBLEdBQVcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxhQUFYO01BR1gsSUFBRyxRQUFRLENBQUMsTUFBVCxLQUFtQixDQUF0QjtRQUNFLElBQUMsQ0FBQSxVQUFELEdBQWMsS0FEaEI7T0FBQSxNQUFBO1FBR0UsSUFBQyxDQUFBLFVBQUQsR0FBYyxNQUhoQjs7QUFNQSxXQUFBLGVBQUE7O1FBQ0ksT0FBQSxHQUFVLE9BQU8sQ0FBQyxPQUFSLENBQWdCLFlBQWhCLEVBQThCLEVBQTlCO1FBQ1YsSUFBRyxPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsR0FBZCxJQUFxQixPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsR0FBdEM7VUFDSSxPQUFBLEdBQVUsT0FBTyxDQUFDLFNBQVIsQ0FBa0IsQ0FBbEIsRUFEZDtTQUFBLE1BRUssSUFBRyxPQUFPLENBQUMsT0FBUixDQUFnQixTQUFoQixDQUFBLEtBQThCLENBQWpDO1VBQ0QsT0FBQSxHQUFVLE9BQU8sQ0FBQyxTQUFSLENBQWtCLFNBQVMsQ0FBQyxNQUE1QixFQURUOztRQUdMLFFBQVMsQ0FBQSxHQUFBLENBQVQsR0FBZ0I7QUFQcEI7QUFTQSxhQUFPO0lBbkNNLENBdGZqQjs7QUEyaEJBOzs7Ozs7O0lBT0EsZUFBQSxFQUFpQixTQUFDLE1BQUQsRUFBUyxjQUFULEVBQXlCLE9BQXpCO0FBQ2IsVUFBQTtNQUFBLElBQUcsT0FBTyxDQUFDLE9BQVIsQ0FBZ0Isb0JBQWhCLEVBQXNDLEVBQXRDLENBQXlDLENBQUMsSUFBMUMsQ0FBQSxDQUFnRCxDQUFDLE1BQWpELEdBQTBELENBQTdEO0FBQ0ksZUFBTyxLQURYOztNQUdBLElBQUcsT0FBTyxDQUFDLElBQVIsQ0FBQSxDQUFjLENBQUMsTUFBZixLQUF5QixDQUE1QjtBQUNJLGVBQU8sS0FEWDs7TUFHQSxTQUFBLEdBQVk7TUFDWixZQUFBLEdBQWU7TUFHZixZQUFBLEdBQW1CLElBQUEsTUFBQSxDQUFPLElBQUEsR0FBSyxPQUFMLEdBQWEsdUJBQXBCLEVBQTRDLEdBQTVDO01BQ25CLGdCQUFBLEdBQXVCLElBQUEsTUFBQSxDQUFPLElBQUEsR0FBSyxPQUFMLEdBQWEsZ0VBQXBCLEVBQXFGLEdBQXJGO01BQ3ZCLFVBQUEsR0FBaUIsSUFBQSxNQUFBLENBQU8saURBQUEsR0FBa0QsT0FBbEQsR0FBMEQsV0FBakUsRUFBNkUsR0FBN0U7TUFFakIsVUFBQSxHQUFhLGNBQWMsQ0FBQyxHQUFmLEdBQXFCO0FBRWxDLGFBQU0sVUFBQSxHQUFhLENBQW5CO1FBQ0ksSUFBQSxHQUFPLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixVQUE1QjtRQUVQLElBQUcsQ0FBSSxTQUFQO1VBRUksVUFBQSxHQUFhLGdCQUFnQixDQUFDLElBQWpCLENBQXNCLElBQXRCO1VBRWIsSUFBRyxJQUFBLEtBQVEsVUFBWDtZQUNJLFlBQUEsR0FBZTtZQUNmLFNBQUEsR0FBWSxJQUFDLENBQUEsZ0JBQUQsQ0FBa0IsTUFBbEIsRUFBMEIsVUFBVyxDQUFBLENBQUEsQ0FBckMsRUFGaEI7V0FKSjs7UUFRQSxJQUFHLENBQUksU0FBUDtVQUVJLFlBQUEsR0FBZSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQjtVQUVmLElBQUcsSUFBQSxLQUFRLFlBQVg7WUFDSSxZQUFBLEdBQWU7WUFDZixTQUFBLEdBQVksSUFBQyxDQUFBLGdCQUFELENBQWtCLE1BQWxCLEVBQTBCLFlBQWEsQ0FBQSxDQUFBLENBQXZDLEVBRmhCO1dBSko7O1FBUUEsSUFBRyxDQUFJLFNBQVA7VUFFSSxPQUFBLEdBQVUsWUFBWSxDQUFDLElBQWIsQ0FBa0IsSUFBbEI7VUFFVixJQUFHLElBQUEsS0FBUSxPQUFYO1lBQ0ksS0FBQSxHQUFRLE9BQVEsQ0FBQSxDQUFBO1lBQ2hCLFFBQUEsR0FBVyxJQUFDLENBQUEsZUFBRCxDQUFpQixLQUFqQjtZQUNYLFFBQVEsQ0FBQyxJQUFULENBQWMsRUFBZDtZQUVBLFdBQUEsR0FDSTtjQUFBLEdBQUEsRUFBTSxVQUFOO2NBQ0EsTUFBQSxFQUFRLGNBQWMsQ0FBQyxNQUR2Qjs7WUFLSixZQUFBLEdBQWU7WUFDZixTQUFBLEdBQVksSUFBQyxDQUFBLGFBQUQsQ0FBZSxNQUFmLEVBQXVCLFdBQXZCLEVBQW9DLFFBQXBDLEVBWmhCO1dBSko7O1FBa0JBLElBQUcsQ0FBSSxTQUFQO1VBRUksYUFBQSxHQUFvQixJQUFBLE1BQUEsQ0FBTyx5RUFBQSxHQUEwRSxPQUExRSxHQUFrRix1Q0FBbEYsR0FBeUgsT0FBekgsR0FBaUksaURBQXhJLEVBQTBMLEdBQTFMO1VBQ3BCLE9BQUEsR0FBVSxhQUFhLENBQUMsSUFBZCxDQUFtQixJQUFuQjtVQUVWLElBQUcsSUFBQSxLQUFRLE9BQVg7WUFDSSxRQUFBLEdBQVcsT0FBUSxDQUFBLENBQUE7WUFFbkIsSUFBRyxRQUFRLENBQUMsTUFBVCxHQUFrQixDQUFyQjtBQUNJLHFCQUFPLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixNQUFsQixFQUEwQixRQUExQixFQURYOztZQUdBLFFBQUEsR0FBVyxPQUFRLENBQUEsQ0FBQTtZQUduQixJQUFHLFFBQUEsSUFBYSxRQUFRLENBQUMsTUFBVCxHQUFrQixDQUFsQztjQUNJLE1BQUEsR0FBUyxLQUFLLENBQUMsU0FBTixDQUFnQixJQUFDLENBQUEsZ0JBQUQsQ0FBa0IsTUFBbEIsQ0FBaEIsRUFBMkMsUUFBM0M7Y0FFVCxJQUFHLHVCQUFBLElBQW1CLGdDQUF0QjtBQUNJLHVCQUFPLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixNQUFsQixFQUEwQixNQUFNLENBQUMsTUFBTyxDQUFBLE9BQUEsQ0FBUSxDQUFDLElBQWpELEVBQXVELElBQXZELEVBRFg7ZUFISjthQVRKO1dBTEo7O1FBb0JBLEtBQUEsR0FBUSxNQUFNLENBQUMsZ0NBQVAsQ0FBd0MsQ0FBQyxVQUFELEVBQWEsSUFBSSxDQUFDLE1BQWxCLENBQXhDLENBQWtFLENBQUMsYUFBbkUsQ0FBQTtRQUdSLElBQUcsS0FBSyxDQUFDLE9BQU4sQ0FBYyxTQUFkLENBQUEsS0FBNEIsQ0FBQyxDQUFoQztVQUdJLElBQUcsWUFBQSxJQUFpQixVQUFBLEtBQWMsQ0FBQyxZQUFBLEdBQWUsQ0FBaEIsQ0FBbEM7WUFDSSxRQUFBLEdBQVc7WUFDWCxPQUFBLEdBQVUsUUFBUSxDQUFDLElBQVQsQ0FBYyxJQUFkO1lBRVYsSUFBRyxJQUFBLEtBQVEsT0FBWDtBQUNJLHFCQUFPLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixNQUFsQixFQUEwQixPQUFRLENBQUEsQ0FBQSxDQUFsQyxFQURYO2FBSko7O1VBUUEsbUJBQUEsR0FBMEIsSUFBQSxNQUFBLENBQU8sc0NBQUEsR0FBdUMsT0FBOUMsRUFBeUQsR0FBekQ7VUFDMUIsT0FBQSxHQUFVLG1CQUFtQixDQUFDLElBQXBCLENBQXlCLElBQXpCO1VBRVYsSUFBRyxJQUFBLEtBQVEsT0FBWDtBQUNJLG1CQUFPLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixNQUFsQixFQUEwQixPQUFRLENBQUEsQ0FBQSxDQUFsQyxFQURYOztVQUlBLG1CQUFBLEdBQTBCLElBQUEsTUFBQSxDQUFPLGdCQUFBLEdBQWlCLE9BQWpCLEdBQXlCLHdCQUFoQyxFQUF5RCxHQUF6RDtVQUMxQixPQUFBLEdBQVUsbUJBQW1CLENBQUMsSUFBcEIsQ0FBeUIsSUFBekI7VUFFVixJQUFHLElBQUEsS0FBUSxPQUFYO0FBQ0ksbUJBQU8sSUFBQyxDQUFBLGdCQUFELENBQWtCLE1BQWxCLEVBQTBCLE9BQVEsQ0FBQSxDQUFBLENBQWxDLEVBRFg7V0FyQko7O1FBeUJBLElBQUcsS0FBSyxDQUFDLE9BQU4sQ0FBYyxVQUFkLENBQUEsS0FBNkIsQ0FBQyxDQUFqQztBQUNJLGdCQURKOztRQUdBLEVBQUU7TUF4Rk47QUEwRkEsYUFBTztJQTNHTSxDQWxpQmpCOztBQStvQkE7Ozs7Ozs7O0lBUUEsZ0JBQUEsRUFBa0IsU0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLGNBQWYsRUFBK0IsV0FBL0I7QUFDZCxVQUFBO01BQUEsSUFBRyxDQUFJLFdBQVA7UUFDSSxXQUFBLEdBQWMsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsTUFBaEIsRUFBd0IsSUFBeEIsRUFBOEIsY0FBOUIsRUFEbEI7O01BR0EsSUFBRyxDQUFJLFdBQUosSUFBbUIsQ0FBSSxJQUFDLENBQUEsVUFBM0I7QUFDSSxlQURKOztNQUdBLEtBQUEsR0FBUSxPQUFBLENBQVEsOEJBQVI7TUFDUixJQUFHLElBQUMsQ0FBQSxVQUFKO1FBQ0UsT0FBQSxHQUFVLEtBQUssQ0FBQyxTQUFOLENBQUEsRUFEWjtPQUFBLE1BQUE7UUFHRSxPQUFBLEdBQVUsS0FBSyxDQUFDLE9BQU4sQ0FBYyxXQUFkLEVBSFo7O01BS0EsSUFBRyxDQUFJLE9BQUosSUFBbUIsaUJBQXRCO0FBQ0ksZUFESjs7TUFHQSxJQUFHLHVCQUFBLElBQW1CLE9BQU8sQ0FBQyxLQUFSLEtBQWlCLEVBQXZDO1FBQ0ksSUFBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWpCO1VBQ0ksSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0Qiw0QkFBQSxHQUErQixXQUEzRCxFQUF3RTtZQUNwRSxRQUFBLEVBQVUsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUQ0QztXQUF4RSxFQURKO1NBQUEsTUFBQTtVQUtJLE9BQU8sQ0FBQyxHQUFSLENBQVksNEJBQUEsR0FBK0IsV0FBL0IsR0FBNkMsS0FBN0MsR0FBcUQsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUEvRSxFQUxKOztBQU9BLGVBUko7O01BU0EsSUFBRyxzQ0FBZSxDQUFFLGNBQWhCLENBQStCLElBQS9CLFdBQUo7QUFDSSxlQURKOztNQUdBLEtBQUEsR0FBUSxPQUFPLENBQUMsTUFBTyxDQUFBLElBQUE7TUFHdkIsSUFBRyxLQUFBLFlBQWlCLEtBQXBCO0FBQ0ksYUFBQSx1Q0FBQTs7VUFDSSxJQUFHLEdBQUcsQ0FBQyxRQUFQO1lBQ0ksS0FBQSxHQUFRO0FBQ1Isa0JBRko7O0FBREosU0FESjs7QUFNQSxhQUFPO0lBckNPLENBdnBCbEI7O0FBOHJCQTs7Ozs7SUFLQSxhQUFBLEVBQWUsU0FBQyxNQUFELEVBQVMsY0FBVCxFQUF5QixRQUF6QjtBQUNYLFVBQUE7TUFBQSxVQUFBLEdBQWE7TUFDYixTQUFBLEdBQWE7TUFDYixJQUFPLGdCQUFQO0FBQ0ksZUFESjs7QUFHQSxXQUFBLDBDQUFBOztRQUVJLElBQUcsVUFBQSxLQUFjLENBQWpCO1VBQ0ksSUFBRyxPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsR0FBakI7WUFDSSxTQUFBLEdBQVksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsTUFBakIsRUFBeUIsY0FBekIsRUFBeUMsT0FBekM7WUFHWixJQUFHLE9BQUEsS0FBVyxPQUFYLElBQXVCLENBQUksU0FBOUI7Y0FDSSxTQUFBLEdBQVksSUFBQyxDQUFBLGdCQUFELENBQWtCLE1BQWxCLEVBRGhCOztZQUdBLFVBQUE7QUFDQSxxQkFSSjtXQUFBLE1BVUssSUFBRyxPQUFBLEtBQVcsUUFBWCxJQUF1QixPQUFBLEtBQVcsTUFBckM7WUFDRCxTQUFBLEdBQVksSUFBQyxDQUFBLGdCQUFELENBQWtCLE1BQWxCO1lBQ1osVUFBQTtBQUNBLHFCQUhDO1dBQUEsTUFLQSxJQUFHLE9BQUEsS0FBVyxRQUFkO1lBQ0QsU0FBQSxHQUFZLElBQUMsQ0FBQSxjQUFELENBQWdCLE1BQWhCO1lBQ1osVUFBQTtBQUNBLHFCQUhDO1dBQUEsTUFBQTtZQU1ELFNBQUEsR0FBWSxJQUFDLENBQUEsZ0JBQUQsQ0FBa0IsTUFBbEIsRUFBMEIsT0FBMUI7WUFDWixVQUFBO0FBQ0EscUJBUkM7V0FoQlQ7O1FBMkJBLElBQUcsVUFBQSxJQUFjLFFBQVEsQ0FBQyxNQUFULEdBQWtCLENBQW5DO0FBQ0ksZ0JBREo7O1FBR0EsSUFBRyxTQUFBLEtBQWEsSUFBaEI7QUFDSSxnQkFESjs7UUFJQSxLQUFBLEdBQVE7QUFDUjtBQUFBLGFBQUEsdUNBQUE7O1VBQ0ksSUFBZ0IsMkJBQWhCO0FBQUEscUJBQUE7O1VBQ0EsS0FBQSxHQUFRLE1BQU0sQ0FBQyxZQUFQLENBQW9CLFNBQXBCLEVBQStCLE9BQS9CO1VBQ1IsSUFBUyxLQUFUO0FBQUEsa0JBQUE7O0FBSEo7UUFLQSxJQUFHLEtBQUg7VUFDSSxTQUFBLEdBQVksTUFEaEI7U0FBQSxNQUFBO1VBR0ksT0FBQSxHQUFVLEtBQUssQ0FBQyxZQUFOLENBQW1CLFNBQW5CLEVBQThCLE9BQTlCO1VBR1YsSUFBTywwQkFBSixJQUFzQixDQUFJLElBQUMsQ0FBQSxPQUFELENBQVMsT0FBTyxFQUFDLEtBQUQsRUFBaEIsQ0FBN0I7WUFDSSxTQUFBLEdBQVk7QUFDWixrQkFGSjs7VUFJQSxTQUFBLEdBQVksT0FBTyxFQUFDLEtBQUQsR0FWdkI7O1FBWUEsVUFBQTtBQXRESjtNQXlEQSxJQUFHLFFBQVEsQ0FBQyxNQUFULEdBQWtCLENBQWxCLElBQXdCLENBQUMsUUFBUyxDQUFBLFFBQVEsQ0FBQyxNQUFULEdBQWdCLENBQWhCLENBQWtCLENBQUMsTUFBNUIsS0FBc0MsQ0FBdEMsSUFBMkMsUUFBUyxDQUFBLFFBQVEsQ0FBQyxNQUFULEdBQWdCLENBQWhCLENBQWtCLENBQUMsS0FBNUIsQ0FBa0MsaUJBQWxDLENBQTVDLENBQTNCO0FBQ0ksZUFBTyxVQURYOztBQUdBLGFBQU87SUFsRUksQ0Fuc0JmOztBQXV3QkE7Ozs7Ozs7SUFPQSw2QkFBQSxFQUErQixTQUFDLE1BQUQsRUFBUyxRQUFUO0FBQzNCLFVBQUE7TUFBQSxVQUFBLEdBQWE7TUFDYixRQUFBLEdBQVc7TUFDWCxtQkFBQSxHQUFzQjtNQUN0QixpQkFBQSxHQUFvQjtNQUNwQixZQUFBLEdBQWU7TUFDZixhQUFBLEdBQWdCO01BQ2hCLEtBQUEsR0FBUSxDQUFDO01BQ1QsWUFBQSxHQUFlO0FBRWYsYUFBQSxJQUFBO1FBQ0ksS0FBQTtRQUNBLG1CQUFBLEdBQXNCLENBQUMsUUFBUSxDQUFDLEdBQVYsRUFBZSxRQUFRLENBQUMsTUFBVCxHQUFrQixLQUFsQixHQUEwQixDQUF6QztRQUN0QixLQUFBLEdBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFWLEVBQWUsUUFBUSxDQUFDLE1BQXhCLENBQUQsRUFBa0MsQ0FBQyxtQkFBb0IsQ0FBQSxDQUFBLENBQXJCLEVBQXlCLG1CQUFvQixDQUFBLENBQUEsQ0FBN0MsQ0FBbEM7UUFDUixXQUFBLEdBQWMsTUFBTSxDQUFDLG9CQUFQLENBQTRCLEtBQTVCO1FBQ2QsSUFBRyxhQUFhLENBQUMsSUFBZCxDQUFtQixNQUFNLENBQUMsb0JBQVAsQ0FBNEIsS0FBNUIsQ0FBbkIsQ0FBQSxJQUEwRCxtQkFBb0IsQ0FBQSxDQUFBLENBQXBCLEtBQTBCLENBQUMsQ0FBckYsSUFBMEYsV0FBQSxLQUFlLFlBQTVHO1VBQ0ksVUFBQSxHQUFhLEtBRGpCOztRQUVBLFlBQUEsR0FBZSxNQUFNLENBQUMsb0JBQVAsQ0FBNEIsS0FBNUI7UUFDZixJQUFTLFVBQVQ7QUFBQSxnQkFBQTs7TUFSSjtNQVNBLEtBQUEsR0FBUSxDQUFDO0FBQ1QsYUFBQSxJQUFBO1FBQ0ksS0FBQTtRQUNBLGlCQUFBLEdBQW9CLENBQUMsUUFBUSxDQUFDLEdBQVYsRUFBZSxRQUFRLENBQUMsTUFBVCxHQUFrQixLQUFsQixHQUEwQixDQUF6QztRQUNwQixLQUFBLEdBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFWLEVBQWUsUUFBUSxDQUFDLE1BQXhCLENBQUQsRUFBa0MsQ0FBQyxpQkFBa0IsQ0FBQSxDQUFBLENBQW5CLEVBQXVCLGlCQUFrQixDQUFBLENBQUEsQ0FBekMsQ0FBbEM7UUFDUixXQUFBLEdBQWMsTUFBTSxDQUFDLG9CQUFQLENBQTRCLEtBQTVCO1FBQ2QsSUFBRyxZQUFZLENBQUMsSUFBYixDQUFrQixXQUFsQixDQUFBLElBQWtDLGlCQUFrQixDQUFBLENBQUEsQ0FBbEIsS0FBd0IsR0FBMUQsSUFBaUUsV0FBQSxLQUFlLFlBQW5GO1VBQ0ksUUFBQSxHQUFXLEtBRGY7O1FBRUEsWUFBQSxHQUFlLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixLQUE1QjtRQUNmLElBQVMsUUFBVDtBQUFBLGdCQUFBOztNQVJKO01BVUEsbUJBQW9CLENBQUEsQ0FBQSxDQUFwQixJQUEwQjtNQUMxQixpQkFBa0IsQ0FBQSxDQUFBLENBQWxCLElBQXdCO0FBQ3hCLGFBQU8sTUFBTSxDQUFDLG9CQUFQLENBQTRCLENBQUMsbUJBQUQsRUFBc0IsaUJBQXRCLENBQTVCO0lBaENvQixDQTl3Qi9COztBQWd6QkE7Ozs7Ozs7SUFPQSx5QkFBQSxFQUEyQixTQUFDLEtBQUQ7QUFDdkIsVUFBQTtNQUFBLFFBQUEsR0FBVyxLQUFLLENBQUM7TUFFakIsQ0FBQSxHQUFJLE9BQUEsQ0FBUSxRQUFSO01BRUosSUFBRyxDQUFBLENBQUUsUUFBRixDQUFXLENBQUMsUUFBWixDQUFxQixTQUFyQixDQUFBLElBQW1DLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxRQUFaLENBQXFCLFVBQXJCLENBQWdDLENBQUMsTUFBakMsR0FBMEMsQ0FBaEY7QUFDSSxlQUFPLEtBRFg7O01BR0EsSUFBRyxDQUFBLENBQUUsUUFBRixDQUFXLENBQUMsTUFBWixDQUFBLENBQW9CLENBQUMsUUFBckIsQ0FBOEIsbUJBQTlCLENBQUg7QUFDSSxlQUFPLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxNQUFaLENBQUEsQ0FBb0IsQ0FBQyxRQUFyQixDQUE4QixrREFBOUIsRUFEWDs7TUFHQSxJQUFHLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxJQUFaLENBQUEsQ0FBa0IsQ0FBQyxRQUFuQixDQUE0QixXQUE1QixDQUFBLElBQTRDLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxRQUFaLENBQXFCLE9BQXJCLENBQS9DO0FBQ0ksZUFBTyxDQUFBLENBQUUsQ0FBQyxDQUFBLENBQUUsUUFBRixDQUFXLENBQUMsSUFBWixDQUFBLENBQW1CLENBQUEsQ0FBQSxDQUFwQixFQUF3QixRQUF4QixDQUFGLEVBRFg7O01BR0EsSUFBRyxDQUFBLENBQUUsUUFBRixDQUFXLENBQUMsSUFBWixDQUFBLENBQWtCLENBQUMsUUFBbkIsQ0FBNEIsT0FBNUIsQ0FBQSxJQUF3QyxDQUFBLENBQUUsUUFBRixDQUFXLENBQUMsUUFBWixDQUFxQixXQUFyQixDQUEzQztBQUNHLGVBQU8sQ0FBQSxDQUFFLENBQUMsUUFBRCxFQUFXLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxJQUFaLENBQUEsQ0FBbUIsQ0FBQSxDQUFBLENBQTlCLENBQUYsRUFEVjs7TUFHQSxJQUFHLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxJQUFaLENBQUEsQ0FBa0IsQ0FBQyxRQUFuQixDQUE0QixXQUE1QixDQUFBLElBQTRDLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxJQUFaLENBQUEsQ0FBa0IsQ0FBQyxRQUFuQixDQUE0QixpQkFBNUIsQ0FBL0M7QUFDSSxlQUFPLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxNQUFaLENBQUEsQ0FBb0IsQ0FBQyxRQUFyQixDQUE4Qiw4QkFBOUIsRUFEWDs7QUFHQSxhQUFPO0lBcEJnQixDQXZ6QjNCOztBQTYwQkE7Ozs7O0lBS0EsY0FBQSxFQUFnQixTQUFDLE1BQUQ7QUFDWixVQUFBO01BQUEsSUFBQSxHQUFPLE1BQU0sQ0FBQyxPQUFQLENBQUE7TUFFUCxLQUFBLEdBQVEsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFYO0FBQ1IsV0FBQSx1Q0FBQTs7UUFDSSxJQUFBLEdBQU8sSUFBSSxDQUFDLElBQUwsQ0FBQTtRQUdQLElBQUcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxVQUFiLENBQUEsS0FBNEIsQ0FBQyxDQUFoQztVQUNJLEtBQUEsR0FBUSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQVg7VUFDUixZQUFBLEdBQWUsS0FBSyxDQUFDLE9BQU4sQ0FBYyxTQUFkO0FBQ2YsaUJBQU8sSUFBQyxDQUFBLGdCQUFELENBQWtCLE1BQWxCLEVBQTBCLEtBQU0sQ0FBQSxZQUFBLEdBQWUsQ0FBZixDQUFoQyxFQUhYOztBQUpKO0lBSlksQ0FsMUJoQjs7QUErMUJBOzs7Ozs7SUFNQSx3QkFBQSxFQUEwQixTQUFDLE1BQUQsRUFBUyxJQUFULEVBQWUsS0FBZixFQUFzQixJQUF0QjtBQUN0QixVQUFBOztRQUQ0QyxPQUFPOztNQUNuRCxJQUFHLElBQUEsS0FBUSxJQUFYO1FBQ0ksUUFBQSxHQUFXLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixJQUE1QjtRQUNYLE1BQUEsR0FBUyxJQUFDLENBQUEsZ0JBQUQsQ0FBa0IsUUFBbEIsRUFBNEIsSUFBNUIsRUFBa0MsS0FBbEM7UUFDVCxJQUFHLE1BQUEsS0FBVSxJQUFiO0FBQ0ksaUJBQU8sQ0FBQyxJQUFELEVBQU8sTUFBUCxFQURYO1NBSEo7T0FBQSxNQUFBO1FBTUksSUFBQSxHQUFPLE1BQU0sQ0FBQyxPQUFQLENBQUE7UUFDUCxHQUFBLEdBQU07UUFDTixLQUFBLEdBQVEsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFYO0FBQ1IsYUFBQSx1Q0FBQTs7VUFDSSxNQUFBLEdBQVMsSUFBQyxDQUFBLGdCQUFELENBQWtCLElBQWxCLEVBQXdCLElBQXhCLEVBQThCLEtBQTlCO1VBQ1QsSUFBRyxNQUFBLEtBQVUsSUFBYjtBQUNJLG1CQUFPLENBQUMsR0FBRCxFQUFNLE1BQU4sRUFEWDs7VUFFQSxHQUFBO0FBSkosU0FUSjs7QUFjQSxhQUFPO0lBZmUsQ0FyMkIxQjs7QUFzM0JBOzs7Ozs7OztJQVFBLGdCQUFBLEVBQWtCLFNBQUMsUUFBRCxFQUFXLElBQVgsRUFBaUIsS0FBakI7QUFDZCxVQUFBO01BQUEsSUFBRyxLQUFLLENBQUMsSUFBTixDQUFXLFFBQVgsQ0FBSDtRQUNJLEtBQUEsR0FBUSxRQUFRLENBQUMsS0FBVCxDQUFlLEdBQWY7UUFDUixhQUFBLEdBQWdCO0FBQ2hCLGFBQUEsdUNBQUE7O1VBQ0ksSUFBRyxPQUFPLENBQUMsT0FBUixDQUFnQixJQUFoQixDQUFBLEtBQXlCLENBQUMsQ0FBN0I7QUFDSSxrQkFESjs7VUFFQSxhQUFBO0FBSEo7UUFLRSxZQUFBLEdBQWUsS0FBSyxDQUFDLEtBQU4sQ0FBWSxDQUFaLEVBQWUsYUFBZixDQUE2QixDQUFDLElBQTlCLENBQW1DLEdBQW5DO0FBQ2YsZUFBTyxZQUFZLENBQUMsTUFBYixHQUFzQixFQVRuQzs7QUFVQSxhQUFPO0lBWE8sQ0E5M0JsQjs7QUFMSiIsInNvdXJjZXNDb250ZW50IjpbInByb3h5ID0gcmVxdWlyZSBcIi4uL3NlcnZpY2VzL3BocC1wcm94eS5jb2ZmZWVcIlxuY29uZmlnID0gcmVxdWlyZSBcIi4uL2NvbmZpZy5jb2ZmZWVcIlxucGx1Z2lucyA9IHJlcXVpcmUgXCIuLi9zZXJ2aWNlcy9wbHVnaW4tbWFuYWdlci5jb2ZmZWVcIlxuXG5tb2R1bGUuZXhwb3J0cyA9XG4gICAgc3RydWN0dXJlU3RhcnRSZWdleDogLyg/OmFic3RyYWN0IGNsYXNzfGNsYXNzfHRyYWl0fGludGVyZmFjZSlcXHMrKFxcdyspL1xuICAgIHVzZVN0YXRlbWVudFJlZ2V4OiAvKD86dXNlKSg/OlteXFx3XFxcXF0pKFtcXHdcXFxcXSspKD8hW1xcd1xcXFxdKSg/Oig/OlsgXSthc1sgXSspKFxcdyspKT8oPzo7KS9cblxuICAgICMgU2ltcGxlIGNhY2hlIHRvIGF2b2lkIGR1cGxpY2F0ZSBjb21wdXRhdGlvbiBmb3IgZWFjaCBwcm92aWRlcnNcbiAgICBjYWNoZTogW11cblxuICAgICMgaXMgYSBtZXRob2Qgb3IgYSBzaW1wbGUgZnVuY3Rpb25cbiAgICBpc0Z1bmN0aW9uOiBmYWxzZVxuXG4gICAgIyMjKlxuICAgICAqIFJldHJpZXZlcyB0aGUgY2xhc3MgdGhlIHNwZWNpZmllZCB0ZXJtIChtZXRob2Qgb3IgcHJvcGVydHkpIGlzIGJlaW5nIGludm9rZWQgb24uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgICAgICAgICBUZXh0RWRpdG9yIHRvIHNlYXJjaCBmb3IgbmFtZXNwYWNlIG9mIHRlcm0uXG4gICAgICogQHBhcmFtICB7c3RyaW5nfSAgICAgdGVybSAgICAgICAgICAgVGVybSB0byBzZWFyY2ggZm9yLlxuICAgICAqIEBwYXJhbSAge1BvaW50fSAgICAgIGJ1ZmZlclBvc2l0aW9uIFRoZSBjdXJzb3IgbG9jYXRpb24gdGhlIHRlcm0gaXMgYXQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtzdHJpbmd9XG4gICAgICpcbiAgICAgKiBAZXhhbXBsZSBJbnZva2luZyBpdCBvbiBNeU1ldGhvZDo6Zm9vKCktPmJhcigpIHdpbGwgYXNrIHdoYXQgY2xhc3MgJ2JhcicgaXMgaW52b2tlZCBvbiwgd2hpY2ggd2lsbCB3aGF0ZXZlciB0eXBlXG4gICAgICogICAgICAgICAgZm9vIHJldHVybnMuXG4gICAgIyMjXG4gICAgZ2V0Q2FsbGVkQ2xhc3M6IChlZGl0b3IsIHRlcm0sIGJ1ZmZlclBvc2l0aW9uKSAtPlxuICAgICAgICBmdWxsQ2FsbCA9IEBnZXRTdGFja0NsYXNzZXMoZWRpdG9yLCBidWZmZXJQb3NpdGlvbilcblxuICAgICAgICBpZiBmdWxsQ2FsbD8ubGVuZ3RoID09IDAgb3IgIXRlcm1cbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgIHJldHVybiBAcGFyc2VFbGVtZW50cyhlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uLCBmdWxsQ2FsbClcblxuICAgICMjIypcbiAgICAgKiBHZXQgYWxsIHZhcmlhYmxlcyBkZWNsYXJlZCBpbiB0aGUgY3VycmVudCBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7VGV4dEVkdXRpcn0gZWRpdG9yICAgICAgICAgQXRvbSB0ZXh0IGVkaXRvclxuICAgICAqIEBwYXJhbSB7UmFuZ2V9ICAgICAgYnVmZmVyUG9zaXRpb24gUG9zaXRpb24gb2YgdGhlIGN1cnJlbnQgYnVmZmVyXG4gICAgIyMjXG4gICAgZ2V0QWxsVmFyaWFibGVzSW5GdW5jdGlvbjogKGVkaXRvciwgYnVmZmVyUG9zaXRpb24pIC0+XG4gICAgICAgICMgcmV0dXJuIGlmIG5vdCBAaXNJbkZ1bmN0aW9uKGVkaXRvciwgYnVmZmVyUG9zaXRpb24pXG4gICAgICAgIGlzSW5GdW5jdGlvbiA9IEBpc0luRnVuY3Rpb24oZWRpdG9yLCBidWZmZXJQb3NpdGlvbilcblxuICAgICAgICBzdGFydFBvc2l0aW9uID0gbnVsbFxuXG4gICAgICAgIGlmIGlzSW5GdW5jdGlvblxuICAgICAgICAgICAgc3RhcnRQb3NpdGlvbiA9IEBjYWNoZVsnZnVuY3Rpb25Qb3NpdGlvbiddXG5cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhcnRQb3NpdGlvbiA9IFswLCAwXVxuXG4gICAgICAgIHRleHQgPSBlZGl0b3IuZ2V0VGV4dEluQnVmZmVyUmFuZ2UoW3N0YXJ0UG9zaXRpb24sIFtidWZmZXJQb3NpdGlvbi5yb3csIGJ1ZmZlclBvc2l0aW9uLmNvbHVtbi0xXV0pXG4gICAgICAgIHJlZ2V4ID0gLyhcXCRbYS16QS1aX10rKS9nXG5cbiAgICAgICAgbWF0Y2hlcyA9IHRleHQubWF0Y2gocmVnZXgpXG4gICAgICAgIHJldHVybiBbXSBpZiBub3QgbWF0Y2hlcz9cblxuICAgICAgICBpZiBpc0luRnVuY3Rpb25cbiAgICAgICAgICAgIG1hdGNoZXMucHVzaCBcIiR0aGlzXCJcblxuICAgICAgICByZXR1cm4gbWF0Y2hlc1xuXG4gICAgIyMjKlxuICAgICAqIFJldHJpZXZlcyB0aGUgZnVsbCBjbGFzcyBuYW1lLiBJZiB0aGUgY2xhc3MgbmFtZSBpcyBhIEZRQ04gKEZ1bGx5IFF1YWxpZmllZCBDbGFzcyBOYW1lKSwgaXQgYWxyZWFkeSBpcyBhIGZ1bGxcbiAgICAgKiBuYW1lIGFuZCBpdCBpcyByZXR1cm5lZCBhcyBpcy4gT3RoZXJ3aXNlLCB0aGUgY3VycmVudCBuYW1lc3BhY2UgYW5kIHVzZSBzdGF0ZW1lbnRzIGFyZSBzY2FubmVkLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSAgZWRpdG9yICAgIFRleHQgZWRpdG9yIGluc3RhbmNlLlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfG51bGx9IGNsYXNzTmFtZSBOYW1lIG9mIHRoZSBjbGFzcyB0byByZXRyaWV2ZSB0aGUgZnVsbCBuYW1lIG9mLiBJZiBudWxsLCB0aGUgY3VycmVudCBjbGFzcyB3aWxsXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlIHJldHVybmVkIChpZiBhbnkpLlxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gICAgIG5vQ3VycmVudCBEbyBub3QgdXNlIHRoZSBjdXJyZW50IGNsYXNzIGlmIGNsYXNzTmFtZSBpcyBlbXB0eVxuICAgICAqXG4gICAgICogQHJldHVybiBzdHJpbmdcbiAgICAjIyNcbiAgICBnZXRGdWxsQ2xhc3NOYW1lOiAoZWRpdG9yLCBjbGFzc05hbWUgPSBudWxsLCBub0N1cnJlbnQgPSBmYWxzZSkgLT5cbiAgICAgICAgaWYgY2xhc3NOYW1lID09IG51bGxcbiAgICAgICAgICAgIGNsYXNzTmFtZSA9ICcnXG5cbiAgICAgICAgICAgIGlmIG5vQ3VycmVudFxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsXG5cbiAgICAgICAgaWYgY2xhc3NOYW1lIGFuZCBjbGFzc05hbWVbMF0gPT0gXCJcXFxcXCJcbiAgICAgICAgICAgIHJldHVybiBjbGFzc05hbWUuc3Vic3RyKDEpICMgRlFDTiwgbm90IHN1YmplY3QgdG8gYW55IGZ1cnRoZXIgY29udGV4dC5cblxuICAgICAgICB1c2VQYXR0ZXJuID0gLyg/OnVzZSkoPzpbXlxcd1xcXFxcXFxcXSkoW1xcd1xcXFxcXFxcXSspKD8hW1xcd1xcXFxcXFxcXSkoPzooPzpbIF0rYXNbIF0rKShcXHcrKSk/KD86OykvXG4gICAgICAgIG5hbWVzcGFjZVBhdHRlcm4gPSAvKD86bmFtZXNwYWNlKSg/OlteXFx3XFxcXFxcXFxdKShbXFx3XFxcXFxcXFxdKykoPyFbXFx3XFxcXFxcXFxdKSg/OjspL1xuICAgICAgICBkZWZpbml0aW9uUGF0dGVybiA9IC8oPzphYnN0cmFjdCBjbGFzc3xjbGFzc3x0cmFpdHxpbnRlcmZhY2UpXFxzKyhcXHcrKS9cblxuICAgICAgICB0ZXh0ID0gZWRpdG9yLmdldFRleHQoKVxuXG4gICAgICAgIGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJylcbiAgICAgICAgZnVsbENsYXNzID0gY2xhc3NOYW1lXG5cbiAgICAgICAgZm91bmQgPSBmYWxzZVxuXG4gICAgICAgIGZvciBsaW5lLGkgaW4gbGluZXNcbiAgICAgICAgICAgIG1hdGNoZXMgPSBsaW5lLm1hdGNoKG5hbWVzcGFjZVBhdHRlcm4pXG5cbiAgICAgICAgICAgIGlmIG1hdGNoZXNcbiAgICAgICAgICAgICAgICBmdWxsQ2xhc3MgPSBtYXRjaGVzWzFdICsgJ1xcXFwnICsgY2xhc3NOYW1lXG5cbiAgICAgICAgICAgIGVsc2UgaWYgY2xhc3NOYW1lXG4gICAgICAgICAgICAgICAgbWF0Y2hlcyA9IGxpbmUubWF0Y2godXNlUGF0dGVybilcbiAgICAgICAgICAgICAgICBpZiBtYXRjaGVzXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZVBhcnRzID0gY2xhc3NOYW1lLnNwbGl0KCdcXFxcJylcbiAgICAgICAgICAgICAgICAgICAgaW1wb3J0TmFtZVBhcnRzID0gbWF0Y2hlc1sxXS5zcGxpdCgnXFxcXCcpXG5cbiAgICAgICAgICAgICAgICAgICAgaXNBbGlhc2VkSW1wb3J0ID0gaWYgbWF0Y2hlc1syXSB0aGVuIHRydWUgZWxzZSBmYWxzZVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIGNsYXNzTmFtZSA9PSBtYXRjaGVzWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICBmdWxsQ2xhc3MgPSBjbGFzc05hbWUgIyBBbHJlYWR5IGEgY29tcGxldGUgbmFtZVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzQWxpYXNlZEltcG9ydCBhbmQgbWF0Y2hlc1syXSA9PSBjbGFzc05hbWVQYXJ0c1swXSkgb3IgKCFpc0FsaWFzZWRJbXBvcnQgYW5kIGltcG9ydE5hbWVQYXJ0c1tpbXBvcnROYW1lUGFydHMubGVuZ3RoIC0gMV0gPT0gY2xhc3NOYW1lUGFydHNbMF0pXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3VuZCA9IHRydWVcblxuICAgICAgICAgICAgICAgICAgICAgICAgZnVsbENsYXNzID0gbWF0Y2hlc1sxXVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lUGFydHMgPSBjbGFzc05hbWVQYXJ0c1sxIC4uIGNsYXNzTmFtZVBhcnRzLmxlbmd0aF1cblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNsYXNzTmFtZVBhcnRzLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbENsYXNzICs9ICdcXFxcJyArIGNsYXNzTmFtZVBhcnRzLmpvaW4oJ1xcXFwnKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICBtYXRjaGVzID0gbGluZS5tYXRjaChkZWZpbml0aW9uUGF0dGVybilcblxuICAgICAgICAgICAgaWYgbWF0Y2hlc1xuICAgICAgICAgICAgICAgIGlmIG5vdCBjbGFzc05hbWVcbiAgICAgICAgICAgICAgICAgICAgZm91bmQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxDbGFzcyArPSBtYXRjaGVzWzFdXG5cbiAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICMgSW4gdGhlIGNsYXNzIG1hcCwgY2xhc3NlcyBuZXZlciBoYXZlIGEgbGVhZGluZyBzbGFzaC4gVGhlIGxlYWRpbmcgc2xhc2ggb25seSBpbmRpY2F0ZXMgdGhhdCBpbXBvcnQgcnVsZXMgb2ZcbiAgICAgICAgIyB0aGUgZmlsZSBkb24ndCBhcHBseSwgYnV0IGl0J3MgdXNlbGVzcyBhZnRlciB0aGF0LlxuICAgICAgICBpZiBmdWxsQ2xhc3MgYW5kIGZ1bGxDbGFzc1swXSA9PSAnXFxcXCdcbiAgICAgICAgICAgIGZ1bGxDbGFzcyA9IGZ1bGxDbGFzcy5zdWJzdHIoMSlcblxuICAgICAgICBpZiBub3QgZm91bmRcbiAgICAgICAgICAgICMgQXQgdGhpcyBwb2ludCwgdGhpcyBjb3VsZCBlaXRoZXIgYmUgYSBjbGFzcyBuYW1lIHJlbGF0aXZlIHRvIHRoZSBjdXJyZW50IG5hbWVzcGFjZSBvciBhIGZ1bGwgY2xhc3MgbmFtZVxuICAgICAgICAgICAgIyB3aXRob3V0IGEgbGVhZGluZyBzbGFzaC4gRm9yIGV4YW1wbGUsIEZvb1xcQmFyIGNvdWxkIGFsc28gYmUgcmVsYXRpdmUgKGUuZy4gTXlcXEZvb1xcQmFyKSwgaW4gd2hpY2ggY2FzZSBpdHNcbiAgICAgICAgICAgICMgYWJzb2x1dGUgcGF0aCBpcyBkZXRlcm1pbmVkIGJ5IHRoZSBuYW1lc3BhY2UgYW5kIHVzZSBzdGF0ZW1lbnRzIG9mIHRoZSBmaWxlIGNvbnRhaW5pbmcgaXQuXG4gICAgICAgICAgICBtZXRob2RzUmVxdWVzdCA9IHByb3h5Lm1ldGhvZHMoZnVsbENsYXNzKVxuXG4gICAgICAgICAgICBpZiBub3QgbWV0aG9kc1JlcXVlc3Q/LmZpbGVuYW1lXG4gICAgICAgICAgICAgICAgIyBUaGUgY2xhc3MsIGUuZy4gTXlcXEZvb1xcQmFyLCBkaWRuJ3QgZXhpc3QuIFdlIGNhbiBvbmx5IGFzc3VtZSBpdHMgYW4gYWJzb2x1dGUgcGF0aCwgdXNpbmcgYSBuYW1lc3BhY2VcbiAgICAgICAgICAgICAgICAjIHNldCB1cCBpbiBjb21wb3Nlci5qc29uLCB3aXRob3V0IGEgbGVhZGluZyBzbGFzaC5cbiAgICAgICAgICAgICAgICBmdWxsQ2xhc3MgPSBjbGFzc05hbWVcblxuICAgICAgICByZXR1cm4gZnVsbENsYXNzXG5cbiAgICAjIyMqXG4gICAgICogQWRkIHRoZSB1c2UgZm9yIHRoZSBnaXZlbiBjbGFzcyBpZiBub3QgYWxyZWFkeSBhZGRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yICAgICAgICAgICAgICAgICAgQXRvbSB0ZXh0IGVkaXRvci5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gICAgIGNsYXNzTmFtZSAgICAgICAgICAgICAgIE5hbWUgb2YgdGhlIGNsYXNzIHRvIGFkZC5cbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59ICAgIGFsbG93QWRkaXRpb25hbE5ld2xpbmVzIFdoZXRoZXIgdG8gYWxsb3cgYWRkaW5nIGFkZGl0aW9uYWwgbmV3bGluZXMgdG8gYXR0ZW1wdCB0byBncm91cCB1c2VcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlbWVudHMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtpbnR9ICAgICAgIFRoZSBhbW91bnQgb2YgbGluZXMgYWRkZWQgKGluY2x1ZGluZyBuZXdsaW5lcyksIHNvIHlvdSBjYW4gcmVsaWFibHkgYW5kIGVhc2lseSBvZmZzZXQgeW91clxuICAgICAqICAgICAgICAgICAgICAgICAgICAgcm93cy4gVGhpcyBjb3VsZCBiZSB6ZXJvIGlmIGEgdXNlIHN0YXRlbWVudCB3YXMgYWxyZWFkeSBwcmVzZW50LlxuICAgICMjI1xuICAgIGFkZFVzZUNsYXNzOiAoZWRpdG9yLCBjbGFzc05hbWUsIGFsbG93QWRkaXRpb25hbE5ld2xpbmVzKSAtPlxuICAgICAgICBpZiBjbGFzc05hbWUuc3BsaXQoJ1xcXFwnKS5sZW5ndGggPT0gMSBvciBjbGFzc05hbWUuaW5kZXhPZignXFxcXCcpID09IDBcbiAgICAgICAgICAgIHJldHVybiBudWxsXG5cbiAgICAgICAgYmVzdFVzZSA9IDBcbiAgICAgICAgYmVzdFNjb3JlID0gMFxuICAgICAgICBwbGFjZUJlbG93ID0gdHJ1ZVxuICAgICAgICBkb05ld0xpbmUgPSB0cnVlXG4gICAgICAgIGxpbmVDb3VudCA9IGVkaXRvci5nZXRMaW5lQ291bnQoKVxuXG4gICAgICAgICMgRGV0ZXJtaW5lIGFuIGFwcHJvcHJpYXRlIGxvY2F0aW9uIHRvIHBsYWNlIHRoZSB1c2Ugc3RhdGVtZW50LlxuICAgICAgICBmb3IgaSBpbiBbMCAuLiBsaW5lQ291bnQgLSAxXVxuICAgICAgICAgICAgbGluZSA9IGVkaXRvci5saW5lVGV4dEZvckJ1ZmZlclJvdyhpKS50cmltKClcblxuICAgICAgICAgICAgaWYgbGluZS5sZW5ndGggPT0gMFxuICAgICAgICAgICAgICAgIGNvbnRpbnVlXG5cbiAgICAgICAgICAgIHNjb3BlRGVzY3JpcHRvciA9IGVkaXRvci5zY29wZURlc2NyaXB0b3JGb3JCdWZmZXJQb3NpdGlvbihbaSwgbGluZS5sZW5ndGhdKS5nZXRTY29wZUNoYWluKClcblxuICAgICAgICAgICAgaWYgc2NvcGVEZXNjcmlwdG9yLmluZGV4T2YoJy5jb21tZW50JykgPj0gMFxuICAgICAgICAgICAgICAgIGNvbnRpbnVlXG5cbiAgICAgICAgICAgIGlmIGxpbmUubWF0Y2goQHN0cnVjdHVyZVN0YXJ0UmVnZXgpXG4gICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgaWYgbGluZS5pbmRleE9mKCduYW1lc3BhY2UgJykgPj0gMFxuICAgICAgICAgICAgICAgIGJlc3RVc2UgPSBpXG5cbiAgICAgICAgICAgIG1hdGNoZXMgPSBAdXNlU3RhdGVtZW50UmVnZXguZXhlYyhsaW5lKVxuXG4gICAgICAgICAgICBpZiBtYXRjaGVzPyBhbmQgbWF0Y2hlc1sxXT9cbiAgICAgICAgICAgICAgICBpZiBtYXRjaGVzWzFdID09IGNsYXNzTmFtZVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMFxuXG4gICAgICAgICAgICAgICAgc2NvcmUgPSBAc2NvcmVDbGFzc05hbWUoY2xhc3NOYW1lLCBtYXRjaGVzWzFdKVxuXG4gICAgICAgICAgICAgICAgaWYgc2NvcmUgPj0gYmVzdFNjb3JlXG4gICAgICAgICAgICAgICAgICAgIGJlc3RVc2UgPSBpXG4gICAgICAgICAgICAgICAgICAgIGJlc3RTY29yZSA9IHNjb3JlXG5cbiAgICAgICAgICAgICAgICAgICAgaWYgQGRvU2hhcmVDb21tb25OYW1lc3BhY2VQcmVmaXgoY2xhc3NOYW1lLCBtYXRjaGVzWzFdKVxuICAgICAgICAgICAgICAgICAgICAgICAgZG9OZXdMaW5lID0gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlQmVsb3cgPSBpZiBjbGFzc05hbWUubGVuZ3RoID49IG1hdGNoZXNbMV0ubGVuZ3RoIHRoZW4gdHJ1ZSBlbHNlIGZhbHNlXG5cbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgZG9OZXdMaW5lID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VCZWxvdyA9IHRydWVcblxuICAgICAgICAjIEluc2VydCB0aGUgdXNlIHN0YXRlbWVudCBpdHNlbGYuXG4gICAgICAgIGxpbmVFbmRpbmcgPSBlZGl0b3IuZ2V0QnVmZmVyKCkubGluZUVuZGluZ0ZvclJvdygwKVxuXG4gICAgICAgIGlmIG5vdCBhbGxvd0FkZGl0aW9uYWxOZXdsaW5lc1xuICAgICAgICAgICAgZG9OZXdMaW5lID0gZmFsc2VcblxuICAgICAgICBpZiBub3QgbGluZUVuZGluZ1xuICAgICAgICAgICAgbGluZUVuZGluZyA9IFwiXFxuXCJcblxuICAgICAgICB0ZXh0VG9JbnNlcnQgPSAnJ1xuXG4gICAgICAgIGlmIGRvTmV3TGluZSBhbmQgcGxhY2VCZWxvd1xuICAgICAgICAgICAgdGV4dFRvSW5zZXJ0ICs9IGxpbmVFbmRpbmdcblxuICAgICAgICB0ZXh0VG9JbnNlcnQgKz0gXCJ1c2UgI3tjbGFzc05hbWV9O1wiICsgbGluZUVuZGluZ1xuXG4gICAgICAgIGlmIGRvTmV3TGluZSBhbmQgbm90IHBsYWNlQmVsb3dcbiAgICAgICAgICAgIHRleHRUb0luc2VydCArPSBsaW5lRW5kaW5nXG5cbiAgICAgICAgbGluZVRvSW5zZXJ0QXQgPSBiZXN0VXNlICsgKGlmIHBsYWNlQmVsb3cgdGhlbiAxIGVsc2UgMClcbiAgICAgICAgZWRpdG9yLnNldFRleHRJbkJ1ZmZlclJhbmdlKFtbbGluZVRvSW5zZXJ0QXQsIDBdLCBbbGluZVRvSW5zZXJ0QXQsIDBdXSwgdGV4dFRvSW5zZXJ0KVxuXG4gICAgICAgIHJldHVybiAoMSArIChpZiBkb05ld0xpbmUgdGhlbiAxIGVsc2UgMCkpXG5cbiAgICAjIyMqXG4gICAgICogUmV0dXJucyBhIGJvb2xlYW4gaW5kaWNhdGluZyBpZiB0aGUgc3BlY2lmaWVkIGNsYXNzIG5hbWVzIHNoYXJlIGEgY29tbW9uIG5hbWVzcGFjZSBwcmVmaXguXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmlyc3RDbGFzc05hbWVcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2Vjb25kQ2xhc3NOYW1lXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufVxuICAgICMjI1xuICAgIGRvU2hhcmVDb21tb25OYW1lc3BhY2VQcmVmaXg6IChmaXJzdENsYXNzTmFtZSwgc2Vjb25kQ2xhc3NOYW1lKSAtPlxuICAgICAgICBmaXJzdENsYXNzTmFtZVBhcnRzID0gZmlyc3RDbGFzc05hbWUuc3BsaXQoJ1xcXFwnKVxuICAgICAgICBzZWNvbmRDbGFzc05hbWVQYXJ0cyA9IHNlY29uZENsYXNzTmFtZS5zcGxpdCgnXFxcXCcpXG5cbiAgICAgICAgZmlyc3RDbGFzc05hbWVQYXJ0cy5wb3AoKVxuICAgICAgICBzZWNvbmRDbGFzc05hbWVQYXJ0cy5wb3AoKVxuXG4gICAgICAgIHJldHVybiBpZiBmaXJzdENsYXNzTmFtZVBhcnRzLmpvaW4oJ1xcXFwnKSA9PSBzZWNvbmRDbGFzc05hbWVQYXJ0cy5qb2luKCdcXFxcJykgdGhlbiB0cnVlIGVsc2UgZmFsc2VcblxuXG4gICAgIyMjKlxuICAgICAqIFNjb3JlcyB0aGUgZmlyc3QgY2xhc3MgbmFtZSBhZ2FpbnN0IHRoZSBzZWNvbmQsIGluZGljYXRpbmcgaG93IG11Y2ggdGhleSAnbWF0Y2gnIGVhY2ggb3RoZXIuIFRoaXMgY2FuIGJlIHVzZWRcbiAgICAgKiB0byBlLmcuIGZpbmQgYW4gYXBwcm9wcmlhdGUgbG9jYXRpb24gdG8gcGxhY2UgYSBjbGFzcyBpbiBhbiBleGlzdGluZyBsaXN0IG9mIGNsYXNzZXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmlyc3RDbGFzc05hbWVcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2Vjb25kQ2xhc3NOYW1lXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtmbG9hdH1cbiAgICAjIyNcbiAgICBzY29yZUNsYXNzTmFtZTogKGZpcnN0Q2xhc3NOYW1lLCBzZWNvbmRDbGFzc05hbWUpIC0+XG4gICAgICAgIGZpcnN0Q2xhc3NOYW1lUGFydHMgPSBmaXJzdENsYXNzTmFtZS5zcGxpdCgnXFxcXCcpXG4gICAgICAgIHNlY29uZENsYXNzTmFtZVBhcnRzID0gc2Vjb25kQ2xhc3NOYW1lLnNwbGl0KCdcXFxcJylcblxuICAgICAgICBtYXhMZW5ndGggPSAwXG5cbiAgICAgICAgaWYgZmlyc3RDbGFzc05hbWVQYXJ0cy5sZW5ndGggPiBzZWNvbmRDbGFzc05hbWVQYXJ0cy5sZW5ndGhcbiAgICAgICAgICAgIG1heExlbmd0aCA9IHNlY29uZENsYXNzTmFtZVBhcnRzLmxlbmd0aFxuXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIG1heExlbmd0aCA9IGZpcnN0Q2xhc3NOYW1lUGFydHMubGVuZ3RoXG5cbiAgICAgICAgdG90YWxTY29yZSA9IDBcblxuICAgICAgICAjIE5PVEU6IFdlIGRvbid0IHNjb3JlIHRoZSBsYXN0IHBhcnQuXG4gICAgICAgIGZvciBpIGluIFswIC4uIG1heExlbmd0aCAtIDJdXG4gICAgICAgICAgICBpZiBmaXJzdENsYXNzTmFtZVBhcnRzW2ldID09IHNlY29uZENsYXNzTmFtZVBhcnRzW2ldXG4gICAgICAgICAgICAgICAgdG90YWxTY29yZSArPSAyXG5cbiAgICAgICAgaWYgQGRvU2hhcmVDb21tb25OYW1lc3BhY2VQcmVmaXgoZmlyc3RDbGFzc05hbWUsIHNlY29uZENsYXNzTmFtZSlcbiAgICAgICAgICAgIGlmIGZpcnN0Q2xhc3NOYW1lLmxlbmd0aCA9PSBzZWNvbmRDbGFzc05hbWUubGVuZ3RoXG4gICAgICAgICAgICAgICAgdG90YWxTY29yZSArPSAyXG5cbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAjIFN0aWNrIGNsb3NlciB0byBpdGVtcyB0aGF0IGFyZSBzbWFsbGVyIGluIGxlbmd0aCB0aGFuIGl0ZW1zIHRoYXQgYXJlIGxhcmdlciBpbiBsZW5ndGguXG4gICAgICAgICAgICAgICAgdG90YWxTY29yZSAtPSAwLjAwMSAqIE1hdGguYWJzKHNlY29uZENsYXNzTmFtZS5sZW5ndGggLSBmaXJzdENsYXNzTmFtZS5sZW5ndGgpXG5cbiAgICAgICAgcmV0dXJuIHRvdGFsU2NvcmVcblxuICAgICMjIypcbiAgICAgKiBDaGVja3MgaWYgdGhlIGdpdmVuIG5hbWUgaXMgYSBjbGFzcyBvciBub3RcbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9ICBuYW1lIE5hbWUgdG8gY2hlY2tcbiAgICAgKiBAcmV0dXJuIHtCb29sZWFufVxuICAgICMjI1xuICAgIGlzQ2xhc3M6IChuYW1lKSAtPlxuICAgICAgICByZXR1cm4gbmFtZS5zdWJzdHIoMCwxKS50b1VwcGVyQ2FzZSgpICsgbmFtZS5zdWJzdHIoMSkgPT0gbmFtZVxuXG4gICAgIyMjKlxuICAgICAqIENoZWNrcyBpZiB0aGUgY3VycmVudCBidWZmZXIgaXMgaW4gYSBmdW5jdG9uIG9yIG5vdFxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yICAgICAgICAgQXRvbSB0ZXh0IGVkaXRvclxuICAgICAqIEBwYXJhbSB7UmFuZ2V9ICAgICAgYnVmZmVyUG9zaXRpb24gUG9zaXRpb24gb2YgdGhlIGN1cnJlbnQgYnVmZmVyXG4gICAgICogQHJldHVybiBib29sXG4gICAgIyMjXG4gICAgaXNJbkZ1bmN0aW9uOiAoZWRpdG9yLCBidWZmZXJQb3NpdGlvbikgLT5cbiAgICAgICAgdGV4dCA9IGVkaXRvci5nZXRUZXh0SW5CdWZmZXJSYW5nZShbWzAsIDBdLCBidWZmZXJQb3NpdGlvbl0pXG5cbiAgICAgICAgIyBJZiBsYXN0IHJlcXVlc3Qgd2FzIHRoZSBzYW1lXG4gICAgICAgIGlmIEBjYWNoZVt0ZXh0XT9cbiAgICAgICAgICByZXR1cm4gQGNhY2hlW3RleHRdXG5cbiAgICAgICAgIyBSZWluaXRpYWxpemUgY3VycmVudCBjYWNoZVxuICAgICAgICBAY2FjaGUgPSBbXVxuXG4gICAgICAgIHJvdyA9IGJ1ZmZlclBvc2l0aW9uLnJvd1xuICAgICAgICByb3dzID0gdGV4dC5zcGxpdCgnXFxuJylcblxuICAgICAgICBvcGVuZWRCbG9ja3MgPSAwXG4gICAgICAgIGNsb3NlZEJsb2NrcyA9IDBcblxuICAgICAgICByZXN1bHQgPSBmYWxzZVxuXG4gICAgICAgICMgZm9yIGVhY2ggcm93XG4gICAgICAgIHdoaWxlIHJvdyAhPSAtMVxuICAgICAgICAgICAgbGluZSA9IHJvd3Nbcm93XVxuXG4gICAgICAgICAgICAjIGlzc3VlICM2MVxuICAgICAgICAgICAgaWYgbm90IGxpbmVcbiAgICAgICAgICAgICAgICByb3ctLVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlXG5cbiAgICAgICAgICAgIGNoYXJhY3RlciA9IDBcbiAgICAgICAgICAgIGxpbmVMZW5ndGggPSBsaW5lLmxlbmd0aFxuICAgICAgICAgICAgbGFzdENoYWluID0gbnVsbFxuXG4gICAgICAgICAgICAjIFNjYW4gdGhlIGVudGlyZSBsaW5lLCBmZXRjaGluZyB0aGUgc2NvcGUgZm9yIGVhY2ggY2hhcmFjdGVyIHBvc2l0aW9uIGFzIG9uZSBsaW5lIGNhbiBjb250YWluIGJvdGggYSBzY29wZSBzdGFydFxuICAgICAgICAgICAgIyBhbmQgZW5kIHN1Y2ggYXMgXCJ9IGVsc2VpZiAodHJ1ZSkge1wiLiBIZXJlIHRoZSBzY29wZSBkZXNjcmlwdG9yIHdpbGwgZGlmZmVyIGZvciBkaWZmZXJlbnQgY2hhcmFjdGVyIHBvc2l0aW9ucyBvblxuICAgICAgICAgICAgIyB0aGUgbGluZS5cbiAgICAgICAgICAgIHdoaWxlIGNoYXJhY3RlciA8PSBsaW5lLmxlbmd0aFxuICAgICAgICAgICAgICAgICMgR2V0IGNoYWluIG9mIGFsbCBzY29wZXNcbiAgICAgICAgICAgICAgICBjaGFpbiA9IGVkaXRvci5zY29wZURlc2NyaXB0b3JGb3JCdWZmZXJQb3NpdGlvbihbcm93LCBjaGFyYWN0ZXJdKS5nZXRTY29wZUNoYWluKClcblxuICAgICAgICAgICAgICAgICMgTk9URTogQXRvbSBxdWlyazogYm90aCBsaW5lLmxlbmd0aCBhbmQgbGluZS5sZW5ndGggLSAxIHJldHVybiB0aGUgc2FtZSBzY29wZSBkZXNjcmlwdG9yLCBCVVQgeW91IGNhbid0IHNraXBcbiAgICAgICAgICAgICAgICAjIHNjYW5uaW5nIGxpbmUubGVuZ3RoIGFzIHNvbWV0aW1lcyBsaW5lLmxlbmd0aCAtIDEgZG9lcyBub3QgcmV0dXJuIGEgc2NvcGUgZGVzY3JpcHRvciBhdCBhbGwuXG4gICAgICAgICAgICAgICAgaWYgbm90IChjaGFyYWN0ZXIgPT0gbGluZS5sZW5ndGggYW5kIGNoYWluID09IGxhc3RDaGFpbilcbiAgICAgICAgICAgICAgICAgICAgIyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIGNoYWluLmluZGV4T2YoXCJzY29wZS5lbmRcIikgIT0gLTFcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsb3NlZEJsb2NrcysrXG4gICAgICAgICAgICAgICAgICAgICMge1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIGNoYWluLmluZGV4T2YoXCJzY29wZS5iZWdpblwiKSAhPSAtMVxuICAgICAgICAgICAgICAgICAgICAgICAgb3BlbmVkQmxvY2tzKytcblxuICAgICAgICAgICAgICAgIGxhc3RDaGFpbiA9IGNoYWluXG4gICAgICAgICAgICAgICAgY2hhcmFjdGVyKytcblxuICAgICAgICAgICAgIyBHZXQgY2hhaW4gb2YgYWxsIHNjb3Blc1xuICAgICAgICAgICAgY2hhaW4gPSBlZGl0b3Iuc2NvcGVEZXNjcmlwdG9yRm9yQnVmZmVyUG9zaXRpb24oW3JvdywgbGluZS5sZW5ndGhdKS5nZXRTY29wZUNoYWluKClcblxuICAgICAgICAgICAgIyBmdW5jdGlvblxuICAgICAgICAgICAgaWYgY2hhaW4uaW5kZXhPZihcImZ1bmN0aW9uXCIpICE9IC0xXG4gICAgICAgICAgICAgICAgIyBJZiBtb3JlIG9wZW5lZGJsb2NrcyB0aGFuIGNsb3NlZGJsb2Nrcywgd2UgYXJlIGluIGEgZnVuY3Rpb24uIE90aGVyd2lzZSwgY291bGQgYmUgYSBjbG9zdXJlLCBjb250aW51ZSBsb29raW5nLlxuICAgICAgICAgICAgICAgIGlmIG9wZW5lZEJsb2NrcyA+IGNsb3NlZEJsb2Nrc1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgIEBjYWNoZVtcImZ1bmN0aW9uUG9zaXRpb25cIl0gPSBbcm93LCAwXVxuXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgIHJvdy0tXG5cbiAgICAgICAgQGNhY2hlW3RleHRdID0gcmVzdWx0XG4gICAgICAgIHJldHVybiByZXN1bHRcblxuICAgICMjIypcbiAgICAgKiBSZXRyaWV2ZXMgdGhlIHN0YWNrIG9mIGVsZW1lbnRzIGluIGEgc3RhY2sgb2YgY2FsbHMgc3VjaCBhcyBcInNlbGY6Onh4eC0+eHh4eFwiLlxuICAgICAqXG4gICAgICogQHBhcmFtICB7VGV4dEVkaXRvcn0gZWRpdG9yXG4gICAgICogQHBhcmFtICB7UG9pbnR9ICAgICAgIHBvc2l0aW9uXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtPYmplY3R9XG4gICAgIyMjXG4gICAgZ2V0U3RhY2tDbGFzc2VzOiAoZWRpdG9yLCBwb3NpdGlvbikgLT5cbiAgICAgICAgcmV0dXJuIHVubGVzcyBwb3NpdGlvbj9cblxuICAgICAgICBsaW5lID0gcG9zaXRpb24ucm93XG5cbiAgICAgICAgZmluaXNoZWQgPSBmYWxzZVxuICAgICAgICBwYXJlbnRoZXNlc09wZW5lZCA9IDBcbiAgICAgICAgcGFyZW50aGVzZXNDbG9zZWQgPSAwXG4gICAgICAgIHNxdWlnZ2xlQnJhY2tldHNPcGVuZWQgPSAwXG4gICAgICAgIHNxdWlnZ2xlQnJhY2tldHNDbG9zZWQgPSAwXG5cbiAgICAgICAgd2hpbGUgbGluZSA+IDBcbiAgICAgICAgICAgIGxpbmVUZXh0ID0gZWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KGxpbmUpXG4gICAgICAgICAgICByZXR1cm4gdW5sZXNzIGxpbmVUZXh0XG5cbiAgICAgICAgICAgIGlmIGxpbmUgIT0gcG9zaXRpb24ucm93XG4gICAgICAgICAgICAgICAgaSA9IChsaW5lVGV4dC5sZW5ndGggLSAxKVxuXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgaSA9IHBvc2l0aW9uLmNvbHVtbiAtIDFcblxuICAgICAgICAgICAgd2hpbGUgaSA+PSAwXG4gICAgICAgICAgICAgICAgaWYgbGluZVRleHRbaV0gPT0gJygnXG4gICAgICAgICAgICAgICAgICAgICsrcGFyZW50aGVzZXNPcGVuZWRcblxuICAgICAgICAgICAgICAgICAgICAjIFRpY2tldCAjMTY0IC0gV2UncmUgd2Fsa2luZyBiYWNrd2FyZHMsIGlmIHdlIGZpbmQgYW4gb3BlbmluZyBwYXJhbnRoZXNpcyB0aGF0IGhhc24ndCBiZWVuIGNsb3NlZFxuICAgICAgICAgICAgICAgICAgICAjIGFueXdoZXJlLCB3ZSBrbm93IHdlIG11c3Qgc3RvcC5cbiAgICAgICAgICAgICAgICAgICAgaWYgcGFyZW50aGVzZXNPcGVuZWQgPiBwYXJlbnRoZXNlc0Nsb3NlZFxuICAgICAgICAgICAgICAgICAgICAgICAgKytpXG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5pc2hlZCA9IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICBlbHNlIGlmIGxpbmVUZXh0W2ldID09ICcpJ1xuICAgICAgICAgICAgICAgICAgICArK3BhcmVudGhlc2VzQ2xvc2VkXG5cbiAgICAgICAgICAgICAgICBlbHNlIGlmIGxpbmVUZXh0W2ldID09ICd7J1xuICAgICAgICAgICAgICAgICAgICArK3NxdWlnZ2xlQnJhY2tldHNPcGVuZWRcblxuICAgICAgICAgICAgICAgICAgICAjIFNhbWUgYXMgYWJvdmUuXG4gICAgICAgICAgICAgICAgICAgIGlmIHNxdWlnZ2xlQnJhY2tldHNPcGVuZWQgPiBzcXVpZ2dsZUJyYWNrZXRzQ2xvc2VkXG4gICAgICAgICAgICAgICAgICAgICAgICArK2lcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbmlzaGVkID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgIGVsc2UgaWYgbGluZVRleHRbaV0gPT0gJ30nXG4gICAgICAgICAgICAgICAgICAgICsrc3F1aWdnbGVCcmFja2V0c0Nsb3NlZFxuXG4gICAgICAgICAgICAgICAgIyBUaGVzZSB3aWxsIG5vdCBiZSB0aGUgc2FtZSBpZiwgZm9yIGV4YW1wbGUsIHdlJ3ZlIGVudGVyZWQgYSBjbG9zdXJlLlxuICAgICAgICAgICAgICAgIGVsc2UgaWYgcGFyZW50aGVzZXNPcGVuZWQgPT0gcGFyZW50aGVzZXNDbG9zZWQgYW5kIHNxdWlnZ2xlQnJhY2tldHNPcGVuZWQgPT0gc3F1aWdnbGVCcmFja2V0c0Nsb3NlZFxuICAgICAgICAgICAgICAgICAgICAjIFZhcmlhYmxlIGRlZmluaXRpb24uXG4gICAgICAgICAgICAgICAgICAgIGlmIGxpbmVUZXh0W2ldID09ICckJ1xuICAgICAgICAgICAgICAgICAgICAgICAgZmluaXNoZWQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgbGluZVRleHRbaV0gPT0gJzsnIG9yIGxpbmVUZXh0W2ldID09ICc9J1xuICAgICAgICAgICAgICAgICAgICAgICAgKytpXG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5pc2hlZCA9IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGVEZXNjcmlwdG9yID0gZWRpdG9yLnNjb3BlRGVzY3JpcHRvckZvckJ1ZmZlclBvc2l0aW9uKFtsaW5lLCBpXSkuZ2V0U2NvcGVDaGFpbigpXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICMgTGFuZ3VhZ2UgY29uc3RydWN0cywgc3VjaCBhcyBlY2hvIGFuZCBwcmludCwgZG9uJ3QgcmVxdWlyZSBwYXJhbnRoZXNlcy5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIHNjb3BlRGVzY3JpcHRvci5pbmRleE9mKCcuZnVuY3Rpb24uY29uc3RydWN0JykgPiAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKytpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmluaXNoZWQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgIC0taVxuXG4gICAgICAgICAgICBpZiBmaW5pc2hlZFxuICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgIC0tbGluZVxuXG4gICAgICAgICMgRmV0Y2ggZXZlcnl0aGluZyB3ZSByYW4gdGhyb3VnaCB1cCB1bnRpbCB0aGUgbG9jYXRpb24gd2Ugc3RhcnRlZCBmcm9tLlxuICAgICAgICB0ZXh0U2xpY2UgPSBlZGl0b3IuZ2V0VGV4dEluQnVmZmVyUmFuZ2UoW1tsaW5lLCBpXSwgcG9zaXRpb25dKS50cmltKClcblxuICAgICAgICByZXR1cm4gQHBhcnNlU3RhY2tDbGFzcyh0ZXh0U2xpY2UpXG5cbiAgICAjIyMqXG4gICAgICogUmVtb3ZlcyBjb250ZW50IGluc2lkZSBwYXJhbnRoZXNlcyAoaW5jbHVkaW5nIG5lc3RlZCBwYXJhbnRoZXNlcykuXG4gICAgICogQHBhcmFtIHtzdHJpbmd9ICB0ZXh0IFN0cmluZyB0byBhbmFseXplLlxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0ga2VlcCBzdHJpbmcgaW5zaWRlIHBhcmVudGhlc2lzXG4gICAgICogQHJldHVybiBTdHJpbmdcbiAgICAjIyNcbiAgICBzdHJpcFBhcmFudGhlc2VzQ29udGVudDogKHRleHQsIGtlZXBTdHJpbmcpIC0+XG4gICAgICAgIGkgPSAwXG4gICAgICAgIG9wZW5Db3VudCA9IDBcbiAgICAgICAgY2xvc2VDb3VudCA9IDBcbiAgICAgICAgc3RhcnRJbmRleCA9IC0xXG5cbiAgICAgICAgd2hpbGUgaSA8IHRleHQubGVuZ3RoXG4gICAgICAgICAgICBpZiB0ZXh0W2ldID09ICcoJ1xuICAgICAgICAgICAgICAgICsrb3BlbkNvdW50XG5cbiAgICAgICAgICAgICAgICBpZiBvcGVuQ291bnQgPT0gMVxuICAgICAgICAgICAgICAgICAgICBzdGFydEluZGV4ID0gaVxuXG4gICAgICAgICAgICBlbHNlIGlmIHRleHRbaV0gPT0gJyknXG4gICAgICAgICAgICAgICAgKytjbG9zZUNvdW50XG5cbiAgICAgICAgICAgICAgICBpZiBjbG9zZUNvdW50ID09IG9wZW5Db3VudFxuICAgICAgICAgICAgICAgICAgICBvcmlnaW5hbExlbmd0aCA9IHRleHQubGVuZ3RoXG5cbiAgICAgICAgICAgICAgICAgICAgY29udGVudCA9IHRleHQuc3Vic3RyaW5nKHN0YXJ0SW5kZXgsIGkrMSlcbiAgICAgICAgICAgICAgICAgICAgcmVnID0gL1tcIihdW1xcc10qW1xcJ1xcXCJdW1xcc10qKFteXFxcIlxcJ10rKVtcXHNdKltcXFwiXFwnXVtcXHNdKltcIildL2dcblxuICAgICAgICAgICAgICAgICAgICBpZiBvcGVuQ291bnQgPT0gMSBhbmQgcmVnLmV4ZWMoY29udGVudClcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlXG5cbiAgICAgICAgICAgICAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyKDAsIHN0YXJ0SW5kZXggKyAxKSArIHRleHQuc3Vic3RyKGksIHRleHQubGVuZ3RoKTtcblxuICAgICAgICAgICAgICAgICAgICBpIC09IChvcmlnaW5hbExlbmd0aCAtIHRleHQubGVuZ3RoKVxuXG4gICAgICAgICAgICAgICAgICAgIG9wZW5Db3VudCA9IDBcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VDb3VudCA9IDBcblxuICAgICAgICAgICAgKytpXG5cbiAgICAgICAgcmV0dXJuIHRleHRcblxuICAgICMjIypcbiAgICAgKiBQYXJzZSBzdGFjayBjbGFzcyBlbGVtZW50c1xuICAgICAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0IFN0cmluZyBvZiB0aGUgc3RhY2sgY2xhc3NcbiAgICAgKiBAcmV0dXJuIEFycmF5XG4gICAgIyMjXG4gICAgcGFyc2VTdGFja0NsYXNzOiAodGV4dCkgLT5cbiAgICAgICAgIyBSZW1vdmUgc2luZ2UgbGluZSBjb21tZW50c1xuICAgICAgICByZWd4ID0gL1xcL1xcLy4qXFxuL2dcbiAgICAgICAgdGV4dCA9IHRleHQucmVwbGFjZSByZWd4LCAobWF0Y2gpID0+XG4gICAgICAgICAgICByZXR1cm4gJydcblxuICAgICAgICAjIFJlbW92ZSBtdWx0aSBsaW5lIGNvbW1lbnRzXG4gICAgICAgIHJlZ3ggPSAvXFwvXFwqW14oXFwqXFwvKV0qXFwqXFwvL2dcbiAgICAgICAgdGV4dCA9IHRleHQucmVwbGFjZSByZWd4LCAobWF0Y2gpID0+XG4gICAgICAgICAgICByZXR1cm4gJydcblxuICAgICAgICAjIFJlbW92ZSBjb250ZW50IGluc2lkZSBwYXJhbnRoZXNlcyAoaW5jbHVkaW5nIG5lc3RlZCBwYXJhbnRoZXNlcykuXG4gICAgICAgIHRleHQgPSBAc3RyaXBQYXJhbnRoZXNlc0NvbnRlbnQodGV4dCwgdHJ1ZSlcblxuICAgICAgICAjIEdldCB0aGUgZnVsbCB0ZXh0XG4gICAgICAgIHJldHVybiBbXSBpZiBub3QgdGV4dFxuXG4gICAgICAgIGVsZW1lbnRzID0gdGV4dC5zcGxpdCgvKD86XFwtXFw+fDo6KS8pXG4gICAgICAgICMgZWxlbWVudHMgPSB0ZXh0LnNwbGl0KFwiLT5cIilcblxuICAgICAgICBpZiBlbGVtZW50cy5sZW5ndGggPT0gMVxuICAgICAgICAgIEBpc0Z1bmN0aW9uID0gdHJ1ZVxuICAgICAgICBlbHNlXG4gICAgICAgICAgQGlzRnVuY3Rpb24gPSBmYWxzZVxuXG4gICAgICAgICMgUmVtb3ZlIHBhcmVudGhlc2lzIGFuZCB3aGl0ZXNwYWNlc1xuICAgICAgICBmb3Iga2V5LCBlbGVtZW50IG9mIGVsZW1lbnRzXG4gICAgICAgICAgICBlbGVtZW50ID0gZWxlbWVudC5yZXBsYWNlIC9eXFxzK3xcXHMrJC9nLCBcIlwiXG4gICAgICAgICAgICBpZiBlbGVtZW50WzBdID09ICd7JyBvciBlbGVtZW50WzBdID09ICdbJ1xuICAgICAgICAgICAgICAgIGVsZW1lbnQgPSBlbGVtZW50LnN1YnN0cmluZygxKVxuICAgICAgICAgICAgZWxzZSBpZiBlbGVtZW50LmluZGV4T2YoJ3JldHVybiAnKSA9PSAwXG4gICAgICAgICAgICAgICAgZWxlbWVudCA9IGVsZW1lbnQuc3Vic3RyaW5nKCdyZXR1cm4gJy5sZW5ndGgpXG5cbiAgICAgICAgICAgIGVsZW1lbnRzW2tleV0gPSBlbGVtZW50XG5cbiAgICAgICAgcmV0dXJuIGVsZW1lbnRzXG5cbiAgICAjIyMqXG4gICAgICogR2V0IHRoZSB0eXBlIG9mIGEgdmFyaWFibGVcbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yXG4gICAgICogQHBhcmFtIHtSYW5nZX0gICAgICBidWZmZXJQb3NpdGlvblxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSAgICAgZWxlbWVudCAgICAgICAgVmFyaWFibGUgdG8gc2VhcmNoXG4gICAgIyMjXG4gICAgZ2V0VmFyaWFibGVUeXBlOiAoZWRpdG9yLCBidWZmZXJQb3NpdGlvbiwgZWxlbWVudCkgLT5cbiAgICAgICAgaWYgZWxlbWVudC5yZXBsYWNlKC9bXFwkXVthLXpBLVowLTlfXSsvZywgXCJcIikudHJpbSgpLmxlbmd0aCA+IDBcbiAgICAgICAgICAgIHJldHVybiBudWxsXG5cbiAgICAgICAgaWYgZWxlbWVudC50cmltKCkubGVuZ3RoID09IDBcbiAgICAgICAgICAgIHJldHVybiBudWxsXG5cbiAgICAgICAgYmVzdE1hdGNoID0gbnVsbFxuICAgICAgICBiZXN0TWF0Y2hSb3cgPSBudWxsXG5cbiAgICAgICAgIyBSZWdleCB2YXJpYWJsZSBkZWZpbml0aW9uXG4gICAgICAgIHJlZ2V4RWxlbWVudCA9IG5ldyBSZWdFeHAoXCJcXFxcI3tlbGVtZW50fVtcXFxcc10qPVtcXFxcc10qKFteO10rKTtcIiwgXCJnXCIpXG4gICAgICAgIHJlZ2V4TmV3SW5zdGFuY2UgPSBuZXcgUmVnRXhwKFwiXFxcXCN7ZWxlbWVudH1bXFxcXHNdKj1bXFxcXHNdKm5ld1tcXFxcc10qXFxcXFxcXFw/KFthLXpBLVpdW2EtekEtWl9cXFxcXFxcXF0qKSsoPzooLispPyk7XCIsIFwiZ1wiKVxuICAgICAgICByZWdleENhdGNoID0gbmV3IFJlZ0V4cChcImNhdGNoW1xcXFxzXSpcXFxcKFtcXFxcc10qKFtBLVphLXowLTlfXFxcXFxcXFxdKylbXFxcXHNdK1xcXFwje2VsZW1lbnR9W1xcXFxzXSpcXFxcKVwiLCBcImdcIilcblxuICAgICAgICBsaW5lTnVtYmVyID0gYnVmZmVyUG9zaXRpb24ucm93IC0gMVxuXG4gICAgICAgIHdoaWxlIGxpbmVOdW1iZXIgPiAwXG4gICAgICAgICAgICBsaW5lID0gZWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KGxpbmVOdW1iZXIpXG5cbiAgICAgICAgICAgIGlmIG5vdCBiZXN0TWF0Y2hcbiAgICAgICAgICAgICAgICAjIENoZWNrIGZvciAkeCA9IG5ldyBYWFhYWCgpXG4gICAgICAgICAgICAgICAgbWF0Y2hlc05ldyA9IHJlZ2V4TmV3SW5zdGFuY2UuZXhlYyhsaW5lKVxuXG4gICAgICAgICAgICAgICAgaWYgbnVsbCAhPSBtYXRjaGVzTmV3XG4gICAgICAgICAgICAgICAgICAgIGJlc3RNYXRjaFJvdyA9IGxpbmVOdW1iZXJcbiAgICAgICAgICAgICAgICAgICAgYmVzdE1hdGNoID0gQGdldEZ1bGxDbGFzc05hbWUoZWRpdG9yLCBtYXRjaGVzTmV3WzFdKVxuXG4gICAgICAgICAgICBpZiBub3QgYmVzdE1hdGNoXG4gICAgICAgICAgICAgICAgIyBDaGVjayBmb3IgY2F0Y2goWFhYICR4eHgpXG4gICAgICAgICAgICAgICAgbWF0Y2hlc0NhdGNoID0gcmVnZXhDYXRjaC5leGVjKGxpbmUpXG5cbiAgICAgICAgICAgICAgICBpZiBudWxsICE9IG1hdGNoZXNDYXRjaFxuICAgICAgICAgICAgICAgICAgICBiZXN0TWF0Y2hSb3cgPSBsaW5lTnVtYmVyXG4gICAgICAgICAgICAgICAgICAgIGJlc3RNYXRjaCA9IEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgbWF0Y2hlc0NhdGNoWzFdKVxuXG4gICAgICAgICAgICBpZiBub3QgYmVzdE1hdGNoXG4gICAgICAgICAgICAgICAgIyBDaGVjayBmb3IgYSB2YXJpYWJsZSBhc3NpZ25tZW50ICR4ID0gLi4uXG4gICAgICAgICAgICAgICAgbWF0Y2hlcyA9IHJlZ2V4RWxlbWVudC5leGVjKGxpbmUpXG5cbiAgICAgICAgICAgICAgICBpZiBudWxsICE9IG1hdGNoZXNcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBtYXRjaGVzWzFdXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRzID0gQHBhcnNlU3RhY2tDbGFzcyh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudHMucHVzaChcIlwiKSAjwqBQdXNoIG9uZSBtb3JlIGVsZW1lbnQgdG8gZ2V0IGZ1bGx5IHRoZSBsYXN0IGNsYXNzXG5cbiAgICAgICAgICAgICAgICAgICAgbmV3UG9zaXRpb24gPVxuICAgICAgICAgICAgICAgICAgICAgICAgcm93IDogbGluZU51bWJlclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uOiBidWZmZXJQb3NpdGlvbi5jb2x1bW5cblxuICAgICAgICAgICAgICAgICAgICAjIE5PVEU6IGJlc3RNYXRjaCBjb3VsZCBub3cgYmUgbnVsbCwgYnV0IHRoaXMgbGluZSBpcyBzdGlsbCB0aGUgY2xvc2VzdCBtYXRjaC4gVGhlIGZhY3QgdGhhdCB3ZVxuICAgICAgICAgICAgICAgICAgICAjIGRvbid0IHJlY29nbml6ZSB0aGUgY2xhc3MgbmFtZSBpcyBpcnJlbGV2YW50LlxuICAgICAgICAgICAgICAgICAgICBiZXN0TWF0Y2hSb3cgPSBsaW5lTnVtYmVyXG4gICAgICAgICAgICAgICAgICAgIGJlc3RNYXRjaCA9IEBwYXJzZUVsZW1lbnRzKGVkaXRvciwgbmV3UG9zaXRpb24sIGVsZW1lbnRzKVxuXG4gICAgICAgICAgICBpZiBub3QgYmVzdE1hdGNoXG4gICAgICAgICAgICAgICAgIyBDaGVjayBmb3IgZnVuY3Rpb24gb3IgY2xvc3VyZSBwYXJhbWV0ZXIgdHlwZSBoaW50cyBhbmQgdGhlIGRvY2Jsb2NrLlxuICAgICAgICAgICAgICAgIHJlZ2V4RnVuY3Rpb24gPSBuZXcgUmVnRXhwKFwiZnVuY3Rpb24oPzpbXFxcXHNdKyhbYS16QS1aXSspKT9bXFxcXHNdKltcXFxcKF0oPzooPyFbYS16QS1aXFxcXF9cXFxcXFxcXF0qW1xcXFxzXSpcXFxcI3tlbGVtZW50fSkuKSpbLFxcXFxzXT8oW2EtekEtWlxcXFxfXFxcXFxcXFxdKilbXFxcXHNdKlxcXFwje2VsZW1lbnR9W2EtekEtWjAtOVxcXFxzXFxcXCRcXFxcXFxcXCw9XFxcXFxcXCJcXFxcXFwnXFwoXFwpXSpbXFxcXHNdKltcXFxcKV1cIiwgXCJnXCIpXG4gICAgICAgICAgICAgICAgbWF0Y2hlcyA9IHJlZ2V4RnVuY3Rpb24uZXhlYyhsaW5lKVxuXG4gICAgICAgICAgICAgICAgaWYgbnVsbCAhPSBtYXRjaGVzXG4gICAgICAgICAgICAgICAgICAgIHR5cGVIaW50ID0gbWF0Y2hlc1syXVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIHR5cGVIaW50Lmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBAZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IsIHR5cGVIaW50KVxuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmNOYW1lID0gbWF0Y2hlc1sxXVxuXG4gICAgICAgICAgICAgICAgICAgICMgQ2FuIGJlIGVtcHR5IGZvciBjbG9zdXJlcy5cbiAgICAgICAgICAgICAgICAgICAgaWYgZnVuY05hbWUgYW5kIGZ1bmNOYW1lLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcyA9IHByb3h5LmRvY1BhcmFtcyhAZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IpLCBmdW5jTmFtZSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgcGFyYW1zLnBhcmFtcz8gYW5kIHBhcmFtcy5wYXJhbXNbZWxlbWVudF0/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgcGFyYW1zLnBhcmFtc1tlbGVtZW50XS50eXBlLCB0cnVlKVxuXG4gICAgICAgICAgICBjaGFpbiA9IGVkaXRvci5zY29wZURlc2NyaXB0b3JGb3JCdWZmZXJQb3NpdGlvbihbbGluZU51bWJlciwgbGluZS5sZW5ndGhdKS5nZXRTY29wZUNoYWluKClcblxuICAgICAgICAgICAgIyBBbm5vdGF0aW9ucyBpbiBjb21tZW50cyBjYW4gb3B0aW9uYWxseSBvdmVycmlkZSB0aGUgdmFyaWFibGUgdHlwZS5cbiAgICAgICAgICAgIGlmIGNoYWluLmluZGV4T2YoXCJjb21tZW50XCIpICE9IC0xXG4gICAgICAgICAgICAgICAgIyBDaGVjayBpZiB0aGUgbGluZSBiZWZvcmUgY29udGFpbnMgYSAvKiogQHZhciBGb29UeXBlICovLCB3aGljaCBvdmVycmlkZXMgdGhlIHR5cGUgb2YgdGhlIHZhcmlhYmxlXG4gICAgICAgICAgICAgICAgIyBpbW1lZGlhdGVseSBiZWxvdyBpdC4gVGhpcyB3aWxsIG5vdCBldmFsdWF0ZSB0byAvKiogQHZhciBGb29UeXBlICRzb21lVmFyICovIChzZWUgYmVsb3cgZm9yIHRoYXQpLlxuICAgICAgICAgICAgICAgIGlmIGJlc3RNYXRjaFJvdyBhbmQgbGluZU51bWJlciA9PSAoYmVzdE1hdGNoUm93IC0gMSlcbiAgICAgICAgICAgICAgICAgICAgcmVnZXhWYXIgPSAvXFxAdmFyW1xcc10rKFthLXpBLVpfXFxcXF0rKSg/IVtcXHddK1xcJCkvZ1xuICAgICAgICAgICAgICAgICAgICBtYXRjaGVzID0gcmVnZXhWYXIuZXhlYyhsaW5lKVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIG51bGwgIT0gbWF0Y2hlc1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgbWF0Y2hlc1sxXSlcblxuICAgICAgICAgICAgICAgICMgQ2hlY2sgaWYgdGhlcmUgaXMgYW4gUEhQU3Rvcm0tc3R5bGUgdHlwZSBpbmxpbmUgZG9jYmxvY2sgcHJlc2VudCAvKiogQHZhciBGb29UeXBlICRzb21lVmFyICovLlxuICAgICAgICAgICAgICAgIHJlZ2V4VmFyV2l0aFZhck5hbWUgPSBuZXcgUmVnRXhwKFwiXFxcXEB2YXJbXFxcXHNdKyhbYS16QS1aX1xcXFxcXFxcXSspW1xcXFxzXStcXFxcI3tlbGVtZW50fVwiLCBcImdcIilcbiAgICAgICAgICAgICAgICBtYXRjaGVzID0gcmVnZXhWYXJXaXRoVmFyTmFtZS5leGVjKGxpbmUpXG5cbiAgICAgICAgICAgICAgICBpZiBudWxsICE9IG1hdGNoZXNcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgbWF0Y2hlc1sxXSlcblxuICAgICAgICAgICAgICAgICMgQ2hlY2sgaWYgdGhlcmUgaXMgYW4gSW50ZWxsaUotc3R5bGUgdHlwZSBpbmxpbmUgZG9jYmxvY2sgcHJlc2VudCAvKiogQHZhciAkc29tZVZhciBGb29UeXBlICovLlxuICAgICAgICAgICAgICAgIHJlZ2V4VmFyV2l0aFZhck5hbWUgPSBuZXcgUmVnRXhwKFwiXFxcXEB2YXJbXFxcXHNdK1xcXFwje2VsZW1lbnR9W1xcXFxzXSsoW2EtekEtWl9cXFxcXFxcXF0rKVwiLCBcImdcIilcbiAgICAgICAgICAgICAgICBtYXRjaGVzID0gcmVnZXhWYXJXaXRoVmFyTmFtZS5leGVjKGxpbmUpXG5cbiAgICAgICAgICAgICAgICBpZiBudWxsICE9IG1hdGNoZXNcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgbWF0Y2hlc1sxXSlcblxuICAgICAgICAgICAgIyBXZSd2ZSByZWFjaGVkIHRoZSBmdW5jdGlvbiBkZWZpbml0aW9uLCBvdGhlciB2YXJpYWJsZXMgZG9uJ3QgYXBwbHkgdG8gdGhpcyBzY29wZS5cbiAgICAgICAgICAgIGlmIGNoYWluLmluZGV4T2YoXCJmdW5jdGlvblwiKSAhPSAtMVxuICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgIC0tbGluZU51bWJlclxuXG4gICAgICAgIHJldHVybiBiZXN0TWF0Y2hcblxuICAgICMjIypcbiAgICAgKiBSZXRyaWV2ZXMgY29udGV4dHVhbCBpbmZvcm1hdGlvbiBhYm91dCB0aGUgY2xhc3MgbWVtYmVyIGF0IHRoZSBzcGVjaWZpZWQgbG9jYXRpb24gaW4gdGhlIGVkaXRvci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yICAgICAgICAgVGV4dEVkaXRvciB0byBzZWFyY2ggZm9yIG5hbWVzcGFjZSBvZiB0ZXJtLlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSAgICAgdGVybSAgICAgICAgICAgVGVybSB0byBzZWFyY2ggZm9yLlxuICAgICAqIEBwYXJhbSB7UG9pbnR9ICAgICAgYnVmZmVyUG9zaXRpb24gVGhlIGN1cnNvciBsb2NhdGlvbiB0aGUgdGVybSBpcyBhdC5cbiAgICAgKiBAcGFyYW0ge09iamVjdH0gICAgIGNhbGxlZENsYXNzICAgIEluZm9ybWF0aW9uIGFib3V0IHRoZSBjYWxsZWQgY2xhc3MgKG9wdGlvbmFsKS5cbiAgICAjIyNcbiAgICBnZXRNZW1iZXJDb250ZXh0OiAoZWRpdG9yLCB0ZXJtLCBidWZmZXJQb3NpdGlvbiwgY2FsbGVkQ2xhc3MpIC0+XG4gICAgICAgIGlmIG5vdCBjYWxsZWRDbGFzc1xuICAgICAgICAgICAgY2FsbGVkQ2xhc3MgPSBAZ2V0Q2FsbGVkQ2xhc3MoZWRpdG9yLCB0ZXJtLCBidWZmZXJQb3NpdGlvbilcblxuICAgICAgICBpZiBub3QgY2FsbGVkQ2xhc3MgJiYgbm90IEBpc0Z1bmN0aW9uXG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgICBwcm94eSA9IHJlcXVpcmUgJy4uL3NlcnZpY2VzL3BocC1wcm94eS5jb2ZmZWUnXG4gICAgICAgIGlmIEBpc0Z1bmN0aW9uXG4gICAgICAgICAgbWV0aG9kcyA9IHByb3h5LmZ1bmN0aW9ucygpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBtZXRob2RzID0gcHJveHkubWV0aG9kcyhjYWxsZWRDbGFzcylcblxuICAgICAgICBpZiBub3QgbWV0aG9kcyB8fCBub3QgbWV0aG9kcz9cbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgIGlmIG1ldGhvZHMuZXJyb3I/IGFuZCBtZXRob2RzLmVycm9yICE9ICcnXG4gICAgICAgICAgICBpZiBjb25maWcuY29uZmlnLnZlcmJvc2VFcnJvcnNcbiAgICAgICAgICAgICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkRXJyb3IoJ0ZhaWxlZCB0byBnZXQgbWV0aG9kcyBmb3IgJyArIGNhbGxlZENsYXNzLCB7XG4gICAgICAgICAgICAgICAgICAgICdkZXRhaWwnOiBtZXRob2RzLmVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nICdGYWlsZWQgdG8gZ2V0IG1ldGhvZHMgZm9yICcgKyBjYWxsZWRDbGFzcyArICcgOiAnICsgbWV0aG9kcy5lcnJvci5tZXNzYWdlXG5cbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICBpZiAhbWV0aG9kcy52YWx1ZXM/Lmhhc093blByb3BlcnR5KHRlcm0pXG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgICB2YWx1ZSA9IG1ldGhvZHMudmFsdWVzW3Rlcm1dXG5cbiAgICAgICAgIyBJZiB0aGVyZSBhcmUgbXVsdGlwbGUgbWF0Y2hlcywganVzdCBzZWxlY3QgdGhlIGZpcnN0IG1ldGhvZC5cbiAgICAgICAgaWYgdmFsdWUgaW5zdGFuY2VvZiBBcnJheVxuICAgICAgICAgICAgZm9yIHZhbCBpbiB2YWx1ZVxuICAgICAgICAgICAgICAgIGlmIHZhbC5pc01ldGhvZFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IHZhbFxuICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgIHJldHVybiB2YWx1ZVxuXG4gICAgIyMjKlxuICAgICAqIFBhcnNlIGFsbCBlbGVtZW50cyBmcm9tIHRoZSBnaXZlbiBhcnJheSB0byByZXR1cm4gdGhlIGxhc3QgY2xhc3NOYW1lIChpZiBhbnkpXG4gICAgICogQHBhcmFtICBBcnJheSBlbGVtZW50cyBFbGVtZW50cyB0byBwYXJzZVxuICAgICAqIEByZXR1cm4gc3RyaW5nfG51bGwgZnVsbCBjbGFzcyBuYW1lIG9mIHRoZSBsYXN0IGVsZW1lbnRcbiAgICAjIyNcbiAgICBwYXJzZUVsZW1lbnRzOiAoZWRpdG9yLCBidWZmZXJQb3NpdGlvbiwgZWxlbWVudHMpIC0+XG4gICAgICAgIGxvb3BfaW5kZXggPSAwXG4gICAgICAgIGNsYXNzTmFtZSAgPSBudWxsXG4gICAgICAgIGlmIG5vdCBlbGVtZW50cz9cbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgIGZvciBlbGVtZW50IGluIGVsZW1lbnRzXG4gICAgICAgICAgICAjICR0aGlzIGtleXdvcmRcbiAgICAgICAgICAgIGlmIGxvb3BfaW5kZXggPT0gMFxuICAgICAgICAgICAgICAgIGlmIGVsZW1lbnRbMF0gPT0gJyQnXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZSA9IEBnZXRWYXJpYWJsZVR5cGUoZWRpdG9yLCBidWZmZXJQb3NpdGlvbiwgZWxlbWVudClcblxuICAgICAgICAgICAgICAgICAgICAjIE5PVEU6IFRoZSB0eXBlIG9mICR0aGlzIGNhbiBhbHNvIGJlIG92ZXJyaWRkZW4gbG9jYWxseSBieSBhIGRvY2Jsb2NrLlxuICAgICAgICAgICAgICAgICAgICBpZiBlbGVtZW50ID09ICckdGhpcycgYW5kIG5vdCBjbGFzc05hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZSA9IEBnZXRGdWxsQ2xhc3NOYW1lKGVkaXRvcilcblxuICAgICAgICAgICAgICAgICAgICBsb29wX2luZGV4KytcbiAgICAgICAgICAgICAgICAgICAgY29udGludWVcblxuICAgICAgICAgICAgICAgIGVsc2UgaWYgZWxlbWVudCA9PSAnc3RhdGljJyBvciBlbGVtZW50ID09ICdzZWxmJ1xuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWUgPSBAZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IpXG4gICAgICAgICAgICAgICAgICAgIGxvb3BfaW5kZXgrK1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZVxuXG4gICAgICAgICAgICAgICAgZWxzZSBpZiBlbGVtZW50ID09ICdwYXJlbnQnXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZSA9IEBnZXRQYXJlbnRDbGFzcyhlZGl0b3IpXG4gICAgICAgICAgICAgICAgICAgIGxvb3BfaW5kZXgrK1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZVxuXG4gICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWUgPSBAZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IsIGVsZW1lbnQpXG4gICAgICAgICAgICAgICAgICAgIGxvb3BfaW5kZXgrK1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZVxuXG4gICAgICAgICAgICAjIExhc3QgZWxlbWVudFxuICAgICAgICAgICAgaWYgbG9vcF9pbmRleCA+PSBlbGVtZW50cy5sZW5ndGggLSAxXG4gICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgaWYgY2xhc3NOYW1lID09IG51bGxcbiAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICAjIENoZWNrIGF1dG9jb21wbGV0ZSBmcm9tIHBsdWdpbnNcbiAgICAgICAgICAgIGZvdW5kID0gbnVsbFxuICAgICAgICAgICAgZm9yIHBsdWdpbiBpbiBwbHVnaW5zLnBsdWdpbnNcbiAgICAgICAgICAgICAgICBjb250aW51ZSB1bmxlc3MgcGx1Z2luLmF1dG9jb21wbGV0ZT9cbiAgICAgICAgICAgICAgICBmb3VuZCA9IHBsdWdpbi5hdXRvY29tcGxldGUoY2xhc3NOYW1lLCBlbGVtZW50KVxuICAgICAgICAgICAgICAgIGJyZWFrIGlmIGZvdW5kXG5cbiAgICAgICAgICAgIGlmIGZvdW5kXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lID0gZm91bmRcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBtZXRob2RzID0gcHJveHkuYXV0b2NvbXBsZXRlKGNsYXNzTmFtZSwgZWxlbWVudClcblxuICAgICAgICAgICAgICAgICMgRWxlbWVudCBub3QgZm91bmQgb3Igbm8gcmV0dXJuIHZhbHVlXG4gICAgICAgICAgICAgICAgaWYgbm90IG1ldGhvZHMuY2xhc3M/IG9yIG5vdCBAaXNDbGFzcyhtZXRob2RzLmNsYXNzKVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWUgPSBudWxsXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICBjbGFzc05hbWUgPSBtZXRob2RzLmNsYXNzXG5cbiAgICAgICAgICAgIGxvb3BfaW5kZXgrK1xuXG4gICAgICAgICPCoElmIG5vIGRhdGEgb3IgYSB2YWxpZCBlbmQgb2YgbGluZSwgT0tcbiAgICAgICAgaWYgZWxlbWVudHMubGVuZ3RoID4gMCBhbmQgKGVsZW1lbnRzW2VsZW1lbnRzLmxlbmd0aC0xXS5sZW5ndGggPT0gMCBvciBlbGVtZW50c1tlbGVtZW50cy5sZW5ndGgtMV0ubWF0Y2goLyhbYS16QS1aMC05XSQpL2cpKVxuICAgICAgICAgICAgcmV0dXJuIGNsYXNzTmFtZVxuXG4gICAgICAgIHJldHVybiBudWxsXG5cbiAgICAjIyMqXG4gICAgICogR2V0cyB0aGUgZnVsbCB3b3JkcyBmcm9tIHRoZSBidWZmZXIgcG9zaXRpb24gZ2l2ZW4uXG4gICAgICogRS5nLiBHZXR0aW5nIGEgY2xhc3Mgd2l0aCBpdHMgbmFtZXNwYWNlLlxuICAgICAqIEBwYXJhbSAge1RleHRFZGl0b3J9ICAgICBlZGl0b3IgICBUZXh0RWRpdG9yIHRvIHNlYXJjaC5cbiAgICAgKiBAcGFyYW0gIHtCdWZmZXJQb3NpdGlvbn0gcG9zaXRpb24gQnVmZmVyUG9zaXRpb24gdG8gc3RhcnQgc2VhcmNoaW5nIGZyb20uXG4gICAgICogQHJldHVybiB7c3RyaW5nfSAgUmV0dXJucyBhIHN0cmluZyBvZiB0aGUgY2xhc3MuXG4gICAgIyMjXG4gICAgZ2V0RnVsbFdvcmRGcm9tQnVmZmVyUG9zaXRpb246IChlZGl0b3IsIHBvc2l0aW9uKSAtPlxuICAgICAgICBmb3VuZFN0YXJ0ID0gZmFsc2VcbiAgICAgICAgZm91bmRFbmQgPSBmYWxzZVxuICAgICAgICBzdGFydEJ1ZmZlclBvc2l0aW9uID0gW11cbiAgICAgICAgZW5kQnVmZmVyUG9zaXRpb24gPSBbXVxuICAgICAgICBmb3J3YXJkUmVnZXggPSAvLXwoPzpcXCgpW1xcd1xcW1xcJFxcKFxcXFxdfFxcc3xcXCl8O3wnfCx8XCJ8XFx8L1xuICAgICAgICBiYWNrd2FyZFJlZ2V4ID0gL1xcKHxcXHN8XFwpfDt8J3wsfFwifFxcfC9cbiAgICAgICAgaW5kZXggPSAtMVxuICAgICAgICBwcmV2aW91c1RleHQgPSAnJ1xuXG4gICAgICAgIGxvb3BcbiAgICAgICAgICAgIGluZGV4KytcbiAgICAgICAgICAgIHN0YXJ0QnVmZmVyUG9zaXRpb24gPSBbcG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW4gLSBpbmRleCAtIDFdXG4gICAgICAgICAgICByYW5nZSA9IFtbcG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW5dLCBbc3RhcnRCdWZmZXJQb3NpdGlvblswXSwgc3RhcnRCdWZmZXJQb3NpdGlvblsxXV1dXG4gICAgICAgICAgICBjdXJyZW50VGV4dCA9IGVkaXRvci5nZXRUZXh0SW5CdWZmZXJSYW5nZShyYW5nZSlcbiAgICAgICAgICAgIGlmIGJhY2t3YXJkUmVnZXgudGVzdChlZGl0b3IuZ2V0VGV4dEluQnVmZmVyUmFuZ2UocmFuZ2UpKSB8fCBzdGFydEJ1ZmZlclBvc2l0aW9uWzFdID09IC0xIHx8IGN1cnJlbnRUZXh0ID09IHByZXZpb3VzVGV4dFxuICAgICAgICAgICAgICAgIGZvdW5kU3RhcnQgPSB0cnVlXG4gICAgICAgICAgICBwcmV2aW91c1RleHQgPSBlZGl0b3IuZ2V0VGV4dEluQnVmZmVyUmFuZ2UocmFuZ2UpXG4gICAgICAgICAgICBicmVhayBpZiBmb3VuZFN0YXJ0XG4gICAgICAgIGluZGV4ID0gLTFcbiAgICAgICAgbG9vcFxuICAgICAgICAgICAgaW5kZXgrK1xuICAgICAgICAgICAgZW5kQnVmZmVyUG9zaXRpb24gPSBbcG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW4gKyBpbmRleCArIDFdXG4gICAgICAgICAgICByYW5nZSA9IFtbcG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW5dLCBbZW5kQnVmZmVyUG9zaXRpb25bMF0sIGVuZEJ1ZmZlclBvc2l0aW9uWzFdXV1cbiAgICAgICAgICAgIGN1cnJlbnRUZXh0ID0gZWRpdG9yLmdldFRleHRJbkJ1ZmZlclJhbmdlKHJhbmdlKVxuICAgICAgICAgICAgaWYgZm9yd2FyZFJlZ2V4LnRlc3QoY3VycmVudFRleHQpIHx8IGVuZEJ1ZmZlclBvc2l0aW9uWzFdID09IDUwMCB8fCBjdXJyZW50VGV4dCA9PSBwcmV2aW91c1RleHRcbiAgICAgICAgICAgICAgICBmb3VuZEVuZCA9IHRydWVcbiAgICAgICAgICAgIHByZXZpb3VzVGV4dCA9IGVkaXRvci5nZXRUZXh0SW5CdWZmZXJSYW5nZShyYW5nZSlcbiAgICAgICAgICAgIGJyZWFrIGlmIGZvdW5kRW5kXG5cbiAgICAgICAgc3RhcnRCdWZmZXJQb3NpdGlvblsxXSArPSAxXG4gICAgICAgIGVuZEJ1ZmZlclBvc2l0aW9uWzFdIC09IDFcbiAgICAgICAgcmV0dXJuIGVkaXRvci5nZXRUZXh0SW5CdWZmZXJSYW5nZShbc3RhcnRCdWZmZXJQb3NpdGlvbiwgZW5kQnVmZmVyUG9zaXRpb25dKVxuXG4gICAgIyMjKlxuICAgICAqIEdldHMgdGhlIGNvcnJlY3Qgc2VsZWN0b3Igd2hlbiBhIGNsYXNzIG9yIG5hbWVzcGFjZSBpcyBjbGlja2VkLlxuICAgICAqXG4gICAgICogQHBhcmFtICB7alF1ZXJ5LkV2ZW50fSAgZXZlbnQgIEEgalF1ZXJ5IGV2ZW50LlxuICAgICAqXG4gICAgICogQHJldHVybiB7b2JqZWN0fG51bGx9IEEgc2VsZWN0b3IgdG8gYmUgdXNlZCB3aXRoIGpRdWVyeS5cbiAgICAjIyNcbiAgICBnZXRDbGFzc1NlbGVjdG9yRnJvbUV2ZW50OiAoZXZlbnQpIC0+XG4gICAgICAgIHNlbGVjdG9yID0gZXZlbnQuY3VycmVudFRhcmdldFxuXG4gICAgICAgICQgPSByZXF1aXJlICdqcXVlcnknXG5cbiAgICAgICAgaWYgJChzZWxlY3RvcikuaGFzQ2xhc3MoJ2J1aWx0aW4nKSBvciAkKHNlbGVjdG9yKS5jaGlsZHJlbignLmJ1aWx0aW4nKS5sZW5ndGggPiAwXG4gICAgICAgICAgICByZXR1cm4gbnVsbFxuXG4gICAgICAgIGlmICQoc2VsZWN0b3IpLnBhcmVudCgpLmhhc0NsYXNzKCdmdW5jdGlvbiBhcmd1bWVudCcpXG4gICAgICAgICAgICByZXR1cm4gJChzZWxlY3RvcikucGFyZW50KCkuY2hpbGRyZW4oJy5uYW1lc3BhY2UsIC5jbGFzczpub3QoLm9wZXJhdG9yKTpub3QoLmNvbnN0YW50KScpXG5cbiAgICAgICAgaWYgJChzZWxlY3RvcikucHJldigpLmhhc0NsYXNzKCduYW1lc3BhY2UnKSAmJiAkKHNlbGVjdG9yKS5oYXNDbGFzcygnY2xhc3MnKVxuICAgICAgICAgICAgcmV0dXJuICQoWyQoc2VsZWN0b3IpLnByZXYoKVswXSwgc2VsZWN0b3JdKVxuXG4gICAgICAgIGlmICQoc2VsZWN0b3IpLm5leHQoKS5oYXNDbGFzcygnY2xhc3MnKSAmJiAkKHNlbGVjdG9yKS5oYXNDbGFzcygnbmFtZXNwYWNlJylcbiAgICAgICAgICAgcmV0dXJuICQoW3NlbGVjdG9yLCAkKHNlbGVjdG9yKS5uZXh0KClbMF1dKVxuXG4gICAgICAgIGlmICQoc2VsZWN0b3IpLnByZXYoKS5oYXNDbGFzcygnbmFtZXNwYWNlJykgfHwgJChzZWxlY3RvcikubmV4dCgpLmhhc0NsYXNzKCdpbmhlcml0ZWQtY2xhc3MnKVxuICAgICAgICAgICAgcmV0dXJuICQoc2VsZWN0b3IpLnBhcmVudCgpLmNoaWxkcmVuKCcubmFtZXNwYWNlLCAuaW5oZXJpdGVkLWNsYXNzJylcblxuICAgICAgICByZXR1cm4gc2VsZWN0b3JcblxuICAgICMjIypcbiAgICAgKiBHZXRzIHRoZSBwYXJlbnQgY2xhc3Mgb2YgdGhlIGN1cnJlbnQgY2xhc3Mgb3BlbmVkIGluIHRoZSBlZGl0b3JcbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgRWRpdG9yIHdpdGggdGhlIGNsYXNzIGluLlxuICAgICAqIEByZXR1cm4ge3N0cmluZ30gICAgICAgICAgICBUaGUgbmFtZXNwYWNlIGFuZCBjbGFzcyBvZiB0aGUgcGFyZW50XG4gICAgIyMjXG4gICAgZ2V0UGFyZW50Q2xhc3M6IChlZGl0b3IpIC0+XG4gICAgICAgIHRleHQgPSBlZGl0b3IuZ2V0VGV4dCgpXG5cbiAgICAgICAgbGluZXMgPSB0ZXh0LnNwbGl0KCdcXG4nKVxuICAgICAgICBmb3IgbGluZSBpbiBsaW5lc1xuICAgICAgICAgICAgbGluZSA9IGxpbmUudHJpbSgpXG5cbiAgICAgICAgICAgICMgSWYgd2UgZm91bmQgZXh0ZW5kcyBrZXl3b3JkLCByZXR1cm4gdGhlIGNsYXNzXG4gICAgICAgICAgICBpZiBsaW5lLmluZGV4T2YoJ2V4dGVuZHMgJykgIT0gLTFcbiAgICAgICAgICAgICAgICB3b3JkcyA9IGxpbmUuc3BsaXQoJyAnKVxuICAgICAgICAgICAgICAgIGV4dGVuZHNJbmRleCA9IHdvcmRzLmluZGV4T2YoJ2V4dGVuZHMnKVxuICAgICAgICAgICAgICAgIHJldHVybiBAZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IsIHdvcmRzW2V4dGVuZHNJbmRleCArIDFdKVxuXG4gICAgIyMjKlxuICAgICAqIEZpbmRzIHRoZSBidWZmZXIgcG9zaXRpb24gb2YgdGhlIHdvcmQgZ2l2ZW5cbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgVGV4dEVkaXRvciB0byBzZWFyY2hcbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9ICAgICB0ZXJtICAgVGhlIGZ1bmN0aW9uIG5hbWUgdG8gc2VhcmNoIGZvclxuICAgICAqIEByZXR1cm4ge21peGVkfSAgICAgICAgICAgICBFaXRoZXIgbnVsbCBvciB0aGUgYnVmZmVyIHBvc2l0aW9uIG9mIHRoZSBmdW5jdGlvbi5cbiAgICAjIyNcbiAgICBmaW5kQnVmZmVyUG9zaXRpb25PZldvcmQ6IChlZGl0b3IsIHRlcm0sIHJlZ2V4LCBsaW5lID0gbnVsbCkgLT5cbiAgICAgICAgaWYgbGluZSAhPSBudWxsXG4gICAgICAgICAgICBsaW5lVGV4dCA9IGVkaXRvci5saW5lVGV4dEZvckJ1ZmZlclJvdyhsaW5lKVxuICAgICAgICAgICAgcmVzdWx0ID0gQGNoZWNrTGluZUZvcldvcmQobGluZVRleHQsIHRlcm0sIHJlZ2V4KVxuICAgICAgICAgICAgaWYgcmVzdWx0ICE9IG51bGxcbiAgICAgICAgICAgICAgICByZXR1cm4gW2xpbmUsIHJlc3VsdF1cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgdGV4dCA9IGVkaXRvci5nZXRUZXh0KClcbiAgICAgICAgICAgIHJvdyA9IDBcbiAgICAgICAgICAgIGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJylcbiAgICAgICAgICAgIGZvciBsaW5lIGluIGxpbmVzXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gQGNoZWNrTGluZUZvcldvcmQobGluZSwgdGVybSwgcmVnZXgpXG4gICAgICAgICAgICAgICAgaWYgcmVzdWx0ICE9IG51bGxcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtyb3csIHJlc3VsdF1cbiAgICAgICAgICAgICAgICByb3crK1xuICAgICAgICByZXR1cm4gbnVsbDtcblxuICAgICMjIypcbiAgICAgKiBDaGVja3MgdGhlIGxpbmVUZXh0IGZvciB0aGUgdGVybSBhbmQgcmVnZXggbWF0Y2hlc1xuICAgICAqIEBwYXJhbSAge3N0cmluZ30gICBsaW5lVGV4dCBUaGUgbGluZSBvZiB0ZXh0IHRvIGNoZWNrLlxuICAgICAqIEBwYXJhbSAge3N0cmluZ30gICB0ZXJtICAgICBUZXJtIHRvIGxvb2sgZm9yLlxuICAgICAqIEBwYXJhbSAge3JlZ2V4fSAgICByZWdleCAgICBSZWdleCB0byBydW4gb24gdGhlIGxpbmUgdG8gbWFrZSBzdXJlIGl0J3MgdmFsaWRcbiAgICAgKiBAcmV0dXJuIHtudWxsfGludH0gICAgICAgICAgUmV0dXJucyBudWxsIGlmIG5vdGhpbmcgd2FzIGZvdW5kIG9yIGFuXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludCBvZiB0aGUgY29sdW1uIHRoZSB0ZXJtIGlzIG9uLlxuICAgICMjI1xuICAgIGNoZWNrTGluZUZvcldvcmQ6IChsaW5lVGV4dCwgdGVybSwgcmVnZXgpIC0+XG4gICAgICAgIGlmIHJlZ2V4LnRlc3QobGluZVRleHQpXG4gICAgICAgICAgICB3b3JkcyA9IGxpbmVUZXh0LnNwbGl0KCcgJylcbiAgICAgICAgICAgIHByb3BlcnR5SW5kZXggPSAwXG4gICAgICAgICAgICBmb3IgZWxlbWVudCBpbiB3b3Jkc1xuICAgICAgICAgICAgICAgIGlmIGVsZW1lbnQuaW5kZXhPZih0ZXJtKSAhPSAtMVxuICAgICAgICAgICAgICAgICAgICBicmVha1xuICAgICAgICAgICAgICAgIHByb3BlcnR5SW5kZXgrKztcblxuICAgICAgICAgICAgICByZWR1Y2VkV29yZHMgPSB3b3Jkcy5zbGljZSgwLCBwcm9wZXJ0eUluZGV4KS5qb2luKCcgJylcbiAgICAgICAgICAgICAgcmV0dXJuIHJlZHVjZWRXb3Jkcy5sZW5ndGggKyAxXG4gICAgICAgIHJldHVybiBudWxsXG4iXX0=
