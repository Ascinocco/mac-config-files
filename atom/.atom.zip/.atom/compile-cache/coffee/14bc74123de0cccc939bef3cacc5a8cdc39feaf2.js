(function() {
  var $, RsenseClient, TableParser, exec,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  $ = require('jquery');

  TableParser = require('table-parser');

  exec = require('child_process').exec;

  String.prototype.replaceAll = function(s, r) {
    return this.split(s).join(r);
  };

  module.exports = RsenseClient = (function() {
    function RsenseClient() {
      this.checkCompletion = bind(this.checkCompletion, this);
      this.stopRsense = bind(this.stopRsense, this);
      this.stopRsenseUnix = bind(this.stopRsenseUnix, this);
      this.startRsenseCommand = bind(this.startRsenseCommand, this);
      this.startRsenseWin32 = bind(this.startRsenseWin32, this);
      this.startRsenseUnix = bind(this.startRsenseUnix, this);
      this.projectPath = atom.project.getPaths()[0];
      if (!this.projectPath) {
        this.projectPath = '.';
      }
      this.rsensePath = atom.config.get('autocomplete-ruby.rsensePath');
      this.port = atom.config.get('autocomplete-ruby.port');
      this.serverUrl = "http://localhost:" + this.port;
      this.rsenseStarted = false;
      this.rsenseProcess = null;
    }

    RsenseClient.prototype.startRsenseUnix = function() {
      var start;
      start = this.startRsenseCommand;
      return exec("ps -ef | head -1; ps -ef | grep java", function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error looking for resense process', {
            detail: "exec error: " + error,
            dismissable: true
          });
        } else {
          this.rsenseProcess = $.grep(TableParser.parse(stdout), function(process) {
            return process.CMD.join(' ').match(/rsense.*--port.*--path/);
          })[0];
          if (this.rsenseProcess === void 0 || this.rsenseProcess === null) {
            return start();
          } else {
            return this.rsenseStarted = true;
          }
        }
      });
    };

    RsenseClient.prototype.startRsenseWin32 = function() {
      var start;
      if (this.rsenseStarted) {
        return;
      }
      start = this.startRsenseCommand;
      return exec(this.rsensePath + " stop", (function(_this) {
        return function(error, stdout, stderr) {
          if (error === null) {
            return start();
          } else {
            atom.notifications.addError('Error stopping rsense', {
              detail: "exec error: " + error,
              dismissable: true
            });
            return _this.rsenseStarted = false;
          }
        };
      })(this));
    };

    RsenseClient.prototype.startRsenseCommand = function() {
      if (this.rsenseStarted) {
        return;
      }
      return exec(this.rsensePath + " start --port " + this.port + " --path " + this.projectPath, function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error starting rsense', {
            detail: "exec error: " + error,
            dismissable: true
          });
        } else {
          return this.rsenseStarted = true;
        }
      });
    };

    RsenseClient.prototype.stopRsenseUnix = function() {
      var stopCommand;
      stopCommand = this.stopRsense;
      return exec("ps -ef | head -1; ps -ef | grep atom", function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error looking for atom process', {
            detail: "exec error: " + error,
            dismissable: true
          });
        } else {
          this.atomProcesses = $.grep(TableParser.parse(stdout), function(process) {
            return process.CMD.join(' ').match(/--type=renderer.*--node-integration=true/);
          });
          if (this.atomProcesses.length < 2) {
            if (this.rsenseProcess) {
              process.kill(this.rsenseProcess.PID[0], 'SIGKILL');
            }
            return stopCommand();
          }
        }
      });
    };

    RsenseClient.prototype.stopRsense = function() {
      if (!this.rsenseStarted) {
        return;
      }
      return exec(this.rsensePath + " stop", function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error stopping rsense', {
            detail: "exec error: " + error,
            dismissable: true
          });
        } else {
          return this.rsenseStarted = false;
        }
      });
    };

    RsenseClient.prototype.checkCompletion = function(editor, buffer, row, column, callback) {
      var code, request;
      code = buffer.getText().replaceAll('\n', '\n').replaceAll('%', '%25');
      request = {
        command: 'code_completion',
        project: this.projectPath,
        file: editor.getPath(),
        code: code,
        location: {
          row: row,
          column: column
        }
      };
      $.ajax(this.serverUrl, {
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(request),
        error: function(jqXHR, textStatus, errorThrown) {
          callback([]);
          return console.error(textStatus);
        },
        success: function(data, textStatus, jqXHR) {
          return callback(data.completions);
        }
      });
      return [];
    };

    return RsenseClient;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLXJ1YnkvbGliL2F1dG9jb21wbGV0ZS1ydWJ5LWNsaWVudC5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLGtDQUFBO0lBQUE7O0VBQUEsQ0FBQSxHQUFJLE9BQUEsQ0FBUSxRQUFSOztFQUNKLFdBQUEsR0FBYyxPQUFBLENBQVEsY0FBUjs7RUFDZCxJQUFBLEdBQU8sT0FBQSxDQUFRLGVBQVIsQ0FBd0IsQ0FBQzs7RUFDaEMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFqQixHQUE4QixTQUFDLENBQUQsRUFBSSxDQUFKO1dBQVUsSUFBQyxDQUFBLEtBQUQsQ0FBTyxDQUFQLENBQVMsQ0FBQyxJQUFWLENBQWUsQ0FBZjtFQUFWOztFQUU5QixNQUFNLENBQUMsT0FBUCxHQUNNO0lBQ1Msc0JBQUE7Ozs7Ozs7TUFDWCxJQUFDLENBQUEsV0FBRCxHQUFlLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBYixDQUFBLENBQXdCLENBQUEsQ0FBQTtNQUN2QyxJQUFBLENBQTBCLElBQUMsQ0FBQSxXQUEzQjtRQUFBLElBQUMsQ0FBQSxXQUFELEdBQWUsSUFBZjs7TUFDQSxJQUFDLENBQUEsVUFBRCxHQUFjLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiw4QkFBaEI7TUFDZCxJQUFDLENBQUEsSUFBRCxHQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQix3QkFBaEI7TUFDUixJQUFDLENBQUEsU0FBRCxHQUFhLG1CQUFBLEdBQW9CLElBQUMsQ0FBQTtNQUNsQyxJQUFDLENBQUEsYUFBRCxHQUFpQjtNQUNqQixJQUFDLENBQUEsYUFBRCxHQUFpQjtJQVBOOzsyQkFXYixlQUFBLEdBQWlCLFNBQUE7QUFDZixVQUFBO01BQUEsS0FBQSxHQUFRLElBQUMsQ0FBQTthQUVULElBQUEsQ0FBSyxzQ0FBTCxFQUNFLFNBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsTUFBaEI7UUFDRSxJQUFHLEtBQUEsS0FBUyxJQUFaO2lCQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsbUNBQTVCLEVBQ0k7WUFBQyxNQUFBLEVBQVEsY0FBQSxHQUFlLEtBQXhCO1lBQWlDLFdBQUEsRUFBYSxJQUE5QztXQURKLEVBREY7U0FBQSxNQUFBO1VBS0UsSUFBQyxDQUFBLGFBQUQsR0FBaUIsQ0FBQyxDQUFDLElBQUYsQ0FBTyxXQUFXLENBQUMsS0FBWixDQUFrQixNQUFsQixDQUFQLEVBQWtDLFNBQUMsT0FBRDttQkFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFaLENBQWlCLEdBQWpCLENBQXFCLENBQUMsS0FBdEIsQ0FBNkIsd0JBQTdCO1VBRGlELENBQWxDLENBRWYsQ0FBQSxDQUFBO1VBQ0YsSUFBRyxJQUFDLENBQUEsYUFBRCxLQUFrQixNQUFsQixJQUErQixJQUFDLENBQUEsYUFBRCxLQUFrQixJQUFwRDttQkFDRSxLQUFBLENBQUEsRUFERjtXQUFBLE1BQUE7bUJBR0UsSUFBQyxDQUFBLGFBQUQsR0FBaUIsS0FIbkI7V0FSRjs7TUFERixDQURGO0lBSGU7OzJCQXNCakIsZ0JBQUEsR0FBa0IsU0FBQTtBQUNoQixVQUFBO01BQUEsSUFBVSxJQUFDLENBQUEsYUFBWDtBQUFBLGVBQUE7O01BQ0EsS0FBQSxHQUFRLElBQUMsQ0FBQTthQUVULElBQUEsQ0FBUSxJQUFDLENBQUEsVUFBRixHQUFhLE9BQXBCLEVBQ0UsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLE1BQWhCO1VBQ0UsSUFBRyxLQUFBLEtBQVMsSUFBWjttQkFDRSxLQUFBLENBQUEsRUFERjtXQUFBLE1BQUE7WUFHRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLHVCQUE1QixFQUNJO2NBQUMsTUFBQSxFQUFRLGNBQUEsR0FBZSxLQUF4QjtjQUFpQyxXQUFBLEVBQWEsSUFBOUM7YUFESjttQkFHQSxLQUFDLENBQUEsYUFBRCxHQUFpQixNQU5uQjs7UUFERjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FERjtJQUpnQjs7MkJBZWxCLGtCQUFBLEdBQW9CLFNBQUE7TUFDbEIsSUFBVSxJQUFDLENBQUEsYUFBWDtBQUFBLGVBQUE7O2FBQ0EsSUFBQSxDQUFRLElBQUMsQ0FBQSxVQUFGLEdBQWEsZ0JBQWIsR0FBNkIsSUFBQyxDQUFBLElBQTlCLEdBQW1DLFVBQW5DLEdBQTZDLElBQUMsQ0FBQSxXQUFyRCxFQUNFLFNBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsTUFBaEI7UUFDRSxJQUFHLEtBQUEsS0FBUyxJQUFaO2lCQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsdUJBQTVCLEVBQ0k7WUFBQyxNQUFBLEVBQVEsY0FBQSxHQUFlLEtBQXhCO1lBQWlDLFdBQUEsRUFBYSxJQUE5QztXQURKLEVBREY7U0FBQSxNQUFBO2lCQUtFLElBQUMsQ0FBQSxhQUFELEdBQWlCLEtBTG5COztNQURGLENBREY7SUFGa0I7OzJCQWdCcEIsY0FBQSxHQUFnQixTQUFBO0FBQ2QsVUFBQTtNQUFBLFdBQUEsR0FBYyxJQUFDLENBQUE7YUFFZixJQUFBLENBQUssc0NBQUwsRUFDRSxTQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLE1BQWhCO1FBQ0UsSUFBRyxLQUFBLEtBQVMsSUFBWjtpQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLGdDQUE1QixFQUNJO1lBQUMsTUFBQSxFQUFRLGNBQUEsR0FBZSxLQUF4QjtZQUFpQyxXQUFBLEVBQWEsSUFBOUM7V0FESixFQURGO1NBQUEsTUFBQTtVQUtFLElBQUMsQ0FBQSxhQUFELEdBQWlCLENBQUMsQ0FBQyxJQUFGLENBQU8sV0FBVyxDQUFDLEtBQVosQ0FBa0IsTUFBbEIsQ0FBUCxFQUFrQyxTQUFDLE9BQUQ7bUJBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBWixDQUFpQixHQUFqQixDQUFxQixDQUFDLEtBQXRCLENBQTZCLDBDQUE3QjtVQURpRCxDQUFsQztVQUdqQixJQUFHLElBQUMsQ0FBQSxhQUFhLENBQUMsTUFBZixHQUF3QixDQUEzQjtZQUNFLElBQWtELElBQUMsQ0FBQSxhQUFuRDtjQUFBLE9BQU8sQ0FBQyxJQUFSLENBQWEsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFJLENBQUEsQ0FBQSxDQUFoQyxFQUFvQyxTQUFwQyxFQUFBOzttQkFDQSxXQUFBLENBQUEsRUFGRjtXQVJGOztNQURGLENBREY7SUFIYzs7MkJBa0JoQixVQUFBLEdBQVksU0FBQTtNQUNWLElBQVUsQ0FBQyxJQUFDLENBQUEsYUFBWjtBQUFBLGVBQUE7O2FBQ0EsSUFBQSxDQUFRLElBQUMsQ0FBQSxVQUFGLEdBQWEsT0FBcEIsRUFDRSxTQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLE1BQWhCO1FBQ0UsSUFBRyxLQUFBLEtBQVMsSUFBWjtpQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLHVCQUE1QixFQUNJO1lBQUMsTUFBQSxFQUFRLGNBQUEsR0FBZSxLQUF4QjtZQUFpQyxXQUFBLEVBQWEsSUFBOUM7V0FESixFQURGO1NBQUEsTUFBQTtpQkFLRSxJQUFDLENBQUEsYUFBRCxHQUFpQixNQUxuQjs7TUFERixDQURGO0lBRlU7OzJCQVlaLGVBQUEsR0FBaUIsU0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixHQUFqQixFQUFzQixNQUF0QixFQUE4QixRQUE5QjtBQUNmLFVBQUE7TUFBQSxJQUFBLEdBQU8sTUFBTSxDQUFDLE9BQVAsQ0FBQSxDQUFnQixDQUFDLFVBQWpCLENBQTRCLElBQTVCLEVBQWtDLElBQWxDLENBQXVDLENBQ3RCLFVBRGpCLENBQzRCLEdBRDVCLEVBQ2lDLEtBRGpDO01BR1AsT0FBQSxHQUNFO1FBQUEsT0FBQSxFQUFTLGlCQUFUO1FBQ0EsT0FBQSxFQUFTLElBQUMsQ0FBQSxXQURWO1FBRUEsSUFBQSxFQUFNLE1BQU0sQ0FBQyxPQUFQLENBQUEsQ0FGTjtRQUdBLElBQUEsRUFBTSxJQUhOO1FBSUEsUUFBQSxFQUNFO1VBQUEsR0FBQSxFQUFLLEdBQUw7VUFDQSxNQUFBLEVBQVEsTUFEUjtTQUxGOztNQVFGLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxDQUFBLFNBQVIsRUFDRTtRQUFBLElBQUEsRUFBTSxNQUFOO1FBQ0EsUUFBQSxFQUFVLE1BRFY7UUFFQSxXQUFBLEVBQWEsa0JBRmI7UUFHQSxJQUFBLEVBQU0sSUFBSSxDQUFDLFNBQUwsQ0FBZSxPQUFmLENBSE47UUFJQSxLQUFBLEVBQU8sU0FBQyxLQUFELEVBQVEsVUFBUixFQUFvQixXQUFwQjtVQUdMLFFBQUEsQ0FBUyxFQUFUO2lCQUNBLE9BQU8sQ0FBQyxLQUFSLENBQWMsVUFBZDtRQUpLLENBSlA7UUFTQSxPQUFBLEVBQVMsU0FBQyxJQUFELEVBQU8sVUFBUCxFQUFtQixLQUFuQjtpQkFDUCxRQUFBLENBQVMsSUFBSSxDQUFDLFdBQWQ7UUFETyxDQVRUO09BREY7QUFhQSxhQUFPO0lBMUJROzs7OztBQXJHbkIiLCJzb3VyY2VzQ29udGVudCI6WyIkID0gcmVxdWlyZSgnanF1ZXJ5JylcblRhYmxlUGFyc2VyID0gcmVxdWlyZSgndGFibGUtcGFyc2VyJylcbmV4ZWMgPSByZXF1aXJlKCdjaGlsZF9wcm9jZXNzJykuZXhlY1xuU3RyaW5nLnByb3RvdHlwZS5yZXBsYWNlQWxsID0gKHMsIHIpIC0+IEBzcGxpdChzKS5qb2luKHIpXG5cbm1vZHVsZS5leHBvcnRzID1cbmNsYXNzIFJzZW5zZUNsaWVudFxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAcHJvamVjdFBhdGggPSBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKVswXVxuICAgIEBwcm9qZWN0UGF0aCA9ICcuJyB1bmxlc3MgQHByb2plY3RQYXRoXG4gICAgQHJzZW5zZVBhdGggPSBhdG9tLmNvbmZpZy5nZXQoJ2F1dG9jb21wbGV0ZS1ydWJ5LnJzZW5zZVBhdGgnKVxuICAgIEBwb3J0ID0gYXRvbS5jb25maWcuZ2V0KCdhdXRvY29tcGxldGUtcnVieS5wb3J0JylcbiAgICBAc2VydmVyVXJsID0gXCJodHRwOi8vbG9jYWxob3N0OiN7QHBvcnR9XCJcbiAgICBAcnNlbnNlU3RhcnRlZCA9IGZhbHNlXG4gICAgQHJzZW5zZVByb2Nlc3MgPSBudWxsXG5cbiAgIyBDaGVjayBpZiBhbiByc2Vuc2Ugc2VydmVyIGlzIGFscmVhZHkgcnVubmluZy5cbiAgIyBUaGlzIGNhbiBkZXRlY3QgYWxsIHJzZW5zZSBwcm9jZXNzZXMgZXZlbiB0aG9zZSB3aXRob3V0IHBpZCBmaWxlcy5cbiAgc3RhcnRSc2Vuc2VVbml4OiA9PlxuICAgIHN0YXJ0ID0gQHN0YXJ0UnNlbnNlQ29tbWFuZFxuXG4gICAgZXhlYyhcInBzIC1lZiB8IGhlYWQgLTE7IHBzIC1lZiB8IGdyZXAgamF2YVwiLFxuICAgICAgKGVycm9yLCBzdGRvdXQsIHN0ZGVycikgLT5cbiAgICAgICAgaWYgZXJyb3IgIT0gbnVsbFxuICAgICAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcignRXJyb3IgbG9va2luZyBmb3IgcmVzZW5zZSBwcm9jZXNzJyxcbiAgICAgICAgICAgICAge2RldGFpbDogXCJleGVjIGVycm9yOiAje2Vycm9yfVwiLCBkaXNtaXNzYWJsZTogdHJ1ZX1cbiAgICAgICAgICAgIClcbiAgICAgICAgZWxzZVxuICAgICAgICAgIEByc2Vuc2VQcm9jZXNzID0gJC5ncmVwKFRhYmxlUGFyc2VyLnBhcnNlKHN0ZG91dCksIChwcm9jZXNzKSAtPlxuICAgICAgICAgICAgcHJvY2Vzcy5DTUQuam9pbignICcpLm1hdGNoKCAvcnNlbnNlLiotLXBvcnQuKi0tcGF0aC8gKVxuICAgICAgICAgIClbMF1cbiAgICAgICAgICBpZiBAcnNlbnNlUHJvY2VzcyA9PSB1bmRlZmluZWQgfHwgQHJzZW5zZVByb2Nlc3MgPT0gbnVsbFxuICAgICAgICAgICAgc3RhcnQoKVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIEByc2Vuc2VTdGFydGVkID0gdHJ1ZVxuICAgIClcblxuICAjIEJlZm9yZSB0cnlpbmcgdG8gc3RhcnQgaW4gV2luZG93cyB3ZSBuZWVkIHRvIGtpbGwgYW55IGV4aXN0aW5nIHJzZW5zZSBzZXJ2ZXJzLCBzb1xuICAjIGFzIHRvIG5vdCBlbmQgdXAgd2l0aCBtdWx0aXBsZSByc2Vuc2Ugc2VydnNlcnMgdW5raWxsYWJsZSBieSAncnNlbnNlIHN0b3AnXG4gICMgVGhpcyBtZWFucyB0aGF0IHJ1bm5pbmcgdHdvIGF0b21zIGFuZCBjbG9zaW5nIG9uZSwga2lsbHMgcnNlbnNlIGZvciB0aGUgb3RoZXJcbiAgc3RhcnRSc2Vuc2VXaW4zMjogPT5cbiAgICByZXR1cm4gaWYgQHJzZW5zZVN0YXJ0ZWRcbiAgICBzdGFydCA9IEBzdGFydFJzZW5zZUNvbW1hbmRcblxuICAgIGV4ZWMoXCIje0Byc2Vuc2VQYXRofSBzdG9wXCIsXG4gICAgICAoZXJyb3IsIHN0ZG91dCwgc3RkZXJyKSA9PlxuICAgICAgICBpZiBlcnJvciA9PSBudWxsXG4gICAgICAgICAgc3RhcnQoKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZEVycm9yKCdFcnJvciBzdG9wcGluZyByc2Vuc2UnLFxuICAgICAgICAgICAgICB7ZGV0YWlsOiBcImV4ZWMgZXJyb3I6ICN7ZXJyb3J9XCIsIGRpc21pc3NhYmxlOiB0cnVlfVxuICAgICAgICAgICAgKVxuICAgICAgICAgIEByc2Vuc2VTdGFydGVkID0gZmFsc2VcbiAgICApXG5cbiAgc3RhcnRSc2Vuc2VDb21tYW5kOiA9PlxuICAgIHJldHVybiBpZiBAcnNlbnNlU3RhcnRlZFxuICAgIGV4ZWMoXCIje0Byc2Vuc2VQYXRofSBzdGFydCAtLXBvcnQgI3tAcG9ydH0gLS1wYXRoICN7QHByb2plY3RQYXRofVwiLFxuICAgICAgKGVycm9yLCBzdGRvdXQsIHN0ZGVycikgLT5cbiAgICAgICAgaWYgZXJyb3IgIT0gbnVsbFxuICAgICAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcignRXJyb3Igc3RhcnRpbmcgcnNlbnNlJyxcbiAgICAgICAgICAgICAge2RldGFpbDogXCJleGVjIGVycm9yOiAje2Vycm9yfVwiLCBkaXNtaXNzYWJsZTogdHJ1ZX1cbiAgICAgICAgICAgIClcbiAgICAgICAgZWxzZVxuICAgICAgICAgIEByc2Vuc2VTdGFydGVkID0gdHJ1ZVxuICAgIClcblxuICAjIEZpcnN0IGNvdW50IGhvdyBtYW55IGF0b20gd2luZG93cyBhcmUgb3Blbi5cbiAgIyBJZiB0aGVyZSBpcyBvbmx5IG9uZSBvcGVuLCB0aGVuIGtpbGwgdGhlIHJzZW5zZSBwcm9jZXNzLlxuICAjIFRoaXMgaXMgYWxzbyBhYmxlIHRvIGtpbGwgYW4gcnNlbnNlIHByb2Nlc3Mgd2l0aG91dCBhIHBpZCBmaWxlLlxuICAjIE90aGVyd2lzZSBkbyBub3RoaW5nIHNvIHlvdSB3aWxsIHN0aWxsIGJlIGFibGUgdG8gdXNlIHJzZW5zZSBpbiBvdGhlciB3aW5kb3dzLlxuICBzdG9wUnNlbnNlVW5peDogPT5cbiAgICBzdG9wQ29tbWFuZCA9IEBzdG9wUnNlbnNlXG5cbiAgICBleGVjKFwicHMgLWVmIHwgaGVhZCAtMTsgcHMgLWVmIHwgZ3JlcCBhdG9tXCIsXG4gICAgICAoZXJyb3IsIHN0ZG91dCwgc3RkZXJyKSAtPlxuICAgICAgICBpZiBlcnJvciAhPSBudWxsXG4gICAgICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZEVycm9yKCdFcnJvciBsb29raW5nIGZvciBhdG9tIHByb2Nlc3MnLFxuICAgICAgICAgICAgICB7ZGV0YWlsOiBcImV4ZWMgZXJyb3I6ICN7ZXJyb3J9XCIsIGRpc21pc3NhYmxlOiB0cnVlfVxuICAgICAgICAgICAgKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgQGF0b21Qcm9jZXNzZXMgPSAkLmdyZXAoVGFibGVQYXJzZXIucGFyc2Uoc3Rkb3V0KSwgKHByb2Nlc3MpIC0+XG4gICAgICAgICAgICBwcm9jZXNzLkNNRC5qb2luKCcgJykubWF0Y2goIC8tLXR5cGU9cmVuZGVyZXIuKi0tbm9kZS1pbnRlZ3JhdGlvbj10cnVlLyApXG4gICAgICAgICAgKVxuICAgICAgICAgIGlmIEBhdG9tUHJvY2Vzc2VzLmxlbmd0aCA8IDJcbiAgICAgICAgICAgIHByb2Nlc3Mua2lsbChAcnNlbnNlUHJvY2Vzcy5QSURbMF0sICdTSUdLSUxMJykgaWYgQHJzZW5zZVByb2Nlc3NcbiAgICAgICAgICAgIHN0b3BDb21tYW5kKClcbiAgICApXG5cbiAgc3RvcFJzZW5zZTogPT5cbiAgICByZXR1cm4gaWYgIUByc2Vuc2VTdGFydGVkXG4gICAgZXhlYyhcIiN7QHJzZW5zZVBhdGh9IHN0b3BcIixcbiAgICAgIChlcnJvciwgc3Rkb3V0LCBzdGRlcnIpIC0+XG4gICAgICAgIGlmIGVycm9yICE9IG51bGxcbiAgICAgICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkRXJyb3IoJ0Vycm9yIHN0b3BwaW5nIHJzZW5zZScsXG4gICAgICAgICAgICAgIHtkZXRhaWw6IFwiZXhlYyBlcnJvcjogI3tlcnJvcn1cIiwgZGlzbWlzc2FibGU6IHRydWV9XG4gICAgICAgICAgICApXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBAcnNlbnNlU3RhcnRlZCA9IGZhbHNlXG4gICAgKVxuXG4gIGNoZWNrQ29tcGxldGlvbjogKGVkaXRvciwgYnVmZmVyLCByb3csIGNvbHVtbiwgY2FsbGJhY2spID0+XG4gICAgY29kZSA9IGJ1ZmZlci5nZXRUZXh0KCkucmVwbGFjZUFsbCgnXFxuJywgJ1xcbicpLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcGxhY2VBbGwoJyUnLCAnJTI1JylcblxuICAgIHJlcXVlc3QgPVxuICAgICAgY29tbWFuZDogJ2NvZGVfY29tcGxldGlvbidcbiAgICAgIHByb2plY3Q6IEBwcm9qZWN0UGF0aFxuICAgICAgZmlsZTogZWRpdG9yLmdldFBhdGgoKVxuICAgICAgY29kZTogY29kZVxuICAgICAgbG9jYXRpb246XG4gICAgICAgIHJvdzogcm93XG4gICAgICAgIGNvbHVtbjogY29sdW1uXG5cbiAgICAkLmFqYXggQHNlcnZlclVybCxcbiAgICAgIHR5cGU6ICdQT1NUJ1xuICAgICAgZGF0YVR5cGU6ICdqc29uJ1xuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIGRhdGE6IEpTT04uc3RyaW5naWZ5IHJlcXVlc3RcbiAgICAgIGVycm9yOiAoanFYSFIsIHRleHRTdGF0dXMsIGVycm9yVGhyb3duKSAtPlxuICAgICAgICAjIHNlbmQgZW1wdHkgYXJyYXkgdG8gY2FsbGJhY2tcbiAgICAgICAgIyB0byBhdm9pZCBhdXRvY29tcGxldGUtcGx1cyBicmlja1xuICAgICAgICBjYWxsYmFjayBbXVxuICAgICAgICBjb25zb2xlLmVycm9yIHRleHRTdGF0dXNcbiAgICAgIHN1Y2Nlc3M6IChkYXRhLCB0ZXh0U3RhdHVzLCBqcVhIUikgLT5cbiAgICAgICAgY2FsbGJhY2sgZGF0YS5jb21wbGV0aW9uc1xuXG4gICAgcmV0dXJuIFtdXG4iXX0=
