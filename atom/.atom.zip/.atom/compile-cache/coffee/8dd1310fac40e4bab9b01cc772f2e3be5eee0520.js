(function() {
  var AbstractProvider, VariableProvider, fuzzaldrin, parser,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  fuzzaldrin = require('fuzzaldrin');

  parser = require("../services/php-file-parser.coffee");

  AbstractProvider = require("./abstract-provider");

  module.exports = VariableProvider = (function(superClass) {
    extend(VariableProvider, superClass);

    function VariableProvider() {
      return VariableProvider.__super__.constructor.apply(this, arguments);
    }

    VariableProvider.prototype.variables = [];


    /**
     * Get suggestions from the provider (@see provider-api)
     * @return array
     */

    VariableProvider.prototype.fetchSuggestions = function(arg) {
      var bufferPosition, editor, prefix, scopeDescriptor, suggestions;
      editor = arg.editor, bufferPosition = arg.bufferPosition, scopeDescriptor = arg.scopeDescriptor, prefix = arg.prefix;
      this.regex = /(\$[a-zA-Z_]*)/g;
      prefix = this.getPrefix(editor, bufferPosition);
      if (!prefix.length) {
        return;
      }
      this.variables = parser.getAllVariablesInFunction(editor, bufferPosition);
      if (!this.variables.length) {
        return;
      }
      suggestions = this.findSuggestionsForPrefix(prefix.trim());
      if (!suggestions.length) {
        return;
      }
      return suggestions;
    };


    /**
     * Returns suggestions available matching the given prefix
     * @param {string} prefix Prefix to match
     * @return array
     */

    VariableProvider.prototype.findSuggestionsForPrefix = function(prefix) {
      var i, len, suggestions, word, words;
      words = fuzzaldrin.filter(this.variables, prefix);
      suggestions = [];
      for (i = 0, len = words.length; i < len; i++) {
        word = words[i];
        suggestions.push({
          text: word,
          type: 'variable',
          replacementPrefix: prefix
        });
      }
      return suggestions;
    };

    return VariableProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hdXRvY29tcGxldGlvbi92YXJpYWJsZS1wcm92aWRlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLHNEQUFBO0lBQUE7OztFQUFBLFVBQUEsR0FBYSxPQUFBLENBQVEsWUFBUjs7RUFFYixNQUFBLEdBQVMsT0FBQSxDQUFRLG9DQUFSOztFQUNULGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSxxQkFBUjs7RUFFbkIsTUFBTSxDQUFDLE9BQVAsR0FHTTs7Ozs7OzsrQkFDRixTQUFBLEdBQVc7OztBQUVYOzs7OzsrQkFJQSxnQkFBQSxHQUFrQixTQUFDLEdBQUQ7QUFFZCxVQUFBO01BRmdCLHFCQUFRLHFDQUFnQix1Q0FBaUI7TUFFekQsSUFBQyxDQUFBLEtBQUQsR0FBUztNQUVULE1BQUEsR0FBUyxJQUFDLENBQUEsU0FBRCxDQUFXLE1BQVgsRUFBbUIsY0FBbkI7TUFDVCxJQUFBLENBQWMsTUFBTSxDQUFDLE1BQXJCO0FBQUEsZUFBQTs7TUFFQSxJQUFDLENBQUEsU0FBRCxHQUFhLE1BQU0sQ0FBQyx5QkFBUCxDQUFpQyxNQUFqQyxFQUF5QyxjQUF6QztNQUNiLElBQUEsQ0FBYyxJQUFDLENBQUEsU0FBUyxDQUFDLE1BQXpCO0FBQUEsZUFBQTs7TUFFQSxXQUFBLEdBQWMsSUFBQyxDQUFBLHdCQUFELENBQTBCLE1BQU0sQ0FBQyxJQUFQLENBQUEsQ0FBMUI7TUFDZCxJQUFBLENBQWMsV0FBVyxDQUFDLE1BQTFCO0FBQUEsZUFBQTs7QUFDQSxhQUFPO0lBWk87OztBQWNsQjs7Ozs7OytCQUtBLHdCQUFBLEdBQTBCLFNBQUMsTUFBRDtBQUV0QixVQUFBO01BQUEsS0FBQSxHQUFRLFVBQVUsQ0FBQyxNQUFYLENBQWtCLElBQUMsQ0FBQSxTQUFuQixFQUE4QixNQUE5QjtNQUdSLFdBQUEsR0FBYztBQUNkLFdBQUEsdUNBQUE7O1FBQ0ksV0FBVyxDQUFDLElBQVosQ0FDSTtVQUFBLElBQUEsRUFBTSxJQUFOO1VBQ0EsSUFBQSxFQUFNLFVBRE47VUFFQSxpQkFBQSxFQUFtQixNQUZuQjtTQURKO0FBREo7QUFNQSxhQUFPO0lBWmU7Ozs7S0ExQkM7QUFSL0IiLCJzb3VyY2VzQ29udGVudCI6WyJmdXp6YWxkcmluID0gcmVxdWlyZSAnZnV6emFsZHJpbidcblxucGFyc2VyID0gcmVxdWlyZSBcIi4uL3NlcnZpY2VzL3BocC1maWxlLXBhcnNlci5jb2ZmZWVcIlxuQWJzdHJhY3RQcm92aWRlciA9IHJlcXVpcmUgXCIuL2Fic3RyYWN0LXByb3ZpZGVyXCJcblxubW9kdWxlLmV4cG9ydHMgPVxuXG4jIEF1dG9jb21wbGV0ZSBmb3IgbG9jYWwgdmFyaWFibGUgbmFtZXMuXG5jbGFzcyBWYXJpYWJsZVByb3ZpZGVyIGV4dGVuZHMgQWJzdHJhY3RQcm92aWRlclxuICAgIHZhcmlhYmxlczogW11cblxuICAgICMjIypcbiAgICAgKiBHZXQgc3VnZ2VzdGlvbnMgZnJvbSB0aGUgcHJvdmlkZXIgKEBzZWUgcHJvdmlkZXItYXBpKVxuICAgICAqIEByZXR1cm4gYXJyYXlcbiAgICAjIyNcbiAgICBmZXRjaFN1Z2dlc3Rpb25zOiAoe2VkaXRvciwgYnVmZmVyUG9zaXRpb24sIHNjb3BlRGVzY3JpcHRvciwgcHJlZml4fSkgLT5cbiAgICAgICAgIyBcIm5ld1wiIGtleXdvcmQgb3Igd29yZCBzdGFydGluZyB3aXRoIGNhcGl0YWwgbGV0dGVyXG4gICAgICAgIEByZWdleCA9IC8oXFwkW2EtekEtWl9dKikvZ1xuXG4gICAgICAgIHByZWZpeCA9IEBnZXRQcmVmaXgoZWRpdG9yLCBidWZmZXJQb3NpdGlvbilcbiAgICAgICAgcmV0dXJuIHVubGVzcyBwcmVmaXgubGVuZ3RoXG5cbiAgICAgICAgQHZhcmlhYmxlcyA9IHBhcnNlci5nZXRBbGxWYXJpYWJsZXNJbkZ1bmN0aW9uKGVkaXRvciwgYnVmZmVyUG9zaXRpb24pXG4gICAgICAgIHJldHVybiB1bmxlc3MgQHZhcmlhYmxlcy5sZW5ndGhcblxuICAgICAgICBzdWdnZXN0aW9ucyA9IEBmaW5kU3VnZ2VzdGlvbnNGb3JQcmVmaXgocHJlZml4LnRyaW0oKSlcbiAgICAgICAgcmV0dXJuIHVubGVzcyBzdWdnZXN0aW9ucy5sZW5ndGhcbiAgICAgICAgcmV0dXJuIHN1Z2dlc3Rpb25zXG5cbiAgICAjIyMqXG4gICAgICogUmV0dXJucyBzdWdnZXN0aW9ucyBhdmFpbGFibGUgbWF0Y2hpbmcgdGhlIGdpdmVuIHByZWZpeFxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwcmVmaXggUHJlZml4IHRvIG1hdGNoXG4gICAgICogQHJldHVybiBhcnJheVxuICAgICMjI1xuICAgIGZpbmRTdWdnZXN0aW9uc0ZvclByZWZpeDogKHByZWZpeCkgLT5cbiAgICAgICAgIyBGaWx0ZXIgdGhlIHdvcmRzIHVzaW5nIGZ1enphbGRyaW5cbiAgICAgICAgd29yZHMgPSBmdXp6YWxkcmluLmZpbHRlciBAdmFyaWFibGVzLCBwcmVmaXhcblxuICAgICAgICAjIEJ1aWxkcyBzdWdnZXN0aW9ucyBmb3IgdGhlIHdvcmRzXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gW11cbiAgICAgICAgZm9yIHdvcmQgaW4gd29yZHNcbiAgICAgICAgICAgIHN1Z2dlc3Rpb25zLnB1c2hcbiAgICAgICAgICAgICAgICB0ZXh0OiB3b3JkLFxuICAgICAgICAgICAgICAgIHR5cGU6ICd2YXJpYWJsZScsXG4gICAgICAgICAgICAgICAgcmVwbGFjZW1lbnRQcmVmaXg6IHByZWZpeFxuXG4gICAgICAgIHJldHVybiBzdWdnZXN0aW9uc1xuIl19
