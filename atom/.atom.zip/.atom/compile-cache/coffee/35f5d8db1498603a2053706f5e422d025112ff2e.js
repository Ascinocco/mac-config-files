(function() {
  var CommandContext, Emitter, Runtime, _;

  CommandContext = require('./command-context');

  _ = require('underscore');

  Emitter = require('atom').Emitter;

  module.exports = Runtime = (function() {
    Runtime.prototype.observers = [];

    function Runtime(runner, codeContextBuilder, observers, emitter) {
      this.runner = runner;
      this.codeContextBuilder = codeContextBuilder;
      this.observers = observers != null ? observers : [];
      this.emitter = emitter != null ? emitter : new Emitter;
      this.scriptOptions = this.runner.scriptOptions;
      _.each(this.observers, (function(_this) {
        return function(observer) {
          return observer.observe(_this);
        };
      })(this));
    }

    Runtime.prototype.addObserver = function(observer) {
      this.observers.push(observer);
      return observer.observe(this);
    };

    Runtime.prototype.destroy = function() {
      this.stop();
      this.runner.destroy();
      _.each(this.observers, function(observer) {
        return observer.destroy();
      });
      this.emitter.dispose();
      return this.codeContextBuilder.destroy();
    };

    Runtime.prototype.execute = function(argType, input, options) {
      var codeContext, commandContext, executionOptions;
      if (argType == null) {
        argType = "Selection Based";
      }
      if (input == null) {
        input = null;
      }
      if (options == null) {
        options = null;
      }
      if (atom.config.get('script.stopOnRerun')) {
        this.stop();
      }
      this.emitter.emit('start');
      codeContext = this.codeContextBuilder.buildCodeContext(atom.workspace.getActiveTextEditor(), argType);
      if ((codeContext != null ? codeContext.lang : void 0) == null) {
        return;
      }
      executionOptions = options ? options : this.scriptOptions;
      commandContext = CommandContext.build(this, executionOptions, codeContext);
      if (!commandContext) {
        return;
      }
      if (commandContext.workingDirectory != null) {
        executionOptions.workingDirectory = commandContext.workingDirectory;
      }
      this.emitter.emit('did-context-create', {
        lang: codeContext.lang,
        filename: codeContext.filename,
        lineNumber: codeContext.lineNumber
      });
      this.runner.scriptOptions = executionOptions;
      this.runner.run(commandContext.command, commandContext.args, codeContext, input);
      return this.emitter.emit('started', commandContext);
    };

    Runtime.prototype.stop = function() {
      this.emitter.emit('stop');
      this.runner.stop();
      return this.emitter.emit('stopped');
    };

    Runtime.prototype.onStart = function(callback) {
      return this.emitter.on('start', callback);
    };

    Runtime.prototype.onStarted = function(callback) {
      return this.emitter.on('started', callback);
    };

    Runtime.prototype.onStop = function(callback) {
      return this.emitter.on('stop', callback);
    };

    Runtime.prototype.onStopped = function(callback) {
      return this.emitter.on('stopped', callback);
    };

    Runtime.prototype.onDidNotSpecifyLanguage = function(callback) {
      return this.codeContextBuilder.onDidNotSpecifyLanguage(callback);
    };

    Runtime.prototype.onDidNotSupportLanguage = function(callback) {
      return this.codeContextBuilder.onDidNotSupportLanguage(callback);
    };

    Runtime.prototype.onDidNotSupportMode = function(callback) {
      return this.emitter.on('did-not-support-mode', callback);
    };

    Runtime.prototype.onDidNotBuildArgs = function(callback) {
      return this.emitter.on('did-not-build-args', callback);
    };

    Runtime.prototype.onDidContextCreate = function(callback) {
      return this.emitter.on('did-context-create', callback);
    };

    Runtime.prototype.onDidWriteToStdout = function(callback) {
      return this.runner.onDidWriteToStdout(callback);
    };

    Runtime.prototype.onDidWriteToStderr = function(callback) {
      return this.runner.onDidWriteToStderr(callback);
    };

    Runtime.prototype.onDidExit = function(callback) {
      return this.runner.onDidExit(callback);
    };

    Runtime.prototype.onDidNotRun = function(callback) {
      return this.runner.onDidNotRun(callback);
    };

    Runtime.prototype.modeNotSupported = function(argType, lang) {
      return this.emitter.emit('did-not-support-mode', {
        argType: argType,
        lang: lang
      });
    };

    Runtime.prototype.didNotBuildArgs = function(error) {
      return this.emitter.emit('did-not-build-args', {
        error: error
      });
    };

    return Runtime;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ydW50aW1lLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxtQ0FBQTs7QUFBQSxFQUFBLGNBQUEsR0FBaUIsT0FBQSxDQUFRLG1CQUFSLENBQWpCLENBQUE7O0FBQUEsRUFFQSxDQUFBLEdBQUksT0FBQSxDQUFRLFlBQVIsQ0FGSixDQUFBOztBQUFBLEVBSUMsVUFBVyxPQUFBLENBQVEsTUFBUixFQUFYLE9BSkQsQ0FBQTs7QUFBQSxFQU1BLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFDSixzQkFBQSxTQUFBLEdBQVcsRUFBWCxDQUFBOztBQUthLElBQUEsaUJBQUUsTUFBRixFQUFXLGtCQUFYLEVBQWdDLFNBQWhDLEVBQWlELE9BQWpELEdBQUE7QUFDWCxNQURZLElBQUMsQ0FBQSxTQUFBLE1BQ2IsQ0FBQTtBQUFBLE1BRHFCLElBQUMsQ0FBQSxxQkFBQSxrQkFDdEIsQ0FBQTtBQUFBLE1BRDBDLElBQUMsQ0FBQSxnQ0FBQSxZQUFZLEVBQ3ZELENBQUE7QUFBQSxNQUQyRCxJQUFDLENBQUEsNEJBQUEsVUFBVSxHQUFBLENBQUEsT0FDdEUsQ0FBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLGFBQUQsR0FBaUIsSUFBQyxDQUFBLE1BQU0sQ0FBQyxhQUF6QixDQUFBO0FBQUEsTUFDQSxDQUFDLENBQUMsSUFBRixDQUFPLElBQUMsQ0FBQSxTQUFSLEVBQW1CLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLFFBQUQsR0FBQTtpQkFBYyxRQUFRLENBQUMsT0FBVCxDQUFpQixLQUFqQixFQUFkO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkIsQ0FEQSxDQURXO0lBQUEsQ0FMYjs7QUFBQSxzQkFlQSxXQUFBLEdBQWEsU0FBQyxRQUFELEdBQUE7QUFDWCxNQUFBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFnQixRQUFoQixDQUFBLENBQUE7YUFDQSxRQUFRLENBQUMsT0FBVCxDQUFpQixJQUFqQixFQUZXO0lBQUEsQ0FmYixDQUFBOztBQUFBLHNCQXNCQSxPQUFBLEdBQVMsU0FBQSxHQUFBO0FBQ1AsTUFBQSxJQUFDLENBQUEsSUFBRCxDQUFBLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxPQUFSLENBQUEsQ0FEQSxDQUFBO0FBQUEsTUFFQSxDQUFDLENBQUMsSUFBRixDQUFPLElBQUMsQ0FBQSxTQUFSLEVBQW1CLFNBQUMsUUFBRCxHQUFBO2VBQWMsUUFBUSxDQUFDLE9BQVQsQ0FBQSxFQUFkO01BQUEsQ0FBbkIsQ0FGQSxDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsT0FBTyxDQUFDLE9BQVQsQ0FBQSxDQUhBLENBQUE7YUFJQSxJQUFDLENBQUEsa0JBQWtCLENBQUMsT0FBcEIsQ0FBQSxFQUxPO0lBQUEsQ0F0QlQsQ0FBQTs7QUFBQSxzQkFvQ0EsT0FBQSxHQUFTLFNBQUMsT0FBRCxFQUE4QixLQUE5QixFQUE0QyxPQUE1QyxHQUFBO0FBQ1AsVUFBQSw2Q0FBQTs7UUFEUSxVQUFVO09BQ2xCOztRQURxQyxRQUFRO09BQzdDOztRQURtRCxVQUFVO09BQzdEO0FBQUEsTUFBQSxJQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixvQkFBaEIsQ0FBWDtBQUFBLFFBQUEsSUFBQyxDQUFBLElBQUQsQ0FBQSxDQUFBLENBQUE7T0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsT0FBZCxDQURBLENBQUE7QUFBQSxNQUdBLFdBQUEsR0FBYyxJQUFDLENBQUEsa0JBQWtCLENBQUMsZ0JBQXBCLENBQXFDLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQSxDQUFyQyxFQUEyRSxPQUEzRSxDQUhkLENBQUE7QUFPQSxNQUFBLElBQWMseURBQWQ7QUFBQSxjQUFBLENBQUE7T0FQQTtBQUFBLE1BU0EsZ0JBQUEsR0FBc0IsT0FBSCxHQUFnQixPQUFoQixHQUE2QixJQUFDLENBQUEsYUFUakQsQ0FBQTtBQUFBLE1BVUEsY0FBQSxHQUFpQixjQUFjLENBQUMsS0FBZixDQUFxQixJQUFyQixFQUF3QixnQkFBeEIsRUFBMEMsV0FBMUMsQ0FWakIsQ0FBQTtBQVlBLE1BQUEsSUFBQSxDQUFBLGNBQUE7QUFBQSxjQUFBLENBQUE7T0FaQTtBQWNBLE1BQUEsSUFBRyx1Q0FBSDtBQUNFLFFBQUEsZ0JBQWdCLENBQUMsZ0JBQWpCLEdBQW9DLGNBQWMsQ0FBQyxnQkFBbkQsQ0FERjtPQWRBO0FBQUEsTUFpQkEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsb0JBQWQsRUFDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLFdBQVcsQ0FBQyxJQUFsQjtBQUFBLFFBQ0EsUUFBQSxFQUFVLFdBQVcsQ0FBQyxRQUR0QjtBQUFBLFFBRUEsVUFBQSxFQUFZLFdBQVcsQ0FBQyxVQUZ4QjtPQURGLENBakJBLENBQUE7QUFBQSxNQXNCQSxJQUFDLENBQUEsTUFBTSxDQUFDLGFBQVIsR0FBd0IsZ0JBdEJ4QixDQUFBO0FBQUEsTUF1QkEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxHQUFSLENBQVksY0FBYyxDQUFDLE9BQTNCLEVBQW9DLGNBQWMsQ0FBQyxJQUFuRCxFQUF5RCxXQUF6RCxFQUFzRSxLQUF0RSxDQXZCQSxDQUFBO2FBd0JBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLFNBQWQsRUFBeUIsY0FBekIsRUF6Qk87SUFBQSxDQXBDVCxDQUFBOztBQUFBLHNCQWdFQSxJQUFBLEdBQU0sU0FBQSxHQUFBO0FBQ0osTUFBQSxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxNQUFkLENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxJQUFSLENBQUEsQ0FEQSxDQUFBO2FBRUEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsU0FBZCxFQUhJO0lBQUEsQ0FoRU4sQ0FBQTs7QUFBQSxzQkFzRUEsT0FBQSxHQUFTLFNBQUMsUUFBRCxHQUFBO2FBQ1AsSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksT0FBWixFQUFxQixRQUFyQixFQURPO0lBQUEsQ0F0RVQsQ0FBQTs7QUFBQSxzQkEwRUEsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBO2FBQ1QsSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksU0FBWixFQUF1QixRQUF2QixFQURTO0lBQUEsQ0ExRVgsQ0FBQTs7QUFBQSxzQkE4RUEsTUFBQSxHQUFRLFNBQUMsUUFBRCxHQUFBO2FBQ04sSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksTUFBWixFQUFvQixRQUFwQixFQURNO0lBQUEsQ0E5RVIsQ0FBQTs7QUFBQSxzQkFrRkEsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBO2FBQ1QsSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksU0FBWixFQUF1QixRQUF2QixFQURTO0lBQUEsQ0FsRlgsQ0FBQTs7QUFBQSxzQkFzRkEsdUJBQUEsR0FBeUIsU0FBQyxRQUFELEdBQUE7YUFDdkIsSUFBQyxDQUFBLGtCQUFrQixDQUFDLHVCQUFwQixDQUE0QyxRQUE1QyxFQUR1QjtJQUFBLENBdEZ6QixDQUFBOztBQUFBLHNCQTJGQSx1QkFBQSxHQUF5QixTQUFDLFFBQUQsR0FBQTthQUN2QixJQUFDLENBQUEsa0JBQWtCLENBQUMsdUJBQXBCLENBQTRDLFFBQTVDLEVBRHVCO0lBQUEsQ0EzRnpCLENBQUE7O0FBQUEsc0JBaUdBLG1CQUFBLEdBQXFCLFNBQUMsUUFBRCxHQUFBO2FBQ25CLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLHNCQUFaLEVBQW9DLFFBQXBDLEVBRG1CO0lBQUEsQ0FqR3JCLENBQUE7O0FBQUEsc0JBc0dBLGlCQUFBLEdBQW1CLFNBQUMsUUFBRCxHQUFBO2FBQ2pCLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLG9CQUFaLEVBQWtDLFFBQWxDLEVBRGlCO0lBQUEsQ0F0R25CLENBQUE7O0FBQUEsc0JBNkdBLGtCQUFBLEdBQW9CLFNBQUMsUUFBRCxHQUFBO2FBQ2xCLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLG9CQUFaLEVBQWtDLFFBQWxDLEVBRGtCO0lBQUEsQ0E3R3BCLENBQUE7O0FBQUEsc0JBa0hBLGtCQUFBLEdBQW9CLFNBQUMsUUFBRCxHQUFBO2FBQ2xCLElBQUMsQ0FBQSxNQUFNLENBQUMsa0JBQVIsQ0FBMkIsUUFBM0IsRUFEa0I7SUFBQSxDQWxIcEIsQ0FBQTs7QUFBQSxzQkF1SEEsa0JBQUEsR0FBb0IsU0FBQyxRQUFELEdBQUE7YUFDbEIsSUFBQyxDQUFBLE1BQU0sQ0FBQyxrQkFBUixDQUEyQixRQUEzQixFQURrQjtJQUFBLENBdkhwQixDQUFBOztBQUFBLHNCQTZIQSxTQUFBLEdBQVcsU0FBQyxRQUFELEdBQUE7YUFDVCxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsQ0FBa0IsUUFBbEIsRUFEUztJQUFBLENBN0hYLENBQUE7O0FBQUEsc0JBa0lBLFdBQUEsR0FBYSxTQUFDLFFBQUQsR0FBQTthQUNYLElBQUMsQ0FBQSxNQUFNLENBQUMsV0FBUixDQUFvQixRQUFwQixFQURXO0lBQUEsQ0FsSWIsQ0FBQTs7QUFBQSxzQkFxSUEsZ0JBQUEsR0FBa0IsU0FBQyxPQUFELEVBQVUsSUFBVixHQUFBO2FBQ2hCLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLHNCQUFkLEVBQXNDO0FBQUEsUUFBRSxTQUFBLE9BQUY7QUFBQSxRQUFXLE1BQUEsSUFBWDtPQUF0QyxFQURnQjtJQUFBLENBcklsQixDQUFBOztBQUFBLHNCQXdJQSxlQUFBLEdBQWlCLFNBQUMsS0FBRCxHQUFBO2FBQ2YsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsb0JBQWQsRUFBb0M7QUFBQSxRQUFFLEtBQUEsRUFBTyxLQUFUO09BQXBDLEVBRGU7SUFBQSxDQXhJakIsQ0FBQTs7bUJBQUE7O01BUkYsQ0FBQTtBQUFBIgp9

//# sourceURL=/Users/anthony/.atom/packages/script/lib/runtime.coffee
