(function() {
  var StatusInProgress;

  module.exports = StatusInProgress = (function() {
    StatusInProgress.prototype.actions = [];

    function StatusInProgress() {
      this.span = document.createElement("span");
      this.span.className = "inline-block text-subtle";
      this.span.innerHTML = "Indexing..";
      this.progress = document.createElement("progress");
      this.container = document.createElement("div");
      this.container.className = "inline-block";
      this.subcontainer = document.createElement("div");
      this.subcontainer.className = "block";
      this.container.appendChild(this.subcontainer);
      this.subcontainer.appendChild(this.progress);
      this.subcontainer.appendChild(this.span);
    }

    StatusInProgress.prototype.initialize = function(statusBar) {
      this.statusBar = statusBar;
    };

    StatusInProgress.prototype.update = function(text, show) {
      if (show) {
        this.container.className = "inline-block";
        this.span.innerHTML = text;
        return this.actions.push(text);
      } else {
        this.actions.forEach(function(value, index) {
          if (value === text) {
            return this.actions.splice(index, 1);
          }
        }, this);
        if (this.actions.length === 0) {
          return this.hide();
        } else {
          return this.span.innerHTML = this.actions[0];
        }
      }
    };

    StatusInProgress.prototype.hide = function() {
      return this.container.className = 'hidden';
    };

    StatusInProgress.prototype.attach = function() {
      return this.tile = this.statusBar.addRightTile({
        item: this.container,
        priority: 19
      });
    };

    StatusInProgress.prototype.detach = function() {
      return this.tile.destroy();
    };

    return StatusInProgress;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9zZXJ2aWNlcy9zdGF0dXMtaW4tcHJvZ3Jlc3MuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxNQUFNLENBQUMsT0FBUCxHQUtNOytCQUNKLE9BQUEsR0FBUzs7SUFFSSwwQkFBQTtNQUNYLElBQUMsQ0FBQSxJQUFELEdBQVEsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsTUFBdkI7TUFDUixJQUFDLENBQUEsSUFBSSxDQUFDLFNBQU4sR0FBa0I7TUFDbEIsSUFBQyxDQUFBLElBQUksQ0FBQyxTQUFOLEdBQWtCO01BRWxCLElBQUMsQ0FBQSxRQUFELEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsVUFBdkI7TUFFWixJQUFDLENBQUEsU0FBRCxHQUFhLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCO01BQ2IsSUFBQyxDQUFBLFNBQVMsQ0FBQyxTQUFYLEdBQXVCO01BRXZCLElBQUMsQ0FBQSxZQUFELEdBQWdCLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCO01BQ2hCLElBQUMsQ0FBQSxZQUFZLENBQUMsU0FBZCxHQUEwQjtNQUMxQixJQUFDLENBQUEsU0FBUyxDQUFDLFdBQVgsQ0FBdUIsSUFBQyxDQUFBLFlBQXhCO01BRUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxXQUFkLENBQTBCLElBQUMsQ0FBQSxRQUEzQjtNQUNBLElBQUMsQ0FBQSxZQUFZLENBQUMsV0FBZCxDQUEwQixJQUFDLENBQUEsSUFBM0I7SUFmVzs7K0JBaUJiLFVBQUEsR0FBWSxTQUFDLFNBQUQ7TUFBQyxJQUFDLENBQUEsWUFBRDtJQUFEOzsrQkFFWixNQUFBLEdBQVEsU0FBQyxJQUFELEVBQU8sSUFBUDtNQUNOLElBQUcsSUFBSDtRQUNJLElBQUMsQ0FBQSxTQUFTLENBQUMsU0FBWCxHQUF1QjtRQUN2QixJQUFDLENBQUEsSUFBSSxDQUFDLFNBQU4sR0FBa0I7ZUFDbEIsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsSUFBZCxFQUhKO09BQUEsTUFBQTtRQUtJLElBQUMsQ0FBQSxPQUFPLENBQUMsT0FBVCxDQUFpQixTQUFDLEtBQUQsRUFBUSxLQUFSO1VBQ2IsSUFBRyxLQUFBLEtBQVMsSUFBWjttQkFDSSxJQUFDLENBQUEsT0FBTyxDQUFDLE1BQVQsQ0FBZ0IsS0FBaEIsRUFBdUIsQ0FBdkIsRUFESjs7UUFEYSxDQUFqQixFQUdFLElBSEY7UUFLQSxJQUFHLElBQUMsQ0FBQSxPQUFPLENBQUMsTUFBVCxLQUFtQixDQUF0QjtpQkFDSSxJQUFDLENBQUEsSUFBRCxDQUFBLEVBREo7U0FBQSxNQUFBO2lCQUdJLElBQUMsQ0FBQSxJQUFJLENBQUMsU0FBTixHQUFrQixJQUFDLENBQUEsT0FBUSxDQUFBLENBQUEsRUFIL0I7U0FWSjs7SUFETTs7K0JBZ0JSLElBQUEsR0FBTSxTQUFBO2FBQ0osSUFBQyxDQUFBLFNBQVMsQ0FBQyxTQUFYLEdBQXVCO0lBRG5COzsrQkFHTixNQUFBLEdBQVEsU0FBQTthQUNOLElBQUMsQ0FBQSxJQUFELEdBQVEsSUFBQyxDQUFBLFNBQVMsQ0FBQyxZQUFYLENBQXdCO1FBQUEsSUFBQSxFQUFNLElBQUMsQ0FBQSxTQUFQO1FBQWtCLFFBQUEsRUFBVSxFQUE1QjtPQUF4QjtJQURGOzsrQkFHUixNQUFBLEdBQVEsU0FBQTthQUNOLElBQUMsQ0FBQSxJQUFJLENBQUMsT0FBTixDQUFBO0lBRE07Ozs7O0FBakRWIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPVxuXG4jIypcbiMgUHJvZ3Jlc3MgYmFyIGluIHRoZSBzdGF0dXMgYmFyXG4jI1xuY2xhc3MgU3RhdHVzSW5Qcm9ncmVzc1xuICBhY3Rpb25zOiBbXVxuXG4gIGNvbnN0cnVjdG9yOiAtPlxuICAgIEBzcGFuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIilcbiAgICBAc3Bhbi5jbGFzc05hbWUgPSBcImlubGluZS1ibG9jayB0ZXh0LXN1YnRsZVwiXG4gICAgQHNwYW4uaW5uZXJIVE1MID0gXCJJbmRleGluZy4uXCJcblxuICAgIEBwcm9ncmVzcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJwcm9ncmVzc1wiKVxuXG4gICAgQGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIilcbiAgICBAY29udGFpbmVyLmNsYXNzTmFtZSA9IFwiaW5saW5lLWJsb2NrXCJcblxuICAgIEBzdWJjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gICAgQHN1YmNvbnRhaW5lci5jbGFzc05hbWUgPSBcImJsb2NrXCJcbiAgICBAY29udGFpbmVyLmFwcGVuZENoaWxkKEBzdWJjb250YWluZXIpXG5cbiAgICBAc3ViY29udGFpbmVyLmFwcGVuZENoaWxkKEBwcm9ncmVzcylcbiAgICBAc3ViY29udGFpbmVyLmFwcGVuZENoaWxkKEBzcGFuKVxuXG4gIGluaXRpYWxpemU6IChAc3RhdHVzQmFyKSAtPlxuXG4gIHVwZGF0ZTogKHRleHQsIHNob3cpIC0+XG4gICAgaWYgc2hvd1xuICAgICAgICBAY29udGFpbmVyLmNsYXNzTmFtZSA9IFwiaW5saW5lLWJsb2NrXCJcbiAgICAgICAgQHNwYW4uaW5uZXJIVE1MID0gdGV4dFxuICAgICAgICBAYWN0aW9ucy5wdXNoKHRleHQpXG4gICAgZWxzZVxuICAgICAgICBAYWN0aW9ucy5mb3JFYWNoKCh2YWx1ZSwgaW5kZXgpIC0+XG4gICAgICAgICAgICBpZiB2YWx1ZSA9PSB0ZXh0XG4gICAgICAgICAgICAgICAgQGFjdGlvbnMuc3BsaWNlKGluZGV4LCAxKVxuICAgICAgICAsIEApXG5cbiAgICAgICAgaWYgQGFjdGlvbnMubGVuZ3RoID09IDBcbiAgICAgICAgICAgIEBoaWRlKClcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgQHNwYW4uaW5uZXJIVE1MID0gQGFjdGlvbnNbMF1cblxuICBoaWRlOiAtPlxuICAgIEBjb250YWluZXIuY2xhc3NOYW1lID0gJ2hpZGRlbidcblxuICBhdHRhY2g6IC0+XG4gICAgQHRpbGUgPSBAc3RhdHVzQmFyLmFkZFJpZ2h0VGlsZShpdGVtOiBAY29udGFpbmVyLCBwcmlvcml0eTogMTkpXG5cbiAgZGV0YWNoOiAtPlxuICAgIEB0aWxlLmRlc3Ryb3koKVxuIl19
