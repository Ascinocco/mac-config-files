(function() {
  var $$, CompositeDisposable, Emitter, ScriptInputView, ScriptProfileRunView, SelectListView, View, _ref, _ref1,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ref = require('atom'), CompositeDisposable = _ref.CompositeDisposable, Emitter = _ref.Emitter;

  _ref1 = require('atom-space-pen-views'), $$ = _ref1.$$, View = _ref1.View, SelectListView = _ref1.SelectListView;

  ScriptInputView = require('./script-input-view');

  module.exports = ScriptProfileRunView = (function(_super) {
    __extends(ScriptProfileRunView, _super);

    function ScriptProfileRunView() {
      return ScriptProfileRunView.__super__.constructor.apply(this, arguments);
    }

    ScriptProfileRunView.prototype.initialize = function(profiles) {
      this.profiles = profiles;
      ScriptProfileRunView.__super__.initialize.apply(this, arguments);
      this.emitter = new Emitter;
      this.subscriptions = new CompositeDisposable;
      this.subscriptions.add(atom.commands.add('atom-workspace', {
        'core:cancel': (function(_this) {
          return function() {
            return _this.hide();
          };
        })(this),
        'core:close': (function(_this) {
          return function() {
            return _this.hide();
          };
        })(this),
        'script:run-with-profile': (function(_this) {
          return function() {
            if (_this.panel.isVisible()) {
              return _this.hide();
            } else {
              return _this.show();
            }
          };
        })(this)
      }));
      this.setItems(this.profiles);
      return this.initializeView();
    };

    ScriptProfileRunView.prototype.initializeView = function() {
      var selector;
      this.addClass('overlay from-top script-profile-run-view');
      this.buttons = $$(function() {
        return this.div({
          "class": 'block buttons'
        }, (function(_this) {
          return function() {
            var css;
            css = 'btn inline-block-tight';
            _this.button({
              "class": "btn cancel"
            }, function() {
              return _this.span({
                "class": 'icon icon-x'
              }, 'Cancel');
            });
            _this.button({
              "class": "btn rename"
            }, function() {
              return _this.span({
                "class": 'icon icon-pencil'
              }, 'Rename');
            });
            _this.button({
              "class": "btn delete"
            }, function() {
              return _this.span({
                "class": 'icon icon-trashcan'
              }, 'Delete');
            });
            return _this.button({
              "class": "btn run"
            }, function() {
              return _this.span({
                "class": 'icon icon-playback-play'
              }, 'Run');
            });
          };
        })(this));
      });
      this.buttons.find('.btn.cancel').on('click', (function(_this) {
        return function() {
          return _this.hide();
        };
      })(this));
      this.buttons.find('.btn.rename').on('click', (function(_this) {
        return function() {
          return _this.rename();
        };
      })(this));
      this.buttons.find('.btn.delete').on('click', (function(_this) {
        return function() {
          return _this["delete"]();
        };
      })(this));
      this.buttons.find('.btn.run').on('click', (function(_this) {
        return function() {
          return _this.run();
        };
      })(this));
      this.buttons.find('.btn.run').on('keydown', (function(_this) {
        return function(e) {
          if (e.keyCode === 9) {
            e.stopPropagation();
            e.preventDefault();
            return _this.focusFilterEditor();
          }
        };
      })(this));
      this.on('keydown', (function(_this) {
        return function(e) {
          if (e.keyCode === 27) {
            _this.hide();
          }
          if (e.keyCode === 13) {
            return _this.run();
          }
        };
      })(this));
      this.append(this.buttons);
      selector = '.rename, .delete, .run';
      if (this.profiles.length) {
        this.buttons.find(selector).show();
      } else {
        this.buttons.find(selector).hide();
      }
      this.panel = atom.workspace.addModalPanel({
        item: this
      });
      return this.panel.hide();
    };

    ScriptProfileRunView.prototype.onProfileDelete = function(callback) {
      return this.emitter.on('on-profile-delete', callback);
    };

    ScriptProfileRunView.prototype.onProfileChange = function(callback) {
      return this.emitter.on('on-profile-change', callback);
    };

    ScriptProfileRunView.prototype.onProfileRun = function(callback) {
      return this.emitter.on('on-profile-run', callback);
    };

    ScriptProfileRunView.prototype.rename = function() {
      var inputView, profile;
      profile = this.getSelectedItem();
      if (!profile) {
        return;
      }
      inputView = new ScriptInputView({
        caption: 'Enter new profile name:',
        "default": profile.name
      });
      inputView.onCancel((function(_this) {
        return function() {
          return _this.show();
        };
      })(this));
      inputView.onConfirm((function(_this) {
        return function(newProfileName) {
          if (!newProfileName) {
            return;
          }
          return _this.emitter.emit('on-profile-change', {
            profile: profile,
            key: 'name',
            value: newProfileName
          });
        };
      })(this));
      return inputView.show();
    };

    ScriptProfileRunView.prototype["delete"] = function() {
      var profile;
      profile = this.getSelectedItem();
      if (!profile) {
        return;
      }
      return atom.confirm({
        message: 'Delete profile',
        detailedMessage: "Are you sure you want to delete \"" + profile.name + "\" profile?",
        buttons: {
          No: (function(_this) {
            return function() {
              return _this.focusFilterEditor();
            };
          })(this),
          Yes: (function(_this) {
            return function() {
              return _this.emitter.emit('on-profile-delete', profile);
            };
          })(this)
        }
      });
    };

    ScriptProfileRunView.prototype.getFilterKey = function() {
      return 'name';
    };

    ScriptProfileRunView.prototype.getEmptyMessage = function() {
      return 'No profiles found';
    };

    ScriptProfileRunView.prototype.viewForItem = function(item) {
      return $$(function() {
        return this.li({
          "class": 'two-lines profile'
        }, (function(_this) {
          return function() {
            _this.div({
              "class": 'primary-line name'
            }, function() {
              return _this.text(item.name);
            });
            return _this.div({
              "class": 'secondary-line description'
            }, function() {
              return _this.text(item.description);
            });
          };
        })(this));
      });
    };

    ScriptProfileRunView.prototype.cancel = function() {};

    ScriptProfileRunView.prototype.confirmed = function(item) {};

    ScriptProfileRunView.prototype.show = function() {
      this.panel.show();
      return this.focusFilterEditor();
    };

    ScriptProfileRunView.prototype.hide = function() {
      this.panel.hide();
      return atom.workspace.getActivePane().activate();
    };

    ScriptProfileRunView.prototype.setProfiles = function(profiles) {
      var selector;
      this.profiles = profiles;
      this.setItems(this.profiles);
      selector = '.rename, .delete, .run';
      if (this.profiles.length) {
        this.buttons.find(selector).show();
      } else {
        this.buttons.find(selector).hide();
      }
      this.populateList();
      return this.focusFilterEditor();
    };

    ScriptProfileRunView.prototype.close = function() {};

    ScriptProfileRunView.prototype.destroy = function() {
      var _ref2;
      return (_ref2 = this.subscriptions) != null ? _ref2.dispose() : void 0;
    };

    ScriptProfileRunView.prototype.run = function() {
      var profile;
      profile = this.getSelectedItem();
      if (!profile) {
        return;
      }
      this.emitter.emit('on-profile-run', profile);
      return this.hide();
    };

    return ScriptProfileRunView;

  })(SelectListView);

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9zY3JpcHQtcHJvZmlsZS1ydW4tdmlldy5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsMEdBQUE7SUFBQTttU0FBQTs7QUFBQSxFQUFBLE9BQWlDLE9BQUEsQ0FBUSxNQUFSLENBQWpDLEVBQUMsMkJBQUEsbUJBQUQsRUFBc0IsZUFBQSxPQUF0QixDQUFBOztBQUFBLEVBQ0EsUUFBNkIsT0FBQSxDQUFRLHNCQUFSLENBQTdCLEVBQUMsV0FBQSxFQUFELEVBQUssYUFBQSxJQUFMLEVBQVcsdUJBQUEsY0FEWCxDQUFBOztBQUFBLEVBRUEsZUFBQSxHQUFrQixPQUFBLENBQVEscUJBQVIsQ0FGbEIsQ0FBQTs7QUFBQSxFQUlBLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFDSiwyQ0FBQSxDQUFBOzs7O0tBQUE7O0FBQUEsbUNBQUEsVUFBQSxHQUFZLFNBQUUsUUFBRixHQUFBO0FBQ1YsTUFEVyxJQUFDLENBQUEsV0FBQSxRQUNaLENBQUE7QUFBQSxNQUFBLHNEQUFBLFNBQUEsQ0FBQSxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsT0FBRCxHQUFXLEdBQUEsQ0FBQSxPQUZYLENBQUE7QUFBQSxNQUlBLElBQUMsQ0FBQSxhQUFELEdBQWlCLEdBQUEsQ0FBQSxtQkFKakIsQ0FBQTtBQUFBLE1BS0EsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQW1CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFDakI7QUFBQSxRQUFBLGFBQUEsRUFBZSxDQUFBLFNBQUEsS0FBQSxHQUFBO2lCQUFBLFNBQUEsR0FBQTttQkFBRyxLQUFDLENBQUEsSUFBRCxDQUFBLEVBQUg7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFmO0FBQUEsUUFDQSxZQUFBLEVBQWMsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7bUJBQUcsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEZDtBQUFBLFFBRUEseUJBQUEsRUFBMkIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7QUFBRyxZQUFBLElBQUcsS0FBQyxDQUFBLEtBQUssQ0FBQyxTQUFQLENBQUEsQ0FBSDtxQkFBMkIsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUEzQjthQUFBLE1BQUE7cUJBQXdDLEtBQUMsQ0FBQSxJQUFELENBQUEsRUFBeEM7YUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRjNCO09BRGlCLENBQW5CLENBTEEsQ0FBQTtBQUFBLE1BVUEsSUFBQyxDQUFBLFFBQUQsQ0FBVSxJQUFDLENBQUEsUUFBWCxDQVZBLENBQUE7YUFXQSxJQUFDLENBQUEsY0FBRCxDQUFBLEVBWlU7SUFBQSxDQUFaLENBQUE7O0FBQUEsbUNBY0EsY0FBQSxHQUFnQixTQUFBLEdBQUE7QUFDZCxVQUFBLFFBQUE7QUFBQSxNQUFBLElBQUMsQ0FBQSxRQUFELENBQVUsMENBQVYsQ0FBQSxDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsT0FBRCxHQUFXLEVBQUEsQ0FBRyxTQUFBLEdBQUE7ZUFDWixJQUFDLENBQUEsR0FBRCxDQUFLO0FBQUEsVUFBQSxPQUFBLEVBQU8sZUFBUDtTQUFMLEVBQTZCLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO0FBQzNCLGdCQUFBLEdBQUE7QUFBQSxZQUFBLEdBQUEsR0FBTSx3QkFBTixDQUFBO0FBQUEsWUFDQSxLQUFDLENBQUEsTUFBRCxDQUFRO0FBQUEsY0FBQSxPQUFBLEVBQU8sWUFBUDthQUFSLEVBQTZCLFNBQUEsR0FBQTtxQkFDM0IsS0FBQyxDQUFBLElBQUQsQ0FBTTtBQUFBLGdCQUFBLE9BQUEsRUFBTyxhQUFQO2VBQU4sRUFBNEIsUUFBNUIsRUFEMkI7WUFBQSxDQUE3QixDQURBLENBQUE7QUFBQSxZQUdBLEtBQUMsQ0FBQSxNQUFELENBQVE7QUFBQSxjQUFBLE9BQUEsRUFBTyxZQUFQO2FBQVIsRUFBNkIsU0FBQSxHQUFBO3FCQUMzQixLQUFDLENBQUEsSUFBRCxDQUFNO0FBQUEsZ0JBQUEsT0FBQSxFQUFPLGtCQUFQO2VBQU4sRUFBaUMsUUFBakMsRUFEMkI7WUFBQSxDQUE3QixDQUhBLENBQUE7QUFBQSxZQUtBLEtBQUMsQ0FBQSxNQUFELENBQVE7QUFBQSxjQUFBLE9BQUEsRUFBTyxZQUFQO2FBQVIsRUFBNkIsU0FBQSxHQUFBO3FCQUMzQixLQUFDLENBQUEsSUFBRCxDQUFNO0FBQUEsZ0JBQUEsT0FBQSxFQUFPLG9CQUFQO2VBQU4sRUFBbUMsUUFBbkMsRUFEMkI7WUFBQSxDQUE3QixDQUxBLENBQUE7bUJBT0EsS0FBQyxDQUFBLE1BQUQsQ0FBUTtBQUFBLGNBQUEsT0FBQSxFQUFPLFNBQVA7YUFBUixFQUEwQixTQUFBLEdBQUE7cUJBQ3hCLEtBQUMsQ0FBQSxJQUFELENBQU07QUFBQSxnQkFBQSxPQUFBLEVBQU8seUJBQVA7ZUFBTixFQUF3QyxLQUF4QyxFQUR3QjtZQUFBLENBQTFCLEVBUjJCO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBN0IsRUFEWTtNQUFBLENBQUgsQ0FIWCxDQUFBO0FBQUEsTUFnQkEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsYUFBZCxDQUE0QixDQUFDLEVBQTdCLENBQWdDLE9BQWhDLEVBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7aUJBQUcsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUFIO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsQ0FoQkEsQ0FBQTtBQUFBLE1BaUJBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLGFBQWQsQ0FBNEIsQ0FBQyxFQUE3QixDQUFnQyxPQUFoQyxFQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUFHLEtBQUMsQ0FBQSxNQUFELENBQUEsRUFBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLENBakJBLENBQUE7QUFBQSxNQWtCQSxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxhQUFkLENBQTRCLENBQUMsRUFBN0IsQ0FBZ0MsT0FBaEMsRUFBeUMsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtpQkFBRyxLQUFDLENBQUEsUUFBQSxDQUFELENBQUEsRUFBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDLENBbEJBLENBQUE7QUFBQSxNQW1CQSxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxVQUFkLENBQXlCLENBQUMsRUFBMUIsQ0FBNkIsT0FBN0IsRUFBc0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtpQkFBRyxLQUFDLENBQUEsR0FBRCxDQUFBLEVBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF0QyxDQW5CQSxDQUFBO0FBQUEsTUFzQkEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsVUFBZCxDQUF5QixDQUFDLEVBQTFCLENBQTZCLFNBQTdCLEVBQXdDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtBQUN0QyxVQUFBLElBQUcsQ0FBQyxDQUFDLE9BQUYsS0FBYSxDQUFoQjtBQUNFLFlBQUEsQ0FBQyxDQUFDLGVBQUYsQ0FBQSxDQUFBLENBQUE7QUFBQSxZQUNBLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FEQSxDQUFBO21CQUVBLEtBQUMsQ0FBQSxpQkFBRCxDQUFBLEVBSEY7V0FEc0M7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF4QyxDQXRCQSxDQUFBO0FBQUEsTUE2QkEsSUFBQyxDQUFDLEVBQUYsQ0FBSyxTQUFMLEVBQWdCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtBQUNkLFVBQUEsSUFBVyxDQUFDLENBQUMsT0FBRixLQUFhLEVBQXhCO0FBQUEsWUFBQSxLQUFDLENBQUEsSUFBRCxDQUFBLENBQUEsQ0FBQTtXQUFBO0FBQ0EsVUFBQSxJQUFVLENBQUMsQ0FBQyxPQUFGLEtBQWEsRUFBdkI7bUJBQUEsS0FBQyxDQUFBLEdBQUQsQ0FBQSxFQUFBO1dBRmM7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQixDQTdCQSxDQUFBO0FBQUEsTUFrQ0EsSUFBQyxDQUFBLE1BQUQsQ0FBUSxJQUFDLENBQUEsT0FBVCxDQWxDQSxDQUFBO0FBQUEsTUFvQ0EsUUFBQSxHQUFXLHdCQXBDWCxDQUFBO0FBcUNBLE1BQUEsSUFBRyxJQUFDLENBQUEsUUFBUSxDQUFDLE1BQWI7QUFBeUIsUUFBQSxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxRQUFkLENBQXVCLENBQUMsSUFBeEIsQ0FBQSxDQUFBLENBQXpCO09BQUEsTUFBQTtBQUE2RCxRQUFBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLFFBQWQsQ0FBdUIsQ0FBQyxJQUF4QixDQUFBLENBQUEsQ0FBN0Q7T0FyQ0E7QUFBQSxNQXVDQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBZixDQUE2QjtBQUFBLFFBQUEsSUFBQSxFQUFNLElBQU47T0FBN0IsQ0F2Q1QsQ0FBQTthQXdDQSxJQUFDLENBQUEsS0FBSyxDQUFDLElBQVAsQ0FBQSxFQXpDYztJQUFBLENBZGhCLENBQUE7O0FBQUEsbUNBeURBLGVBQUEsR0FBaUIsU0FBQyxRQUFELEdBQUE7YUFBYyxJQUFDLENBQUEsT0FBTyxDQUFDLEVBQVQsQ0FBWSxtQkFBWixFQUFpQyxRQUFqQyxFQUFkO0lBQUEsQ0F6RGpCLENBQUE7O0FBQUEsbUNBMERBLGVBQUEsR0FBaUIsU0FBQyxRQUFELEdBQUE7YUFBYyxJQUFDLENBQUEsT0FBTyxDQUFDLEVBQVQsQ0FBWSxtQkFBWixFQUFpQyxRQUFqQyxFQUFkO0lBQUEsQ0ExRGpCLENBQUE7O0FBQUEsbUNBMkRBLFlBQUEsR0FBYyxTQUFDLFFBQUQsR0FBQTthQUFjLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLGdCQUFaLEVBQThCLFFBQTlCLEVBQWQ7SUFBQSxDQTNEZCxDQUFBOztBQUFBLG1DQTZEQSxNQUFBLEdBQVEsU0FBQSxHQUFBO0FBQ04sVUFBQSxrQkFBQTtBQUFBLE1BQUEsT0FBQSxHQUFVLElBQUMsQ0FBQSxlQUFELENBQUEsQ0FBVixDQUFBO0FBQ0EsTUFBQSxJQUFBLENBQUEsT0FBQTtBQUFBLGNBQUEsQ0FBQTtPQURBO0FBQUEsTUFHQSxTQUFBLEdBQWdCLElBQUEsZUFBQSxDQUFnQjtBQUFBLFFBQUEsT0FBQSxFQUFTLHlCQUFUO0FBQUEsUUFBb0MsU0FBQSxFQUFTLE9BQU8sQ0FBQyxJQUFyRDtPQUFoQixDQUhoQixDQUFBO0FBQUEsTUFJQSxTQUFTLENBQUMsUUFBVixDQUFtQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUFHLEtBQUMsQ0FBQSxJQUFELENBQUEsRUFBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQW5CLENBSkEsQ0FBQTtBQUFBLE1BS0EsU0FBUyxDQUFDLFNBQVYsQ0FBb0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsY0FBRCxHQUFBO0FBQ2xCLFVBQUEsSUFBQSxDQUFBLGNBQUE7QUFBQSxrQkFBQSxDQUFBO1dBQUE7aUJBQ0EsS0FBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsbUJBQWQsRUFBbUM7QUFBQSxZQUFBLE9BQUEsRUFBUyxPQUFUO0FBQUEsWUFBa0IsR0FBQSxFQUFLLE1BQXZCO0FBQUEsWUFBK0IsS0FBQSxFQUFPLGNBQXRDO1dBQW5DLEVBRmtCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBcEIsQ0FMQSxDQUFBO2FBU0EsU0FBUyxDQUFDLElBQVYsQ0FBQSxFQVZNO0lBQUEsQ0E3RFIsQ0FBQTs7QUFBQSxtQ0F5RUEsU0FBQSxHQUFRLFNBQUEsR0FBQTtBQUNOLFVBQUEsT0FBQTtBQUFBLE1BQUEsT0FBQSxHQUFVLElBQUMsQ0FBQSxlQUFELENBQUEsQ0FBVixDQUFBO0FBQ0EsTUFBQSxJQUFBLENBQUEsT0FBQTtBQUFBLGNBQUEsQ0FBQTtPQURBO2FBR0EsSUFBSSxDQUFDLE9BQUwsQ0FDRTtBQUFBLFFBQUEsT0FBQSxFQUFTLGdCQUFUO0FBQUEsUUFDQSxlQUFBLEVBQWtCLG9DQUFBLEdBQW9DLE9BQU8sQ0FBQyxJQUE1QyxHQUFpRCxhQURuRTtBQUFBLFFBRUEsT0FBQSxFQUNFO0FBQUEsVUFBQSxFQUFBLEVBQUksQ0FBQSxTQUFBLEtBQUEsR0FBQTttQkFBQSxTQUFBLEdBQUE7cUJBQUcsS0FBQyxDQUFBLGlCQUFELENBQUEsRUFBSDtZQUFBLEVBQUE7VUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQUo7QUFBQSxVQUNBLEdBQUEsRUFBSyxDQUFBLFNBQUEsS0FBQSxHQUFBO21CQUFBLFNBQUEsR0FBQTtxQkFBRyxLQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxtQkFBZCxFQUFtQyxPQUFuQyxFQUFIO1lBQUEsRUFBQTtVQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FETDtTQUhGO09BREYsRUFKTTtJQUFBLENBekVSLENBQUE7O0FBQUEsbUNBb0ZBLFlBQUEsR0FBYyxTQUFBLEdBQUE7YUFDWixPQURZO0lBQUEsQ0FwRmQsQ0FBQTs7QUFBQSxtQ0F1RkEsZUFBQSxHQUFpQixTQUFBLEdBQUE7YUFDZixvQkFEZTtJQUFBLENBdkZqQixDQUFBOztBQUFBLG1DQTBGQSxXQUFBLEdBQWEsU0FBQyxJQUFELEdBQUE7YUFDWCxFQUFBLENBQUcsU0FBQSxHQUFBO2VBQUcsSUFBQyxDQUFBLEVBQUQsQ0FBSTtBQUFBLFVBQUEsT0FBQSxFQUFPLG1CQUFQO1NBQUosRUFBZ0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7QUFDcEMsWUFBQSxLQUFDLENBQUEsR0FBRCxDQUFLO0FBQUEsY0FBQSxPQUFBLEVBQU8sbUJBQVA7YUFBTCxFQUFpQyxTQUFBLEdBQUE7cUJBQy9CLEtBQUMsQ0FBQSxJQUFELENBQU0sSUFBSSxDQUFDLElBQVgsRUFEK0I7WUFBQSxDQUFqQyxDQUFBLENBQUE7bUJBRUEsS0FBQyxDQUFBLEdBQUQsQ0FBSztBQUFBLGNBQUEsT0FBQSxFQUFPLDRCQUFQO2FBQUwsRUFBMEMsU0FBQSxHQUFBO3FCQUN4QyxLQUFDLENBQUEsSUFBRCxDQUFNLElBQUksQ0FBQyxXQUFYLEVBRHdDO1lBQUEsQ0FBMUMsRUFIb0M7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQyxFQUFIO01BQUEsQ0FBSCxFQURXO0lBQUEsQ0ExRmIsQ0FBQTs7QUFBQSxtQ0FpR0EsTUFBQSxHQUFRLFNBQUEsR0FBQSxDQWpHUixDQUFBOztBQUFBLG1DQWtHQSxTQUFBLEdBQVcsU0FBQyxJQUFELEdBQUEsQ0FsR1gsQ0FBQTs7QUFBQSxtQ0FvR0EsSUFBQSxHQUFNLFNBQUEsR0FBQTtBQUNKLE1BQUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxJQUFQLENBQUEsQ0FBQSxDQUFBO2FBQ0EsSUFBQyxDQUFBLGlCQUFELENBQUEsRUFGSTtJQUFBLENBcEdOLENBQUE7O0FBQUEsbUNBd0dBLElBQUEsR0FBTSxTQUFBLEdBQUE7QUFDSixNQUFBLElBQUMsQ0FBQSxLQUFLLENBQUMsSUFBUCxDQUFBLENBQUEsQ0FBQTthQUNBLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBZixDQUFBLENBQThCLENBQUMsUUFBL0IsQ0FBQSxFQUZJO0lBQUEsQ0F4R04sQ0FBQTs7QUFBQSxtQ0E2R0EsV0FBQSxHQUFhLFNBQUMsUUFBRCxHQUFBO0FBQ1gsVUFBQSxRQUFBO0FBQUEsTUFBQSxJQUFDLENBQUEsUUFBRCxHQUFZLFFBQVosQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLFFBQUQsQ0FBVSxJQUFDLENBQUEsUUFBWCxDQURBLENBQUE7QUFBQSxNQUlBLFFBQUEsR0FBVyx3QkFKWCxDQUFBO0FBS0EsTUFBQSxJQUFHLElBQUMsQ0FBQSxRQUFRLENBQUMsTUFBYjtBQUF5QixRQUFBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLFFBQWQsQ0FBdUIsQ0FBQyxJQUF4QixDQUFBLENBQUEsQ0FBekI7T0FBQSxNQUFBO0FBQTZELFFBQUEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsUUFBZCxDQUF1QixDQUFDLElBQXhCLENBQUEsQ0FBQSxDQUE3RDtPQUxBO0FBQUEsTUFPQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBUEEsQ0FBQTthQVFBLElBQUMsQ0FBQSxpQkFBRCxDQUFBLEVBVFc7SUFBQSxDQTdHYixDQUFBOztBQUFBLG1DQXdIQSxLQUFBLEdBQU8sU0FBQSxHQUFBLENBeEhQLENBQUE7O0FBQUEsbUNBMEhBLE9BQUEsR0FBUyxTQUFBLEdBQUE7QUFDUCxVQUFBLEtBQUE7eURBQWMsQ0FBRSxPQUFoQixDQUFBLFdBRE87SUFBQSxDQTFIVCxDQUFBOztBQUFBLG1DQTZIQSxHQUFBLEdBQUssU0FBQSxHQUFBO0FBQ0gsVUFBQSxPQUFBO0FBQUEsTUFBQSxPQUFBLEdBQVUsSUFBQyxDQUFBLGVBQUQsQ0FBQSxDQUFWLENBQUE7QUFDQSxNQUFBLElBQUEsQ0FBQSxPQUFBO0FBQUEsY0FBQSxDQUFBO09BREE7QUFBQSxNQUdBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLGdCQUFkLEVBQWdDLE9BQWhDLENBSEEsQ0FBQTthQUlBLElBQUMsQ0FBQSxJQUFELENBQUEsRUFMRztJQUFBLENBN0hMLENBQUE7O2dDQUFBOztLQURpQyxlQUxuQyxDQUFBO0FBQUEiCn0=

//# sourceURL=/Users/anthony/.atom/packages/script/lib/script-profile-run-view.coffee
