(function() {
  var os, path;

  os = require('os');

  path = require('path');

  module.exports = {
    tempFilesDir: path.join(os.tmpdir()),
    getClassName: function(context) {
      return context.filename.replace(/\.java$/, "");
    },
    getProjectPath: function(context) {
      var projectPath, projectPaths, _i, _len, _results;
      projectPaths = atom.project.getPaths();
      _results = [];
      for (_i = 0, _len = projectPaths.length; _i < _len; _i++) {
        projectPath = projectPaths[_i];
        if (context.filepath.includes(projectPath)) {
          _results.push(projectPath);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    },
    getClassPackage: function(context) {
      var projectPath, projectRemoved;
      projectPath = module.exports.getProjectPath(context);
      projectRemoved = context.filepath.replace(projectPath + "/", "");
      return projectRemoved.replace("/" + context.filename, "");
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ncmFtbWFyLXV0aWxzL2phdmEuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQ0E7QUFBQSxNQUFBLFFBQUE7O0FBQUEsRUFBQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVIsQ0FBTCxDQUFBOztBQUFBLEVBQ0EsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSLENBRFAsQ0FBQTs7QUFBQSxFQUdBLE1BQU0sQ0FBQyxPQUFQLEdBSUU7QUFBQSxJQUFBLFlBQUEsRUFBYyxJQUFJLENBQUMsSUFBTCxDQUFVLEVBQUUsQ0FBQyxNQUFILENBQUEsQ0FBVixDQUFkO0FBQUEsSUFPQSxZQUFBLEVBQWMsU0FBQyxPQUFELEdBQUE7YUFDWixPQUFPLENBQUMsUUFBUSxDQUFDLE9BQWpCLENBQXlCLFNBQXpCLEVBQW9DLEVBQXBDLEVBRFk7SUFBQSxDQVBkO0FBQUEsSUFlQSxjQUFBLEVBQWdCLFNBQUMsT0FBRCxHQUFBO0FBQ2QsVUFBQSw2Q0FBQTtBQUFBLE1BQUEsWUFBQSxHQUFlLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBYixDQUFBLENBQWYsQ0FBQTtBQUNBO1dBQUEsbURBQUE7dUNBQUE7QUFDRSxRQUFBLElBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFqQixDQUEwQixXQUExQixDQUFIO3dCQUNFLGFBREY7U0FBQSxNQUFBO2dDQUFBO1NBREY7QUFBQTtzQkFGYztJQUFBLENBZmhCO0FBQUEsSUEwQkEsZUFBQSxFQUFpQixTQUFDLE9BQUQsR0FBQTtBQUNmLFVBQUEsMkJBQUE7QUFBQSxNQUFBLFdBQUEsR0FBYyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWYsQ0FBOEIsT0FBOUIsQ0FBZCxDQUFBO0FBQUEsTUFDQSxjQUFBLEdBQWtCLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBakIsQ0FBeUIsV0FBQSxHQUFjLEdBQXZDLEVBQTRDLEVBQTVDLENBRGxCLENBQUE7YUFFQSxjQUFjLENBQUMsT0FBZixDQUF1QixHQUFBLEdBQU0sT0FBTyxDQUFDLFFBQXJDLEVBQStDLEVBQS9DLEVBSGU7SUFBQSxDQTFCakI7R0FQRixDQUFBO0FBQUEiCn0=

//# sourceURL=/Users/anthony/.atom/packages/script/lib/grammar-utils/java.coffee
