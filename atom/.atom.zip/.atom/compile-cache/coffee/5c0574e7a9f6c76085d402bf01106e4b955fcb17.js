(function() {
  var AttachedPopover, Popover,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Popover = require('./popover');

  module.exports = AttachedPopover = (function(superClass) {
    extend(AttachedPopover, superClass);


    /*
        NOTE: The reason we do not use Atom's native tooltip is because it is attached to an element, which caused
        strange problems such as tickets #107 and #72. This implementation uses the same CSS classes and transitions but
        handles the displaying manually as we don't want to attach/detach, we only want to temporarily display a popover
        on mouseover.
     */

    AttachedPopover.prototype.timeoutId = null;

    AttachedPopover.prototype.elementToAttachTo = null;


    /**
     * Constructor.
     *
     * @param {HTMLElement} elementToAttachTo The element to show the popover over.
     * @param {int}         delay             How long the mouse has to hover over the elment before the popover shows
     *                                        up (in miliiseconds).
     */

    function AttachedPopover(elementToAttachTo, delay) {
      this.elementToAttachTo = elementToAttachTo;
      if (delay == null) {
        delay = 500;
      }
      AttachedPopover.__super__.constructor.call(this);
    }


    /**
     * Destructor.
     *
     */

    AttachedPopover.prototype.destructor = function() {
      if (this.timeoutId) {
        clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }
      return AttachedPopover.__super__.destructor.call(this);
    };


    /**
     * Shows the popover with the specified text.
     *
     * @param {int} fadeInTime The amount of time to take to fade in the tooltip.
     */

    AttachedPopover.prototype.show = function(fadeInTime) {
      var centerOffset, coordinates, x, y;
      if (fadeInTime == null) {
        fadeInTime = 100;
      }
      coordinates = this.elementToAttachTo.getBoundingClientRect();
      centerOffset = (coordinates.right - coordinates.left) / 2;
      x = coordinates.left - (this.$(this.getElement()).width() / 2) + centerOffset;
      y = coordinates.bottom;
      return AttachedPopover.__super__.show.call(this, x, y, fadeInTime);
    };


    /**
     * Shows the popover with the specified text after the specified delay (in miliiseconds). Calling this method
     * multiple times will cancel previous show requests and restart.
     *
     * @param {int}    delay      The delay before the tooltip shows up (in milliseconds).
     * @param {int}    fadeInTime The amount of time to take to fade in the tooltip.
     */

    AttachedPopover.prototype.showAfter = function(delay, fadeInTime) {
      if (fadeInTime == null) {
        fadeInTime = 100;
      }
      return this.timeoutId = setTimeout((function(_this) {
        return function() {
          return _this.show(fadeInTime);
        };
      })(this), delay);
    };

    return AttachedPopover;

  })(Popover);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9zZXJ2aWNlcy9hdHRhY2hlZC1wb3BvdmVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsd0JBQUE7SUFBQTs7O0VBQUEsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSOztFQUVWLE1BQU0sQ0FBQyxPQUFQLEdBRU07Ozs7QUFDRjs7Ozs7Ozs4QkFNQSxTQUFBLEdBQVc7OzhCQUNYLGlCQUFBLEdBQW1COzs7QUFFbkI7Ozs7Ozs7O0lBT2EseUJBQUMsaUJBQUQsRUFBcUIsS0FBckI7TUFBQyxJQUFDLENBQUEsb0JBQUQ7O1FBQW9CLFFBQVE7O01BQ3RDLCtDQUFBO0lBRFM7OztBQUdiOzs7Ozs4QkFJQSxVQUFBLEdBQVksU0FBQTtNQUNSLElBQUcsSUFBQyxDQUFBLFNBQUo7UUFDSSxZQUFBLENBQWEsSUFBQyxDQUFBLFNBQWQ7UUFDQSxJQUFDLENBQUEsU0FBRCxHQUFhLEtBRmpCOzthQUlBLDhDQUFBO0lBTFE7OztBQU9aOzs7Ozs7OEJBS0EsSUFBQSxHQUFNLFNBQUMsVUFBRDtBQUNGLFVBQUE7O1FBREcsYUFBYTs7TUFDaEIsV0FBQSxHQUFjLElBQUMsQ0FBQSxpQkFBaUIsQ0FBQyxxQkFBbkIsQ0FBQTtNQUVkLFlBQUEsR0FBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBWixHQUFvQixXQUFXLENBQUMsSUFBakMsQ0FBQSxHQUF5QztNQUV6RCxDQUFBLEdBQUksV0FBVyxDQUFDLElBQVosR0FBbUIsQ0FBQyxJQUFDLENBQUEsQ0FBRCxDQUFHLElBQUMsQ0FBQSxVQUFELENBQUEsQ0FBSCxDQUFpQixDQUFDLEtBQWxCLENBQUEsQ0FBQSxHQUE0QixDQUE3QixDQUFuQixHQUFxRDtNQUN6RCxDQUFBLEdBQUksV0FBVyxDQUFDO2FBRWhCLDBDQUFNLENBQU4sRUFBUyxDQUFULEVBQVksVUFBWjtJQVJFOzs7QUFVTjs7Ozs7Ozs7OEJBT0EsU0FBQSxHQUFXLFNBQUMsS0FBRCxFQUFRLFVBQVI7O1FBQVEsYUFBYTs7YUFDNUIsSUFBQyxDQUFBLFNBQUQsR0FBYSxVQUFBLENBQVcsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFBO2lCQUNwQixLQUFDLENBQUEsSUFBRCxDQUFNLFVBQU47UUFEb0I7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQVgsRUFFWCxLQUZXO0lBRE47Ozs7S0FyRGU7QUFKOUIiLCJzb3VyY2VzQ29udGVudCI6WyJQb3BvdmVyID0gcmVxdWlyZSAnLi9wb3BvdmVyJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5cbmNsYXNzIEF0dGFjaGVkUG9wb3ZlciBleHRlbmRzIFBvcG92ZXJcbiAgICAjIyNcbiAgICAgICAgTk9URTogVGhlIHJlYXNvbiB3ZSBkbyBub3QgdXNlIEF0b20ncyBuYXRpdmUgdG9vbHRpcCBpcyBiZWNhdXNlIGl0IGlzIGF0dGFjaGVkIHRvIGFuIGVsZW1lbnQsIHdoaWNoIGNhdXNlZFxuICAgICAgICBzdHJhbmdlIHByb2JsZW1zIHN1Y2ggYXMgdGlja2V0cyAjMTA3IGFuZCAjNzIuIFRoaXMgaW1wbGVtZW50YXRpb24gdXNlcyB0aGUgc2FtZSBDU1MgY2xhc3NlcyBhbmQgdHJhbnNpdGlvbnMgYnV0XG4gICAgICAgIGhhbmRsZXMgdGhlIGRpc3BsYXlpbmcgbWFudWFsbHkgYXMgd2UgZG9uJ3Qgd2FudCB0byBhdHRhY2gvZGV0YWNoLCB3ZSBvbmx5IHdhbnQgdG8gdGVtcG9yYXJpbHkgZGlzcGxheSBhIHBvcG92ZXJcbiAgICAgICAgb24gbW91c2VvdmVyLlxuICAgICMjI1xuICAgIHRpbWVvdXRJZDogbnVsbFxuICAgIGVsZW1lbnRUb0F0dGFjaFRvOiBudWxsXG5cbiAgICAjIyMqXG4gICAgICogQ29uc3RydWN0b3IuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBlbGVtZW50VG9BdHRhY2hUbyBUaGUgZWxlbWVudCB0byBzaG93IHRoZSBwb3BvdmVyIG92ZXIuXG4gICAgICogQHBhcmFtIHtpbnR9ICAgICAgICAgZGVsYXkgICAgICAgICAgICAgSG93IGxvbmcgdGhlIG1vdXNlIGhhcyB0byBob3ZlciBvdmVyIHRoZSBlbG1lbnQgYmVmb3JlIHRoZSBwb3BvdmVyIHNob3dzXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXAgKGluIG1pbGlpc2Vjb25kcykuXG4gICAgIyMjXG4gICAgY29uc3RydWN0b3I6IChAZWxlbWVudFRvQXR0YWNoVG8sIGRlbGF5ID0gNTAwKSAtPlxuICAgICAgICBzdXBlcigpXG5cbiAgICAjIyMqXG4gICAgICogRGVzdHJ1Y3Rvci5cbiAgICAgKlxuICAgICMjI1xuICAgIGRlc3RydWN0b3I6ICgpIC0+XG4gICAgICAgIGlmIEB0aW1lb3V0SWRcbiAgICAgICAgICAgIGNsZWFyVGltZW91dChAdGltZW91dElkKVxuICAgICAgICAgICAgQHRpbWVvdXRJZCA9IG51bGxcblxuICAgICAgICBzdXBlcigpXG5cbiAgICAjIyMqXG4gICAgICogU2hvd3MgdGhlIHBvcG92ZXIgd2l0aCB0aGUgc3BlY2lmaWVkIHRleHQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge2ludH0gZmFkZUluVGltZSBUaGUgYW1vdW50IG9mIHRpbWUgdG8gdGFrZSB0byBmYWRlIGluIHRoZSB0b29sdGlwLlxuICAgICMjI1xuICAgIHNob3c6IChmYWRlSW5UaW1lID0gMTAwKSAtPlxuICAgICAgICBjb29yZGluYXRlcyA9IEBlbGVtZW50VG9BdHRhY2hUby5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblxuICAgICAgICBjZW50ZXJPZmZzZXQgPSAoKGNvb3JkaW5hdGVzLnJpZ2h0IC0gY29vcmRpbmF0ZXMubGVmdCkgLyAyKVxuXG4gICAgICAgIHggPSBjb29yZGluYXRlcy5sZWZ0IC0gKEAkKEBnZXRFbGVtZW50KCkpLndpZHRoKCkgLyAyKSArIGNlbnRlck9mZnNldFxuICAgICAgICB5ID0gY29vcmRpbmF0ZXMuYm90dG9tXG5cbiAgICAgICAgc3VwZXIoeCwgeSwgZmFkZUluVGltZSlcblxuICAgICMjIypcbiAgICAgKiBTaG93cyB0aGUgcG9wb3ZlciB3aXRoIHRoZSBzcGVjaWZpZWQgdGV4dCBhZnRlciB0aGUgc3BlY2lmaWVkIGRlbGF5IChpbiBtaWxpaXNlY29uZHMpLiBDYWxsaW5nIHRoaXMgbWV0aG9kXG4gICAgICogbXVsdGlwbGUgdGltZXMgd2lsbCBjYW5jZWwgcHJldmlvdXMgc2hvdyByZXF1ZXN0cyBhbmQgcmVzdGFydC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7aW50fSAgICBkZWxheSAgICAgIFRoZSBkZWxheSBiZWZvcmUgdGhlIHRvb2x0aXAgc2hvd3MgdXAgKGluIG1pbGxpc2Vjb25kcykuXG4gICAgICogQHBhcmFtIHtpbnR9ICAgIGZhZGVJblRpbWUgVGhlIGFtb3VudCBvZiB0aW1lIHRvIHRha2UgdG8gZmFkZSBpbiB0aGUgdG9vbHRpcC5cbiAgICAjIyNcbiAgICBzaG93QWZ0ZXI6IChkZWxheSwgZmFkZUluVGltZSA9IDEwMCkgLT5cbiAgICAgICAgQHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT5cbiAgICAgICAgICAgIEBzaG93KGZhZGVJblRpbWUpXG4gICAgICAgICwgZGVsYXkpXG4iXX0=
