(function() {
  var CommandContext, grammarMap;

  grammarMap = require('./grammars');

  module.exports = CommandContext = (function() {
    function CommandContext() {}

    CommandContext.prototype.command = null;

    CommandContext.prototype.workingDirectory = null;

    CommandContext.prototype.args = [];

    CommandContext.prototype.options = {};

    CommandContext.build = function(runtime, runOptions, codeContext) {
      var buildArgsArray, commandContext, error, errorSendByArgs;
      commandContext = new CommandContext;
      commandContext.options = runOptions;
      try {
        if ((runOptions.cmd == null) || runOptions.cmd === '') {
          commandContext.command = codeContext.shebangCommand() || grammarMap[codeContext.lang][codeContext.argType].command;
        } else {
          commandContext.command = runOptions.cmd;
        }
        buildArgsArray = grammarMap[codeContext.lang][codeContext.argType].args;
      } catch (_error) {
        error = _error;
        runtime.modeNotSupported(codeContext.argType, codeContext.lang);
        return false;
      }
      try {
        commandContext.args = buildArgsArray(codeContext);
      } catch (_error) {
        errorSendByArgs = _error;
        runtime.didNotBuildArgs(errorSendByArgs);
        return false;
      }
      if ((runOptions.workingDirectory == null) || runOptions.workingDirectory === '') {
        commandContext.workingDirectory = grammarMap[codeContext.lang][codeContext.argType].workingDirectory || '';
      } else {
        commandContext.workingDirectory = runOptions.workingDirectory;
      }
      return commandContext;
    };

    CommandContext.prototype.quoteArguments = function(args) {
      var arg, _i, _len, _results;
      _results = [];
      for (_i = 0, _len = args.length; _i < _len; _i++) {
        arg = args[_i];
        _results.push(arg.trim().indexOf(' ') === -1 ? arg.trim() : "'" + arg + "'");
      }
      return _results;
    };

    CommandContext.prototype.getRepresentation = function() {
      var args, commandArgs, scriptArgs;
      if (!this.command || !this.args.length) {
        return '';
      }
      commandArgs = this.options.cmdArgs != null ? this.quoteArguments(this.options.cmdArgs).join(' ') : '';
      args = this.args.length ? this.quoteArguments(this.args).join(' ') : '';
      scriptArgs = this.options.scriptArgs != null ? this.quoteArguments(this.options.scriptArgs).join(' ') : '';
      return this.command.trim() + (commandArgs ? ' ' + commandArgs : '') + (args ? ' ' + args : '') + (scriptArgs ? ' ' + scriptArgs : '');
    };

    return CommandContext;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9jb21tYW5kLWNvbnRleHQuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLDBCQUFBOztBQUFBLEVBQUEsVUFBQSxHQUFhLE9BQUEsQ0FBUSxZQUFSLENBQWIsQ0FBQTs7QUFBQSxFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQ007Z0NBQ0o7O0FBQUEsNkJBQUEsT0FBQSxHQUFTLElBQVQsQ0FBQTs7QUFBQSw2QkFDQSxnQkFBQSxHQUFrQixJQURsQixDQUFBOztBQUFBLDZCQUVBLElBQUEsR0FBTSxFQUZOLENBQUE7O0FBQUEsNkJBR0EsT0FBQSxHQUFTLEVBSFQsQ0FBQTs7QUFBQSxJQUtBLGNBQUMsQ0FBQSxLQUFELEdBQVEsU0FBQyxPQUFELEVBQVUsVUFBVixFQUFzQixXQUF0QixHQUFBO0FBQ04sVUFBQSxzREFBQTtBQUFBLE1BQUEsY0FBQSxHQUFpQixHQUFBLENBQUEsY0FBakIsQ0FBQTtBQUFBLE1BQ0EsY0FBYyxDQUFDLE9BQWYsR0FBeUIsVUFEekIsQ0FBQTtBQUdBO0FBQ0UsUUFBQSxJQUFPLHdCQUFKLElBQXVCLFVBQVUsQ0FBQyxHQUFYLEtBQWtCLEVBQTVDO0FBRUUsVUFBQSxjQUFjLENBQUMsT0FBZixHQUF5QixXQUFXLENBQUMsY0FBWixDQUFBLENBQUEsSUFBZ0MsVUFBVyxDQUFBLFdBQVcsQ0FBQyxJQUFaLENBQWtCLENBQUEsV0FBVyxDQUFDLE9BQVosQ0FBb0IsQ0FBQyxPQUEzRyxDQUZGO1NBQUEsTUFBQTtBQUlFLFVBQUEsY0FBYyxDQUFDLE9BQWYsR0FBeUIsVUFBVSxDQUFDLEdBQXBDLENBSkY7U0FBQTtBQUFBLFFBTUEsY0FBQSxHQUFpQixVQUFXLENBQUEsV0FBVyxDQUFDLElBQVosQ0FBa0IsQ0FBQSxXQUFXLENBQUMsT0FBWixDQUFvQixDQUFDLElBTm5FLENBREY7T0FBQSxjQUFBO0FBVUUsUUFESSxjQUNKLENBQUE7QUFBQSxRQUFBLE9BQU8sQ0FBQyxnQkFBUixDQUF5QixXQUFXLENBQUMsT0FBckMsRUFBOEMsV0FBVyxDQUFDLElBQTFELENBQUEsQ0FBQTtBQUNBLGVBQU8sS0FBUCxDQVhGO09BSEE7QUFnQkE7QUFDRSxRQUFBLGNBQWMsQ0FBQyxJQUFmLEdBQXNCLGNBQUEsQ0FBZSxXQUFmLENBQXRCLENBREY7T0FBQSxjQUFBO0FBR0UsUUFESSx3QkFDSixDQUFBO0FBQUEsUUFBQSxPQUFPLENBQUMsZUFBUixDQUF3QixlQUF4QixDQUFBLENBQUE7QUFDQSxlQUFPLEtBQVAsQ0FKRjtPQWhCQTtBQXNCQSxNQUFBLElBQU8scUNBQUosSUFBb0MsVUFBVSxDQUFDLGdCQUFYLEtBQStCLEVBQXRFO0FBRUUsUUFBQSxjQUFjLENBQUMsZ0JBQWYsR0FBa0MsVUFBVyxDQUFBLFdBQVcsQ0FBQyxJQUFaLENBQWtCLENBQUEsV0FBVyxDQUFDLE9BQVosQ0FBb0IsQ0FBQyxnQkFBbEQsSUFBc0UsRUFBeEcsQ0FGRjtPQUFBLE1BQUE7QUFJRSxRQUFBLGNBQWMsQ0FBQyxnQkFBZixHQUFrQyxVQUFVLENBQUMsZ0JBQTdDLENBSkY7T0F0QkE7YUE2QkEsZUE5Qk07SUFBQSxDQUxSLENBQUE7O0FBQUEsNkJBcUNBLGNBQUEsR0FBZ0IsU0FBQyxJQUFELEdBQUE7QUFDZCxVQUFBLHVCQUFBO0FBQUM7V0FBQSwyQ0FBQTt1QkFBQTtBQUFBLHNCQUFJLEdBQUcsQ0FBQyxJQUFKLENBQUEsQ0FBVSxDQUFDLE9BQVgsQ0FBbUIsR0FBbkIsQ0FBQSxLQUEyQixDQUFBLENBQTlCLEdBQXNDLEdBQUcsQ0FBQyxJQUFKLENBQUEsQ0FBdEMsR0FBdUQsR0FBQSxHQUFHLEdBQUgsR0FBTyxJQUEvRCxDQUFBO0FBQUE7c0JBRGE7SUFBQSxDQXJDaEIsQ0FBQTs7QUFBQSw2QkF3Q0EsaUJBQUEsR0FBbUIsU0FBQSxHQUFBO0FBQ2pCLFVBQUEsNkJBQUE7QUFBQSxNQUFBLElBQWEsQ0FBQSxJQUFFLENBQUEsT0FBRixJQUFhLENBQUEsSUFBRSxDQUFBLElBQUksQ0FBQyxNQUFqQztBQUFBLGVBQU8sRUFBUCxDQUFBO09BQUE7QUFBQSxNQUdBLFdBQUEsR0FBaUIsNEJBQUgsR0FBMEIsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsSUFBQyxDQUFBLE9BQU8sQ0FBQyxPQUF6QixDQUFpQyxDQUFDLElBQWxDLENBQXVDLEdBQXZDLENBQTFCLEdBQTBFLEVBSHhGLENBQUE7QUFBQSxNQU1BLElBQUEsR0FBVSxJQUFDLENBQUEsSUFBSSxDQUFDLE1BQVQsR0FBcUIsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsSUFBQyxDQUFBLElBQWpCLENBQXNCLENBQUMsSUFBdkIsQ0FBNEIsR0FBNUIsQ0FBckIsR0FBMEQsRUFOakUsQ0FBQTtBQUFBLE1BT0EsVUFBQSxHQUFnQiwrQkFBSCxHQUE2QixJQUFDLENBQUEsY0FBRCxDQUFnQixJQUFDLENBQUEsT0FBTyxDQUFDLFVBQXpCLENBQW9DLENBQUMsSUFBckMsQ0FBMEMsR0FBMUMsQ0FBN0IsR0FBZ0YsRUFQN0YsQ0FBQTthQVNBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFBLENBQUEsR0FDRSxDQUFJLFdBQUgsR0FBb0IsR0FBQSxHQUFNLFdBQTFCLEdBQTJDLEVBQTVDLENBREYsR0FFRSxDQUFJLElBQUgsR0FBYSxHQUFBLEdBQU0sSUFBbkIsR0FBNkIsRUFBOUIsQ0FGRixHQUdFLENBQUksVUFBSCxHQUFtQixHQUFBLEdBQU0sVUFBekIsR0FBeUMsRUFBMUMsRUFiZTtJQUFBLENBeENuQixDQUFBOzswQkFBQTs7TUFKRixDQUFBO0FBQUEiCn0=

//# sourceURL=/Users/anthony/.atom/packages/script/lib/command-context.coffee
