(function() {
  var AutocompletionManager, ClassProvider, ConstantProvider, FunctionProvider, MemberProvider, VariableProvider;

  ClassProvider = require('./class-provider.coffee');

  MemberProvider = require('./member-provider.coffee');

  ConstantProvider = require('./constant-provider.coffee');

  VariableProvider = require('./variable-provider.coffee');

  FunctionProvider = require('./function-provider.coffee');

  module.exports = AutocompletionManager = (function() {
    function AutocompletionManager() {}

    AutocompletionManager.prototype.providers = [];


    /**
     * Initializes the autocompletion providers.
     */

    AutocompletionManager.prototype.init = function() {
      var i, len, provider, ref, results;
      this.providers.push(new ConstantProvider());
      this.providers.push(new VariableProvider());
      this.providers.push(new FunctionProvider());
      this.providers.push(new ClassProvider());
      this.providers.push(new MemberProvider());
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.init(this));
      }
      return results;
    };


    /**
     * Deactivates the autocompletion providers.
     */

    AutocompletionManager.prototype.deactivate = function() {
      var i, len, provider, ref, results;
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.deactivate());
      }
      return results;
    };


    /**
     * Deactivates the autocompletion providers.
     */

    AutocompletionManager.prototype.getProviders = function() {
      return this.providers;
    };

    return AutocompletionManager;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hdXRvY29tcGxldGlvbi9hdXRvY29tcGxldGlvbi1tYW5hZ2VyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsYUFBQSxHQUFnQixPQUFBLENBQVEseUJBQVI7O0VBQ2hCLGNBQUEsR0FBaUIsT0FBQSxDQUFRLDBCQUFSOztFQUNqQixnQkFBQSxHQUFtQixPQUFBLENBQVEsNEJBQVI7O0VBQ25CLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSw0QkFBUjs7RUFDbkIsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLDRCQUFSOztFQUVuQixNQUFNLENBQUMsT0FBUCxHQUVNOzs7b0NBQ0YsU0FBQSxHQUFXOzs7QUFFWDs7OztvQ0FHQSxJQUFBLEdBQU0sU0FBQTtBQUNGLFVBQUE7TUFBQSxJQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsQ0FBb0IsSUFBQSxnQkFBQSxDQUFBLENBQXBCO01BQ0EsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQW9CLElBQUEsZ0JBQUEsQ0FBQSxDQUFwQjtNQUNBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFvQixJQUFBLGdCQUFBLENBQUEsQ0FBcEI7TUFDQSxJQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsQ0FBb0IsSUFBQSxhQUFBLENBQUEsQ0FBcEI7TUFDQSxJQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsQ0FBb0IsSUFBQSxjQUFBLENBQUEsQ0FBcEI7QUFFQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxJQUFULENBQWMsSUFBZDtBQURKOztJQVBFOzs7QUFVTjs7OztvQ0FHQSxVQUFBLEdBQVksU0FBQTtBQUNSLFVBQUE7QUFBQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxVQUFULENBQUE7QUFESjs7SUFEUTs7O0FBSVo7Ozs7b0NBR0EsWUFBQSxHQUFjLFNBQUE7YUFDVixJQUFDLENBQUE7SUFEUzs7Ozs7QUFsQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiQ2xhc3NQcm92aWRlciA9IHJlcXVpcmUgJy4vY2xhc3MtcHJvdmlkZXIuY29mZmVlJ1xuTWVtYmVyUHJvdmlkZXIgPSByZXF1aXJlICcuL21lbWJlci1wcm92aWRlci5jb2ZmZWUnXG5Db25zdGFudFByb3ZpZGVyID0gcmVxdWlyZSAnLi9jb25zdGFudC1wcm92aWRlci5jb2ZmZWUnXG5WYXJpYWJsZVByb3ZpZGVyID0gcmVxdWlyZSAnLi92YXJpYWJsZS1wcm92aWRlci5jb2ZmZWUnXG5GdW5jdGlvblByb3ZpZGVyID0gcmVxdWlyZSAnLi9mdW5jdGlvbi1wcm92aWRlci5jb2ZmZWUnXG5cbm1vZHVsZS5leHBvcnRzID1cblxuY2xhc3MgQXV0b2NvbXBsZXRpb25NYW5hZ2VyXG4gICAgcHJvdmlkZXJzOiBbXVxuXG4gICAgIyMjKlxuICAgICAqIEluaXRpYWxpemVzIHRoZSBhdXRvY29tcGxldGlvbiBwcm92aWRlcnMuXG4gICAgIyMjXG4gICAgaW5pdDogKCkgLT5cbiAgICAgICAgQHByb3ZpZGVycy5wdXNoIG5ldyBDb25zdGFudFByb3ZpZGVyKClcbiAgICAgICAgQHByb3ZpZGVycy5wdXNoIG5ldyBWYXJpYWJsZVByb3ZpZGVyKClcbiAgICAgICAgQHByb3ZpZGVycy5wdXNoIG5ldyBGdW5jdGlvblByb3ZpZGVyKClcbiAgICAgICAgQHByb3ZpZGVycy5wdXNoIG5ldyBDbGFzc1Byb3ZpZGVyKClcbiAgICAgICAgQHByb3ZpZGVycy5wdXNoIG5ldyBNZW1iZXJQcm92aWRlcigpXG5cbiAgICAgICAgZm9yIHByb3ZpZGVyIGluIEBwcm92aWRlcnNcbiAgICAgICAgICAgIHByb3ZpZGVyLmluaXQoQClcblxuICAgICMjIypcbiAgICAgKiBEZWFjdGl2YXRlcyB0aGUgYXV0b2NvbXBsZXRpb24gcHJvdmlkZXJzLlxuICAgICMjI1xuICAgIGRlYWN0aXZhdGU6ICgpIC0+XG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5kZWFjdGl2YXRlKClcblxuICAgICMjIypcbiAgICAgKiBEZWFjdGl2YXRlcyB0aGUgYXV0b2NvbXBsZXRpb24gcHJvdmlkZXJzLlxuICAgICMjI1xuICAgIGdldFByb3ZpZGVyczogKCkgLT5cbiAgICAgICAgQHByb3ZpZGVyc1xuIl19
