(function() {
  var ClassProvider, FunctionProvider, GotoManager, PropertyProvider, TextEditor, parser;

  TextEditor = require('atom').TextEditor;

  ClassProvider = require('./class-provider.coffee');

  FunctionProvider = require('./function-provider.coffee');

  PropertyProvider = require('./property-provider.coffee');

  parser = require('../services/php-file-parser.coffee');

  module.exports = GotoManager = (function() {
    function GotoManager() {}

    GotoManager.prototype.providers = [];

    GotoManager.prototype.trace = [];


    /**
     * Initialisation of all the providers and commands for goto
     */

    GotoManager.prototype.init = function() {
      var i, len, provider, ref;
      this.providers.push(new ClassProvider());
      this.providers.push(new FunctionProvider());
      this.providers.push(new PropertyProvider());
      ref = this.providers;
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        provider.init(this);
      }
      atom.commands.add('atom-workspace', {
        'atom-autocomplete-php:goto-backtrack': (function(_this) {
          return function() {
            return _this.backTrack(atom.workspace.getActivePaneItem());
          };
        })(this)
      });
      return atom.commands.add('atom-workspace', {
        'atom-autocomplete-php:goto': (function(_this) {
          return function() {
            return _this.goto(atom.workspace.getActivePaneItem());
          };
        })(this)
      });
    };


    /**
     * Deactivates the goto functionaility
     */

    GotoManager.prototype.deactivate = function() {
      var i, len, provider, ref, results;
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.deactivate());
      }
      return results;
    };


    /**
     * Adds a backtrack step to the stack.
     *
     * @param {string}         fileName       The file where the jump took place.
     * @param {BufferPosition} bufferPosition The buffer position the cursor was last on.
     */

    GotoManager.prototype.addBackTrack = function(fileName, bufferPosition) {
      return this.trace.push({
        file: fileName,
        position: bufferPosition
      });
    };


    /**
     * Pops one of the stored back tracks and jump the user to its position.
     *
     * @param {TextEditor} editor The current editor.
     */

    GotoManager.prototype.backTrack = function(editor) {
      var lastTrace;
      if (this.trace.length === 0) {
        return;
      }
      lastTrace = this.trace.pop();
      if (editor instanceof TextEditor && editor.getPath() === lastTrace.file) {
        editor.setCursorBufferPosition(lastTrace.position, {
          autoscroll: false
        });
        return editor.scrollToScreenPosition(editor.screenPositionForBufferPosition(lastTrace.position), {
          center: true
        });
      } else {
        return atom.workspace.open(lastTrace.file, {
          searchAllPanes: true,
          initialLine: lastTrace.position[0],
          initialColumn: lastTrace.position[1]
        });
      }
    };


    /**
     * Takes the editor and jumps using one of the providers.
     *
     * @param {TextEditor} editor Current active editor
     */

    GotoManager.prototype.goto = function(editor) {
      var fullTerm, i, len, provider, ref, results;
      fullTerm = parser.getFullWordFromBufferPosition(editor, editor.getCursorBufferPosition());
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        if (provider.canGoto(fullTerm)) {
          provider.gotoFromEditor(editor);
          break;
        } else {
          results.push(void 0);
        }
      }
      return results;
    };

    return GotoManager;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9nb3RvL2dvdG8tbWFuYWdlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFDLGFBQWMsT0FBQSxDQUFRLE1BQVI7O0VBRWYsYUFBQSxHQUFnQixPQUFBLENBQVEseUJBQVI7O0VBQ2hCLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSw0QkFBUjs7RUFDbkIsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLDRCQUFSOztFQUVuQixNQUFBLEdBQVMsT0FBQSxDQUFRLG9DQUFSOztFQUVULE1BQU0sQ0FBQyxPQUFQLEdBRU07OzswQkFDRixTQUFBLEdBQVc7OzBCQUNYLEtBQUEsR0FBTzs7O0FBRVA7Ozs7MEJBR0EsSUFBQSxHQUFNLFNBQUE7QUFDRixVQUFBO01BQUEsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQW9CLElBQUEsYUFBQSxDQUFBLENBQXBCO01BQ0EsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQW9CLElBQUEsZ0JBQUEsQ0FBQSxDQUFwQjtNQUNBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFvQixJQUFBLGdCQUFBLENBQUEsQ0FBcEI7QUFFQTtBQUFBLFdBQUEscUNBQUE7O1FBQ0ksUUFBUSxDQUFDLElBQVQsQ0FBYyxJQUFkO0FBREo7TUFHQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DO1FBQUEsc0NBQUEsRUFBd0MsQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFDeEUsS0FBQyxDQUFBLFNBQUQsQ0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFmLENBQUEsQ0FBWDtVQUR3RTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBeEM7T0FBcEM7YUFHQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DO1FBQUEsNEJBQUEsRUFBOEIsQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFDOUQsS0FBQyxDQUFBLElBQUQsQ0FBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFmLENBQUEsQ0FBTjtVQUQ4RDtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUI7T0FBcEM7SUFYRTs7O0FBY047Ozs7MEJBR0EsVUFBQSxHQUFZLFNBQUE7QUFDUixVQUFBO0FBQUE7QUFBQTtXQUFBLHFDQUFBOztxQkFDSSxRQUFRLENBQUMsVUFBVCxDQUFBO0FBREo7O0lBRFE7OztBQUlaOzs7Ozs7OzBCQU1BLFlBQUEsR0FBYyxTQUFDLFFBQUQsRUFBVyxjQUFYO2FBQ1YsSUFBQyxDQUFBLEtBQUssQ0FBQyxJQUFQLENBQVk7UUFDUixJQUFBLEVBQU0sUUFERTtRQUVSLFFBQUEsRUFBVSxjQUZGO09BQVo7SUFEVTs7O0FBTWQ7Ozs7OzswQkFLQSxTQUFBLEdBQVcsU0FBQyxNQUFEO0FBQ1AsVUFBQTtNQUFBLElBQUcsSUFBQyxDQUFBLEtBQUssQ0FBQyxNQUFQLEtBQWlCLENBQXBCO0FBQ0ksZUFESjs7TUFHQSxTQUFBLEdBQVksSUFBQyxDQUFBLEtBQUssQ0FBQyxHQUFQLENBQUE7TUFFWixJQUFHLE1BQUEsWUFBa0IsVUFBbEIsSUFBZ0MsTUFBTSxDQUFDLE9BQVAsQ0FBQSxDQUFBLEtBQW9CLFNBQVMsQ0FBQyxJQUFqRTtRQUNJLE1BQU0sQ0FBQyx1QkFBUCxDQUErQixTQUFTLENBQUMsUUFBekMsRUFBbUQ7VUFDL0MsVUFBQSxFQUFZLEtBRG1DO1NBQW5EO2VBTUEsTUFBTSxDQUFDLHNCQUFQLENBQThCLE1BQU0sQ0FBQywrQkFBUCxDQUF1QyxTQUFTLENBQUMsUUFBakQsQ0FBOUIsRUFBMEY7VUFDdEYsTUFBQSxFQUFRLElBRDhFO1NBQTFGLEVBUEo7T0FBQSxNQUFBO2VBWUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFmLENBQW9CLFNBQVMsQ0FBQyxJQUE5QixFQUFvQztVQUNoQyxjQUFBLEVBQWdCLElBRGdCO1VBRWhDLFdBQUEsRUFBYSxTQUFTLENBQUMsUUFBUyxDQUFBLENBQUEsQ0FGQTtVQUdoQyxhQUFBLEVBQWUsU0FBUyxDQUFDLFFBQVMsQ0FBQSxDQUFBLENBSEY7U0FBcEMsRUFaSjs7SUFOTzs7O0FBd0JYOzs7Ozs7MEJBS0EsSUFBQSxHQUFNLFNBQUMsTUFBRDtBQUNGLFVBQUE7TUFBQSxRQUFBLEdBQVcsTUFBTSxDQUFDLDZCQUFQLENBQXFDLE1BQXJDLEVBQTZDLE1BQU0sQ0FBQyx1QkFBUCxDQUFBLENBQTdDO0FBRVg7QUFBQTtXQUFBLHFDQUFBOztRQUNJLElBQUcsUUFBUSxDQUFDLE9BQVQsQ0FBaUIsUUFBakIsQ0FBSDtVQUNJLFFBQVEsQ0FBQyxjQUFULENBQXdCLE1BQXhCO0FBQ0EsZ0JBRko7U0FBQSxNQUFBOytCQUFBOztBQURKOztJQUhFOzs7OztBQXBGViIsInNvdXJjZXNDb250ZW50IjpbIntUZXh0RWRpdG9yfSA9IHJlcXVpcmUgJ2F0b20nXG5cbkNsYXNzUHJvdmlkZXIgPSByZXF1aXJlICcuL2NsYXNzLXByb3ZpZGVyLmNvZmZlZSdcbkZ1bmN0aW9uUHJvdmlkZXIgPSByZXF1aXJlICcuL2Z1bmN0aW9uLXByb3ZpZGVyLmNvZmZlZSdcblByb3BlcnR5UHJvdmlkZXIgPSByZXF1aXJlICcuL3Byb3BlcnR5LXByb3ZpZGVyLmNvZmZlZSdcblxucGFyc2VyID0gcmVxdWlyZSAnLi4vc2VydmljZXMvcGhwLWZpbGUtcGFyc2VyLmNvZmZlZSdcblxubW9kdWxlLmV4cG9ydHMgPVxuXG5jbGFzcyBHb3RvTWFuYWdlclxuICAgIHByb3ZpZGVyczogW11cbiAgICB0cmFjZTogW11cblxuICAgICMjIypcbiAgICAgKiBJbml0aWFsaXNhdGlvbiBvZiBhbGwgdGhlIHByb3ZpZGVycyBhbmQgY29tbWFuZHMgZm9yIGdvdG9cbiAgICAjIyNcbiAgICBpbml0OiAoKSAtPlxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IENsYXNzUHJvdmlkZXIoKVxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IEZ1bmN0aW9uUHJvdmlkZXIoKVxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IFByb3BlcnR5UHJvdmlkZXIoKVxuXG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5pbml0KEApXG5cbiAgICAgICAgYXRvbS5jb21tYW5kcy5hZGQgJ2F0b20td29ya3NwYWNlJywgJ2F0b20tYXV0b2NvbXBsZXRlLXBocDpnb3RvLWJhY2t0cmFjayc6ID0+XG4gICAgICAgICAgICBAYmFja1RyYWNrKGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmVJdGVtKCkpXG5cbiAgICAgICAgYXRvbS5jb21tYW5kcy5hZGQgJ2F0b20td29ya3NwYWNlJywgJ2F0b20tYXV0b2NvbXBsZXRlLXBocDpnb3RvJzogPT5cbiAgICAgICAgICAgIEBnb3RvKGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmVJdGVtKCkpXG5cbiAgICAjIyMqXG4gICAgICogRGVhY3RpdmF0ZXMgdGhlIGdvdG8gZnVuY3Rpb25haWxpdHlcbiAgICAjIyNcbiAgICBkZWFjdGl2YXRlOiAoKSAtPlxuICAgICAgICBmb3IgcHJvdmlkZXIgaW4gQHByb3ZpZGVyc1xuICAgICAgICAgICAgcHJvdmlkZXIuZGVhY3RpdmF0ZSgpXG5cbiAgICAjIyMqXG4gICAgICogQWRkcyBhIGJhY2t0cmFjayBzdGVwIHRvIHRoZSBzdGFjay5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSAgICAgICAgIGZpbGVOYW1lICAgICAgIFRoZSBmaWxlIHdoZXJlIHRoZSBqdW1wIHRvb2sgcGxhY2UuXG4gICAgICogQHBhcmFtIHtCdWZmZXJQb3NpdGlvbn0gYnVmZmVyUG9zaXRpb24gVGhlIGJ1ZmZlciBwb3NpdGlvbiB0aGUgY3Vyc29yIHdhcyBsYXN0IG9uLlxuICAgICMjI1xuICAgIGFkZEJhY2tUcmFjazogKGZpbGVOYW1lLCBidWZmZXJQb3NpdGlvbikgLT5cbiAgICAgICAgQHRyYWNlLnB1c2goe1xuICAgICAgICAgICAgZmlsZTogZmlsZU5hbWUsXG4gICAgICAgICAgICBwb3NpdGlvbjogYnVmZmVyUG9zaXRpb25cbiAgICAgICAgfSlcblxuICAgICMjIypcbiAgICAgKiBQb3BzIG9uZSBvZiB0aGUgc3RvcmVkIGJhY2sgdHJhY2tzIGFuZCBqdW1wIHRoZSB1c2VyIHRvIGl0cyBwb3NpdGlvbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yIFRoZSBjdXJyZW50IGVkaXRvci5cbiAgICAjIyNcbiAgICBiYWNrVHJhY2s6IChlZGl0b3IpIC0+XG4gICAgICAgIGlmIEB0cmFjZS5sZW5ndGggPT0gMFxuICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgbGFzdFRyYWNlID0gQHRyYWNlLnBvcCgpXG5cbiAgICAgICAgaWYgZWRpdG9yIGluc3RhbmNlb2YgVGV4dEVkaXRvciAmJiBlZGl0b3IuZ2V0UGF0aCgpID09IGxhc3RUcmFjZS5maWxlXG4gICAgICAgICAgICBlZGl0b3Iuc2V0Q3Vyc29yQnVmZmVyUG9zaXRpb24obGFzdFRyYWNlLnBvc2l0aW9uLCB7XG4gICAgICAgICAgICAgICAgYXV0b3Njcm9sbDogZmFsc2VcbiAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgICMgU2VwYXJhdGVkIHRoZXNlIGFzIHRoZSBhdXRvc2Nyb2xsIG9uIHNldEN1cnNvckJ1ZmZlclBvc2l0aW9uXG4gICAgICAgICAgICAjIGRpZG4ndCB3b3JrIGFzIHdlbGwuXG4gICAgICAgICAgICBlZGl0b3Iuc2Nyb2xsVG9TY3JlZW5Qb3NpdGlvbihlZGl0b3Iuc2NyZWVuUG9zaXRpb25Gb3JCdWZmZXJQb3NpdGlvbihsYXN0VHJhY2UucG9zaXRpb24pLCB7XG4gICAgICAgICAgICAgICAgY2VudGVyOiB0cnVlXG4gICAgICAgICAgICB9KVxuXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGF0b20ud29ya3NwYWNlLm9wZW4obGFzdFRyYWNlLmZpbGUsIHtcbiAgICAgICAgICAgICAgICBzZWFyY2hBbGxQYW5lczogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpbml0aWFsTGluZTogbGFzdFRyYWNlLnBvc2l0aW9uWzBdXG4gICAgICAgICAgICAgICAgaW5pdGlhbENvbHVtbjogbGFzdFRyYWNlLnBvc2l0aW9uWzFdXG4gICAgICAgICAgICB9KVxuXG4gICAgIyMjKlxuICAgICAqIFRha2VzIHRoZSBlZGl0b3IgYW5kIGp1bXBzIHVzaW5nIG9uZSBvZiB0aGUgcHJvdmlkZXJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSBlZGl0b3IgQ3VycmVudCBhY3RpdmUgZWRpdG9yXG4gICAgIyMjXG4gICAgZ290bzogKGVkaXRvcikgLT5cbiAgICAgICAgZnVsbFRlcm0gPSBwYXJzZXIuZ2V0RnVsbFdvcmRGcm9tQnVmZmVyUG9zaXRpb24oZWRpdG9yLCBlZGl0b3IuZ2V0Q3Vyc29yQnVmZmVyUG9zaXRpb24oKSlcblxuICAgICAgICBmb3IgcHJvdmlkZXIgaW4gQHByb3ZpZGVyc1xuICAgICAgICAgICAgaWYgcHJvdmlkZXIuY2FuR290byhmdWxsVGVybSlcbiAgICAgICAgICAgICAgICBwcm92aWRlci5nb3RvRnJvbUVkaXRvcihlZGl0b3IpXG4gICAgICAgICAgICAgICAgYnJlYWtcbiJdfQ==
