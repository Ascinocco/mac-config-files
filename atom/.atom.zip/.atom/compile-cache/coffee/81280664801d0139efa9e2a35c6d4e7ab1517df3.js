(function() {
  module.exports = {
    createTempFileWithCode: function(code) {
      if (!/^[\s]*<\?php/.test(code)) {
        code = "<?php " + code;
      }
      return module.parent.exports.createTempFileWithCode(code);
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ncmFtbWFyLXV0aWxzL3BocC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFFQTtBQUFBLEVBQUEsTUFBTSxDQUFDLE9BQVAsR0FNRTtBQUFBLElBQUEsc0JBQUEsRUFBd0IsU0FBQyxJQUFELEdBQUE7QUFDdEIsTUFBQSxJQUFBLENBQUEsY0FBNEMsQ0FBQyxJQUFmLENBQW9CLElBQXBCLENBQTlCO0FBQUEsUUFBQSxJQUFBLEdBQVEsUUFBQSxHQUFRLElBQWhCLENBQUE7T0FBQTthQUNBLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHNCQUF0QixDQUE2QyxJQUE3QyxFQUZzQjtJQUFBLENBQXhCO0dBTkYsQ0FBQTtBQUFBIgp9

//# sourceURL=/Users/anthony/.atom/packages/script/lib/grammar-utils/php.coffee
