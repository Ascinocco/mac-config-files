(function() {
  var os;

  os = require('os');

  module.exports = {
    isDarwin: function() {
      return this.platform() === 'darwin';
    },
    isWindows: function() {
      return this.platform() === 'win32';
    },
    isLinux: function() {
      return this.platform() === 'linux';
    },
    platform: function() {
      return os.platform();
    },
    release: function() {
      return os.release();
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ncmFtbWFyLXV0aWxzL29wZXJhdGluZy1zeXN0ZW0uY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLEVBQUE7O0FBQUEsRUFBQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVIsQ0FBTCxDQUFBOztBQUFBLEVBSUEsTUFBTSxDQUFDLE9BQVAsR0FDRTtBQUFBLElBQUEsUUFBQSxFQUFVLFNBQUEsR0FBQTthQUNSLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FBQSxLQUFlLFNBRFA7SUFBQSxDQUFWO0FBQUEsSUFHQSxTQUFBLEVBQVcsU0FBQSxHQUFBO2FBQ1QsSUFBQyxDQUFBLFFBQUQsQ0FBQSxDQUFBLEtBQWUsUUFETjtJQUFBLENBSFg7QUFBQSxJQU1BLE9BQUEsRUFBUyxTQUFBLEdBQUE7YUFDUCxJQUFDLENBQUEsUUFBRCxDQUFBLENBQUEsS0FBZSxRQURSO0lBQUEsQ0FOVDtBQUFBLElBU0EsUUFBQSxFQUFVLFNBQUEsR0FBQTthQUNSLEVBQUUsQ0FBQyxRQUFILENBQUEsRUFEUTtJQUFBLENBVFY7QUFBQSxJQVlBLE9BQUEsRUFBUyxTQUFBLEdBQUE7YUFDUCxFQUFFLENBQUMsT0FBSCxDQUFBLEVBRE87SUFBQSxDQVpUO0dBTEYsQ0FBQTtBQUFBIgp9

//# sourceURL=/Users/anthony/.atom/packages/script/lib/grammar-utils/operating-system.coffee
