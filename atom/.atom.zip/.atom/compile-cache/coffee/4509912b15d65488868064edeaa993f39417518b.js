(function() {
  var $$, CompositeDisposable, Emitter, ScriptInputView, View, _ref, _ref1,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ref = require('atom'), Emitter = _ref.Emitter, CompositeDisposable = _ref.CompositeDisposable;

  _ref1 = require('atom-space-pen-views'), $$ = _ref1.$$, View = _ref1.View;

  module.exports = ScriptInputView = (function(_super) {
    __extends(ScriptInputView, _super);

    function ScriptInputView() {
      return ScriptInputView.__super__.constructor.apply(this, arguments);
    }

    ScriptInputView.content = function() {
      return this.div({
        "class": 'script-input-view'
      }, (function(_this) {
        return function() {
          _this.div({
            "class": 'caption'
          }, '');
          return _this.tag('atom-text-editor', {
            mini: '',
            "class": 'editor mini'
          });
        };
      })(this));
    };

    ScriptInputView.prototype.initialize = function(options) {
      this.options = options;
      this.emitter = new Emitter;
      this.panel = atom.workspace.addModalPanel({
        item: this
      });
      this.panel.hide();
      this.editor = this.find('atom-text-editor').get(0).getModel();
      if (this.options["default"]) {
        this.editor.setText(this.options["default"]);
        this.editor.selectAll();
      }
      if (this.options.caption) {
        this.find('.caption').text(this.options.caption);
      }
      this.find('atom-text-editor').on('keydown', (function(_this) {
        return function(e) {
          if (e.keyCode === 27) {
            e.stopPropagation();
            _this.emitter.emit('on-cancel');
            return _this.hide();
          }
        };
      })(this));
      this.subscriptions = new CompositeDisposable;
      return this.subscriptions.add(atom.commands.add('atom-workspace', {
        'core:confirm': (function(_this) {
          return function() {
            _this.emitter.emit('on-confirm', _this.editor.getText().trim());
            return _this.hide();
          };
        })(this)
      }));
    };

    ScriptInputView.prototype.onConfirm = function(callback) {
      return this.emitter.on('on-confirm', callback);
    };

    ScriptInputView.prototype.onCancel = function(callback) {
      return this.emitter.on('on-cancel', callback);
    };

    ScriptInputView.prototype.focus = function() {
      return this.find('atom-text-editor').focus();
    };

    ScriptInputView.prototype.show = function() {
      this.panel.show();
      return this.focus();
    };

    ScriptInputView.prototype.hide = function() {
      this.panel.hide();
      return this.destroy();
    };

    ScriptInputView.prototype.destroy = function() {
      var _ref2;
      if ((_ref2 = this.subscriptions) != null) {
        _ref2.dispose();
      }
      return this.panel.destroy();
    };

    return ScriptInputView;

  })(View);

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9zY3JpcHQtaW5wdXQtdmlldy5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsb0VBQUE7SUFBQTttU0FBQTs7QUFBQSxFQUFBLE9BQWlDLE9BQUEsQ0FBUSxNQUFSLENBQWpDLEVBQUMsZUFBQSxPQUFELEVBQVUsMkJBQUEsbUJBQVYsQ0FBQTs7QUFBQSxFQUNBLFFBQWEsT0FBQSxDQUFRLHNCQUFSLENBQWIsRUFBQyxXQUFBLEVBQUQsRUFBSyxhQUFBLElBREwsQ0FBQTs7QUFBQSxFQUdBLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFDSixzQ0FBQSxDQUFBOzs7O0tBQUE7O0FBQUEsSUFBQSxlQUFDLENBQUEsT0FBRCxHQUFVLFNBQUEsR0FBQTthQUNSLElBQUMsQ0FBQSxHQUFELENBQUs7QUFBQSxRQUFBLE9BQUEsRUFBTyxtQkFBUDtPQUFMLEVBQWlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFDL0IsVUFBQSxLQUFDLENBQUEsR0FBRCxDQUFLO0FBQUEsWUFBQSxPQUFBLEVBQU8sU0FBUDtXQUFMLEVBQXVCLEVBQXZCLENBQUEsQ0FBQTtpQkFDQSxLQUFDLENBQUEsR0FBRCxDQUFLLGtCQUFMLEVBQXlCO0FBQUEsWUFBQSxJQUFBLEVBQU0sRUFBTjtBQUFBLFlBQVUsT0FBQSxFQUFPLGFBQWpCO1dBQXpCLEVBRitCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBakMsRUFEUTtJQUFBLENBQVYsQ0FBQTs7QUFBQSw4QkFLQSxVQUFBLEdBQVksU0FBRSxPQUFGLEdBQUE7QUFDVixNQURXLElBQUMsQ0FBQSxVQUFBLE9BQ1osQ0FBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLE9BQUQsR0FBVyxHQUFBLENBQUEsT0FBWCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBZixDQUE2QjtBQUFBLFFBQUEsSUFBQSxFQUFNLElBQU47T0FBN0IsQ0FGVCxDQUFBO0FBQUEsTUFHQSxJQUFDLENBQUEsS0FBSyxDQUFDLElBQVAsQ0FBQSxDQUhBLENBQUE7QUFBQSxNQUtBLElBQUMsQ0FBQSxNQUFELEdBQVUsSUFBQyxDQUFBLElBQUQsQ0FBTSxrQkFBTixDQUF5QixDQUFDLEdBQTFCLENBQThCLENBQTlCLENBQWdDLENBQUMsUUFBakMsQ0FBQSxDQUxWLENBQUE7QUFRQSxNQUFBLElBQUcsSUFBQyxDQUFBLE9BQU8sQ0FBQyxTQUFELENBQVg7QUFDRSxRQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsT0FBUixDQUFnQixJQUFDLENBQUEsT0FBTyxDQUFDLFNBQUQsQ0FBeEIsQ0FBQSxDQUFBO0FBQUEsUUFDQSxJQUFDLENBQUEsTUFBTSxDQUFDLFNBQVIsQ0FBQSxDQURBLENBREY7T0FSQTtBQWFBLE1BQUEsSUFBRyxJQUFDLENBQUEsT0FBTyxDQUFDLE9BQVo7QUFDRSxRQUFBLElBQUMsQ0FBQSxJQUFELENBQU0sVUFBTixDQUFpQixDQUFDLElBQWxCLENBQXVCLElBQUMsQ0FBQSxPQUFPLENBQUMsT0FBaEMsQ0FBQSxDQURGO09BYkE7QUFBQSxNQWdCQSxJQUFDLENBQUEsSUFBRCxDQUFNLGtCQUFOLENBQXlCLENBQUMsRUFBMUIsQ0FBNkIsU0FBN0IsRUFBd0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsQ0FBRCxHQUFBO0FBQ3RDLFVBQUEsSUFBRyxDQUFDLENBQUMsT0FBRixLQUFhLEVBQWhCO0FBQ0UsWUFBQSxDQUFDLENBQUMsZUFBRixDQUFBLENBQUEsQ0FBQTtBQUFBLFlBQ0EsS0FBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsV0FBZCxDQURBLENBQUE7bUJBRUEsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUhGO1dBRHNDO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBeEMsQ0FoQkEsQ0FBQTtBQUFBLE1Bc0JBLElBQUMsQ0FBQSxhQUFELEdBQWlCLEdBQUEsQ0FBQSxtQkF0QmpCLENBQUE7YUF1QkEsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQW1CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFDakI7QUFBQSxRQUFBLGNBQUEsRUFBZ0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7QUFDZCxZQUFBLEtBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLFlBQWQsRUFBNEIsS0FBQyxDQUFBLE1BQU0sQ0FBQyxPQUFSLENBQUEsQ0FBaUIsQ0FBQyxJQUFsQixDQUFBLENBQTVCLENBQUEsQ0FBQTttQkFDQSxLQUFDLENBQUEsSUFBRCxDQUFBLEVBRmM7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQjtPQURpQixDQUFuQixFQXhCVTtJQUFBLENBTFosQ0FBQTs7QUFBQSw4QkFrQ0EsU0FBQSxHQUFXLFNBQUMsUUFBRCxHQUFBO2FBQWMsSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksWUFBWixFQUEwQixRQUExQixFQUFkO0lBQUEsQ0FsQ1gsQ0FBQTs7QUFBQSw4QkFtQ0EsUUFBQSxHQUFVLFNBQUMsUUFBRCxHQUFBO2FBQWMsSUFBQyxDQUFBLE9BQU8sQ0FBQyxFQUFULENBQVksV0FBWixFQUF5QixRQUF6QixFQUFkO0lBQUEsQ0FuQ1YsQ0FBQTs7QUFBQSw4QkFxQ0EsS0FBQSxHQUFPLFNBQUEsR0FBQTthQUNMLElBQUMsQ0FBQSxJQUFELENBQU0sa0JBQU4sQ0FBeUIsQ0FBQyxLQUExQixDQUFBLEVBREs7SUFBQSxDQXJDUCxDQUFBOztBQUFBLDhCQXdDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO0FBQ0osTUFBQSxJQUFDLENBQUEsS0FBSyxDQUFDLElBQVAsQ0FBQSxDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsS0FBRCxDQUFBLEVBRkk7SUFBQSxDQXhDTixDQUFBOztBQUFBLDhCQTRDQSxJQUFBLEdBQU0sU0FBQSxHQUFBO0FBQ0osTUFBQSxJQUFDLENBQUEsS0FBSyxDQUFDLElBQVAsQ0FBQSxDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsT0FBRCxDQUFBLEVBRkk7SUFBQSxDQTVDTixDQUFBOztBQUFBLDhCQWdEQSxPQUFBLEdBQVMsU0FBQSxHQUFBO0FBQ1AsVUFBQSxLQUFBOzthQUFjLENBQUUsT0FBaEIsQ0FBQTtPQUFBO2FBQ0EsSUFBQyxDQUFBLEtBQUssQ0FBQyxPQUFQLENBQUEsRUFGTztJQUFBLENBaERULENBQUE7OzJCQUFBOztLQUQ0QixLQUo5QixDQUFBO0FBQUEiCn0=

//# sourceURL=/Users/anthony/.atom/packages/script/lib/script-input-view.coffee
