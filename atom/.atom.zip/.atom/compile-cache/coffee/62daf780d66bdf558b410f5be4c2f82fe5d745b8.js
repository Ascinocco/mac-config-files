(function() {
  var AbstractProvider, PropertyProvider, TextEditor,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  TextEditor = require('atom').TextEditor;

  AbstractProvider = require('./abstract-provider');

  module.exports = PropertyProvider = (function(superClass) {
    extend(PropertyProvider, superClass);

    function PropertyProvider() {
      return PropertyProvider.__super__.constructor.apply(this, arguments);
    }

    PropertyProvider.prototype.hoverEventSelectors = '.property';


    /**
     * Retrieves a tooltip for the word given.
     * @param  {TextEditor} editor         TextEditor to search for namespace of term.
     * @param  {string}     term           Term to search for.
     * @param  {Point}      bufferPosition The cursor location the term is at.
     */

    PropertyProvider.prototype.getTooltipForWord = function(editor, term, bufferPosition) {
      var accessModifier, description, ref, ref1, ref2, returnType, returnValue, value;
      value = this.parser.getMemberContext(editor, term, bufferPosition);
      if (!value) {
        return;
      }
      accessModifier = '';
      returnType = ((ref = value.args["return"]) != null ? ref.type : void 0) ? value.args["return"].type : 'mixed';
      if (value.isPublic) {
        accessModifier = 'public';
      } else if (value.isProtected) {
        accessModifier = 'protected';
      } else {
        accessModifier = 'private';
      }
      description = '';
      description += "<p><div>";
      description += accessModifier + ' ' + returnType + '<strong>' + ' $' + term + '</strong>';
      description += '</div></p>';
      description += '<div>';
      description += (value.args.descriptions.short ? value.args.descriptions.short : '(No documentation available)');
      description += '</div>';
      if (((ref1 = value.args.descriptions.long) != null ? ref1.length : void 0) > 0) {
        description += '<div class="section">';
        description += "<h4>Description</h4>";
        description += "<div>" + value.args.descriptions.long + "</div>";
        description += "</div>";
      }
      if ((ref2 = value.args["return"]) != null ? ref2.type : void 0) {
        returnValue = '<strong>' + value.args["return"].type + '</strong>';
        if (value.args["return"].description) {
          returnValue += ' ' + value.args["return"].description;
        }
        description += '<div class="section">';
        description += "<h4>Type</h4>";
        description += "<div>" + returnValue + "</div>";
        description += "</div>";
      }
      return description;
    };

    return PropertyProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi90b29sdGlwL3Byb3BlcnR5LXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsOENBQUE7SUFBQTs7O0VBQUMsYUFBYyxPQUFBLENBQVEsTUFBUjs7RUFFZixnQkFBQSxHQUFtQixPQUFBLENBQVEscUJBQVI7O0VBRW5CLE1BQU0sQ0FBQyxPQUFQLEdBRU07Ozs7Ozs7K0JBQ0YsbUJBQUEsR0FBcUI7OztBQUVyQjs7Ozs7OzsrQkFNQSxpQkFBQSxHQUFtQixTQUFDLE1BQUQsRUFBUyxJQUFULEVBQWUsY0FBZjtBQUNmLFVBQUE7TUFBQSxLQUFBLEdBQVEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixNQUF6QixFQUFpQyxJQUFqQyxFQUF1QyxjQUF2QztNQUVSLElBQUcsQ0FBSSxLQUFQO0FBQ0ksZUFESjs7TUFHQSxjQUFBLEdBQWlCO01BQ2pCLFVBQUEsOENBQWlDLENBQUUsY0FBdEIsR0FBZ0MsS0FBSyxDQUFDLElBQUksRUFBQyxNQUFELEVBQU8sQ0FBQyxJQUFsRCxHQUE0RDtNQUV6RSxJQUFHLEtBQUssQ0FBQyxRQUFUO1FBQ0ksY0FBQSxHQUFpQixTQURyQjtPQUFBLE1BR0ssSUFBRyxLQUFLLENBQUMsV0FBVDtRQUNELGNBQUEsR0FBaUIsWUFEaEI7T0FBQSxNQUFBO1FBSUQsY0FBQSxHQUFpQixVQUpoQjs7TUFPTCxXQUFBLEdBQWM7TUFFZCxXQUFBLElBQWU7TUFDZixXQUFBLElBQWUsY0FBQSxHQUFpQixHQUFqQixHQUF1QixVQUF2QixHQUFvQyxVQUFwQyxHQUFpRCxJQUFqRCxHQUF3RCxJQUF4RCxHQUErRDtNQUM5RSxXQUFBLElBQWU7TUFHZixXQUFBLElBQWU7TUFDZixXQUFBLElBQW1CLENBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBM0IsR0FBc0MsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBOUQsR0FBeUUsOEJBQTFFO01BQ25CLFdBQUEsSUFBZTtNQUdmLHlEQUErQixDQUFFLGdCQUE5QixHQUF1QyxDQUExQztRQUNJLFdBQUEsSUFBZTtRQUNmLFdBQUEsSUFBbUI7UUFDbkIsV0FBQSxJQUFtQixPQUFBLEdBQVUsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBbEMsR0FBeUM7UUFDNUQsV0FBQSxJQUFlLFNBSm5COztNQU1BLGdEQUFvQixDQUFFLGFBQXRCO1FBQ0ksV0FBQSxHQUFjLFVBQUEsR0FBYSxLQUFLLENBQUMsSUFBSSxFQUFDLE1BQUQsRUFBTyxDQUFDLElBQS9CLEdBQXNDO1FBRXBELElBQUcsS0FBSyxDQUFDLElBQUksRUFBQyxNQUFELEVBQU8sQ0FBQyxXQUFyQjtVQUNJLFdBQUEsSUFBZSxHQUFBLEdBQU0sS0FBSyxDQUFDLElBQUksRUFBQyxNQUFELEVBQU8sQ0FBQyxZQUQzQzs7UUFHQSxXQUFBLElBQWU7UUFDZixXQUFBLElBQW1CO1FBQ25CLFdBQUEsSUFBbUIsT0FBQSxHQUFVLFdBQVYsR0FBd0I7UUFDM0MsV0FBQSxJQUFlLFNBVG5COztBQVdBLGFBQU87SUFoRFE7Ozs7S0FUUTtBQU4vQiIsInNvdXJjZXNDb250ZW50IjpbIntUZXh0RWRpdG9yfSA9IHJlcXVpcmUgJ2F0b20nXG5cbkFic3RyYWN0UHJvdmlkZXIgPSByZXF1aXJlICcuL2Fic3RyYWN0LXByb3ZpZGVyJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5cbmNsYXNzIFByb3BlcnR5UHJvdmlkZXIgZXh0ZW5kcyBBYnN0cmFjdFByb3ZpZGVyXG4gICAgaG92ZXJFdmVudFNlbGVjdG9yczogJy5wcm9wZXJ0eSdcblxuICAgICMjIypcbiAgICAgKiBSZXRyaWV2ZXMgYSB0b29sdGlwIGZvciB0aGUgd29yZCBnaXZlbi5cbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgICAgICAgICBUZXh0RWRpdG9yIHRvIHNlYXJjaCBmb3IgbmFtZXNwYWNlIG9mIHRlcm0uXG4gICAgICogQHBhcmFtICB7c3RyaW5nfSAgICAgdGVybSAgICAgICAgICAgVGVybSB0byBzZWFyY2ggZm9yLlxuICAgICAqIEBwYXJhbSAge1BvaW50fSAgICAgIGJ1ZmZlclBvc2l0aW9uIFRoZSBjdXJzb3IgbG9jYXRpb24gdGhlIHRlcm0gaXMgYXQuXG4gICAgIyMjXG4gICAgZ2V0VG9vbHRpcEZvcldvcmQ6IChlZGl0b3IsIHRlcm0sIGJ1ZmZlclBvc2l0aW9uKSAtPlxuICAgICAgICB2YWx1ZSA9IEBwYXJzZXIuZ2V0TWVtYmVyQ29udGV4dChlZGl0b3IsIHRlcm0sIGJ1ZmZlclBvc2l0aW9uKVxuXG4gICAgICAgIGlmIG5vdCB2YWx1ZVxuICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgYWNjZXNzTW9kaWZpZXIgPSAnJ1xuICAgICAgICByZXR1cm5UeXBlID0gaWYgdmFsdWUuYXJncy5yZXR1cm4/LnR5cGUgdGhlbiB2YWx1ZS5hcmdzLnJldHVybi50eXBlIGVsc2UgJ21peGVkJ1xuXG4gICAgICAgIGlmIHZhbHVlLmlzUHVibGljXG4gICAgICAgICAgICBhY2Nlc3NNb2RpZmllciA9ICdwdWJsaWMnXG5cbiAgICAgICAgZWxzZSBpZiB2YWx1ZS5pc1Byb3RlY3RlZFxuICAgICAgICAgICAgYWNjZXNzTW9kaWZpZXIgPSAncHJvdGVjdGVkJ1xuXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGFjY2Vzc01vZGlmaWVyID0gJ3ByaXZhdGUnXG5cbiAgICAgICAgIyBDcmVhdGUgYSB1c2VmdWwgZGVzY3JpcHRpb24gdG8gc2hvdyBpbiB0aGUgdG9vbHRpcC5cbiAgICAgICAgZGVzY3JpcHRpb24gPSAnJ1xuXG4gICAgICAgIGRlc2NyaXB0aW9uICs9IFwiPHA+PGRpdj5cIlxuICAgICAgICBkZXNjcmlwdGlvbiArPSBhY2Nlc3NNb2RpZmllciArICcgJyArIHJldHVyblR5cGUgKyAnPHN0cm9uZz4nICsgJyAkJyArIHRlcm0gKyAnPC9zdHJvbmc+J1xuICAgICAgICBkZXNjcmlwdGlvbiArPSAnPC9kaXY+PC9wPidcblxuICAgICAgICAjIFNob3cgdGhlIHN1bW1hcnkgKHNob3J0IGRlc2NyaXB0aW9uKS5cbiAgICAgICAgZGVzY3JpcHRpb24gKz0gJzxkaXY+J1xuICAgICAgICBkZXNjcmlwdGlvbiArPSAgICAgKGlmIHZhbHVlLmFyZ3MuZGVzY3JpcHRpb25zLnNob3J0IHRoZW4gdmFsdWUuYXJncy5kZXNjcmlwdGlvbnMuc2hvcnQgZWxzZSAnKE5vIGRvY3VtZW50YXRpb24gYXZhaWxhYmxlKScpXG4gICAgICAgIGRlc2NyaXB0aW9uICs9ICc8L2Rpdj4nXG5cbiAgICAgICAgIyBTaG93IHRoZSAobG9uZykgZGVzY3JpcHRpb24uXG4gICAgICAgIGlmIHZhbHVlLmFyZ3MuZGVzY3JpcHRpb25zLmxvbmc/Lmxlbmd0aCA+IDBcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uICs9ICc8ZGl2IGNsYXNzPVwic2VjdGlvblwiPidcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uICs9ICAgICBcIjxoND5EZXNjcmlwdGlvbjwvaDQ+XCJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uICs9ICAgICBcIjxkaXY+XCIgKyB2YWx1ZS5hcmdzLmRlc2NyaXB0aW9ucy5sb25nICsgXCI8L2Rpdj5cIlxuICAgICAgICAgICAgZGVzY3JpcHRpb24gKz0gXCI8L2Rpdj5cIlxuXG4gICAgICAgIGlmIHZhbHVlLmFyZ3MucmV0dXJuPy50eXBlXG4gICAgICAgICAgICByZXR1cm5WYWx1ZSA9ICc8c3Ryb25nPicgKyB2YWx1ZS5hcmdzLnJldHVybi50eXBlICsgJzwvc3Ryb25nPidcblxuICAgICAgICAgICAgaWYgdmFsdWUuYXJncy5yZXR1cm4uZGVzY3JpcHRpb25cbiAgICAgICAgICAgICAgICByZXR1cm5WYWx1ZSArPSAnICcgKyB2YWx1ZS5hcmdzLnJldHVybi5kZXNjcmlwdGlvblxuXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSAnPGRpdiBjbGFzcz1cInNlY3Rpb25cIj4nXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSAgICAgXCI8aDQ+VHlwZTwvaDQ+XCJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uICs9ICAgICBcIjxkaXY+XCIgKyByZXR1cm5WYWx1ZSArIFwiPC9kaXY+XCJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uICs9IFwiPC9kaXY+XCJcblxuICAgICAgICByZXR1cm4gZGVzY3JpcHRpb25cbiJdfQ==
