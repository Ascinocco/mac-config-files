(function() {
  var AbstractProvider, MemberProvider, exec, fuzzaldrin, parser, proxy,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  fuzzaldrin = require('fuzzaldrin');

  exec = require("child_process");

  proxy = require("../services/php-proxy.coffee");

  parser = require("../services/php-file-parser.coffee");

  AbstractProvider = require("./abstract-provider");

  module.exports = MemberProvider = (function(superClass) {
    extend(MemberProvider, superClass);

    function MemberProvider() {
      return MemberProvider.__super__.constructor.apply(this, arguments);
    }

    MemberProvider.prototype.methods = [];


    /**
     * Get suggestions from the provider (@see provider-api)
     * @return array
     */

    MemberProvider.prototype.fetchSuggestions = function(arg) {
      var bufferPosition, characterAfterPrefix, classInfo, className, currentClass, currentClassParents, editor, elements, insertParameterList, mustBeStatic, prefix, scopeDescriptor, suggestions;
      editor = arg.editor, bufferPosition = arg.bufferPosition, scopeDescriptor = arg.scopeDescriptor, prefix = arg.prefix;
      this.regex = /(?:(?:[a-zA-Z0-9_]*)\s*(?:\(.*\))?\s*(?:->|::)\s*)+([a-zA-Z0-9_]*)/g;
      prefix = this.getPrefix(editor, bufferPosition);
      if (!prefix.length) {
        return;
      }
      elements = parser.getStackClasses(editor, bufferPosition);
      if (elements == null) {
        return;
      }
      className = parser.parseElements(editor, bufferPosition, elements);
      if (className == null) {
        return;
      }
      elements = prefix.split(/(->|::)/);
      if (!(elements.length > 2)) {
        return;
      }
      currentClass = parser.getFullClassName(editor);
      currentClassParents = [];
      if (currentClass) {
        classInfo = proxy.methods(currentClass);
        currentClassParents = (classInfo != null ? classInfo.parents : void 0) ? classInfo != null ? classInfo.parents : void 0 : [];
      }
      mustBeStatic = false;
      if (elements[elements.length - 2] === '::' && elements[elements.length - 3].trim() !== 'parent') {
        mustBeStatic = true;
      }
      characterAfterPrefix = editor.getTextInRange([bufferPosition, [bufferPosition.row, bufferPosition.column + 1]]);
      insertParameterList = characterAfterPrefix === '(' ? false : true;
      suggestions = this.findSuggestionsForPrefix(className, elements[elements.length - 1].trim(), (function(_this) {
        return function(element) {
          var ref;
          if (mustBeStatic && !element.isStatic) {
            return false;
          }
          if (element.isPrivate && element.declaringClass.name !== currentClass) {
            return false;
          }
          if (element.isProtected && element.declaringClass.name !== currentClass && (ref = element.declaringClass.name, indexOf.call(currentClassParents, ref) < 0)) {
            return false;
          }
          if (!element.isMethod && !element.isProperty && !mustBeStatic) {
            return false;
          }
          return true;
        };
      })(this), insertParameterList);
      if (!suggestions.length) {
        return;
      }
      return suggestions;
    };


    /**
     * Returns suggestions available matching the given prefix
     * @param {string}   className           The name of the class to show members of.
     * @param {string}   prefix              Prefix to match (may be left empty to list all members).
     * @param {callback} filterCallback      A callback that should return true if the item should be added to the
     *                                       suggestions list.
     * @param {bool}     insertParameterList Whether to insert a list of parameters for methods.
     * @return array
     */

    MemberProvider.prototype.findSuggestionsForPrefix = function(className, prefix, filterCallback, insertParameterList) {
      var displayText, ele, element, i, j, len, len1, methods, ref, returnValue, returnValueParts, snippet, suggestions, type, word, words;
      if (insertParameterList == null) {
        insertParameterList = true;
      }
      methods = proxy.methods(className);
      if (!(methods != null ? methods.names : void 0)) {
        return [];
      }
      words = fuzzaldrin.filter(methods.names, prefix);
      suggestions = [];
      for (i = 0, len = words.length; i < len; i++) {
        word = words[i];
        element = methods.values[word];
        if (!(element instanceof Array)) {
          element = [element];
        }
        for (j = 0, len1 = element.length; j < len1; j++) {
          ele = element[j];
          if (filterCallback && !filterCallback(ele)) {
            continue;
          }
          snippet = null;
          displayText = word;
          returnValueParts = ((ref = ele.args["return"]) != null ? ref.type : void 0) ? ele.args["return"].type.split('\\') : [];
          returnValue = returnValueParts[returnValueParts.length - 1];
          if (ele.isMethod) {
            type = 'method';
            snippet = insertParameterList ? this.getFunctionSnippet(word, ele.args) : null;
            displayText = this.getFunctionSignature(word, ele.args);
          } else if (ele.isProperty) {
            type = 'property';
          } else {
            type = 'constant';
          }
          suggestions.push({
            text: word,
            type: type,
            snippet: snippet,
            displayText: displayText,
            leftLabel: returnValue,
            description: ele.args.descriptions.short != null ? ele.args.descriptions.short : '',
            className: ele.args.deprecated ? 'php-atom-autocomplete-strike' : ''
          });
        }
      }
      return suggestions;
    };

    return MemberProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hdXRvY29tcGxldGlvbi9tZW1iZXItcHJvdmlkZXIuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSxpRUFBQTtJQUFBOzs7O0VBQUEsVUFBQSxHQUFhLE9BQUEsQ0FBUSxZQUFSOztFQUNiLElBQUEsR0FBTyxPQUFBLENBQVEsZUFBUjs7RUFFUCxLQUFBLEdBQVEsT0FBQSxDQUFRLDhCQUFSOztFQUNSLE1BQUEsR0FBUyxPQUFBLENBQVEsb0NBQVI7O0VBQ1QsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLHFCQUFSOztFQUVuQixNQUFNLENBQUMsT0FBUCxHQUdNOzs7Ozs7OzZCQUNGLE9BQUEsR0FBUzs7O0FBRVQ7Ozs7OzZCQUlBLGdCQUFBLEdBQWtCLFNBQUMsR0FBRDtBQUVkLFVBQUE7TUFGZ0IscUJBQVEscUNBQWdCLHVDQUFpQjtNQUV6RCxJQUFDLENBQUEsS0FBRCxHQUFTO01BRVQsTUFBQSxHQUFTLElBQUMsQ0FBQSxTQUFELENBQVcsTUFBWCxFQUFtQixjQUFuQjtNQUNULElBQUEsQ0FBYyxNQUFNLENBQUMsTUFBckI7QUFBQSxlQUFBOztNQUVBLFFBQUEsR0FBVyxNQUFNLENBQUMsZUFBUCxDQUF1QixNQUF2QixFQUErQixjQUEvQjtNQUNYLElBQWMsZ0JBQWQ7QUFBQSxlQUFBOztNQUVBLFNBQUEsR0FBWSxNQUFNLENBQUMsYUFBUCxDQUFxQixNQUFyQixFQUE2QixjQUE3QixFQUE2QyxRQUE3QztNQUNaLElBQWMsaUJBQWQ7QUFBQSxlQUFBOztNQUVBLFFBQUEsR0FBVyxNQUFNLENBQUMsS0FBUCxDQUFhLFNBQWI7TUFJWCxJQUFBLENBQUEsQ0FBYyxRQUFRLENBQUMsTUFBVCxHQUFrQixDQUFoQyxDQUFBO0FBQUEsZUFBQTs7TUFFQSxZQUFBLEdBQWUsTUFBTSxDQUFDLGdCQUFQLENBQXdCLE1BQXhCO01BQ2YsbUJBQUEsR0FBc0I7TUFFdEIsSUFBRyxZQUFIO1FBQ0ksU0FBQSxHQUFZLEtBQUssQ0FBQyxPQUFOLENBQWMsWUFBZDtRQUNaLG1CQUFBLHdCQUF5QixTQUFTLENBQUUsaUJBQWQsdUJBQTJCLFNBQVMsQ0FBRSxnQkFBdEMsR0FBbUQsR0FGN0U7O01BSUEsWUFBQSxHQUFlO01BRWYsSUFBRyxRQUFTLENBQUEsUUFBUSxDQUFDLE1BQVQsR0FBa0IsQ0FBbEIsQ0FBVCxLQUFpQyxJQUFqQyxJQUEwQyxRQUFTLENBQUEsUUFBUSxDQUFDLE1BQVQsR0FBa0IsQ0FBbEIsQ0FBb0IsQ0FBQyxJQUE5QixDQUFBLENBQUEsS0FBd0MsUUFBckY7UUFDSSxZQUFBLEdBQWUsS0FEbkI7O01BR0Esb0JBQUEsR0FBdUIsTUFBTSxDQUFDLGNBQVAsQ0FBc0IsQ0FBQyxjQUFELEVBQWlCLENBQUMsY0FBYyxDQUFDLEdBQWhCLEVBQXFCLGNBQWMsQ0FBQyxNQUFmLEdBQXdCLENBQTdDLENBQWpCLENBQXRCO01BQ3ZCLG1CQUFBLEdBQXlCLG9CQUFBLEtBQXdCLEdBQTNCLEdBQW9DLEtBQXBDLEdBQStDO01BRXJFLFdBQUEsR0FBYyxJQUFDLENBQUEsd0JBQUQsQ0FBMEIsU0FBMUIsRUFBcUMsUUFBUyxDQUFBLFFBQVEsQ0FBQyxNQUFULEdBQWdCLENBQWhCLENBQWtCLENBQUMsSUFBNUIsQ0FBQSxDQUFyQyxFQUF5RSxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsT0FBRDtBQUVuRixjQUFBO1VBQUEsSUFBZ0IsWUFBQSxJQUFpQixDQUFJLE9BQU8sQ0FBQyxRQUE3QztBQUFBLG1CQUFPLE1BQVA7O1VBQ0EsSUFBZ0IsT0FBTyxDQUFDLFNBQVIsSUFBc0IsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUF2QixLQUErQixZQUFyRTtBQUFBLG1CQUFPLE1BQVA7O1VBQ0EsSUFBZ0IsT0FBTyxDQUFDLFdBQVIsSUFBd0IsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUF2QixLQUErQixZQUF2RCxJQUF3RSxPQUFBLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBdkIsRUFBQSxhQUFtQyxtQkFBbkMsRUFBQSxHQUFBLEtBQUEsQ0FBeEY7QUFBQSxtQkFBTyxNQUFQOztVQUdBLElBQWdCLENBQUksT0FBTyxDQUFDLFFBQVosSUFBeUIsQ0FBSSxPQUFPLENBQUMsVUFBckMsSUFBb0QsQ0FBSSxZQUF4RTtBQUFBLG1CQUFPLE1BQVA7O0FBRUEsaUJBQU87UUFUNEU7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpFLEVBVVosbUJBVlk7TUFZZCxJQUFBLENBQWMsV0FBVyxDQUFDLE1BQTFCO0FBQUEsZUFBQTs7QUFDQSxhQUFPO0lBL0NPOzs7QUFpRGxCOzs7Ozs7Ozs7OzZCQVNBLHdCQUFBLEdBQTBCLFNBQUMsU0FBRCxFQUFZLE1BQVosRUFBb0IsY0FBcEIsRUFBb0MsbUJBQXBDO0FBQ3RCLFVBQUE7O1FBRDBELHNCQUFzQjs7TUFDaEYsT0FBQSxHQUFVLEtBQUssQ0FBQyxPQUFOLENBQWMsU0FBZDtNQUVWLElBQUcsb0JBQUksT0FBTyxDQUFFLGVBQWhCO0FBQ0ksZUFBTyxHQURYOztNQUlBLEtBQUEsR0FBUSxVQUFVLENBQUMsTUFBWCxDQUFrQixPQUFPLENBQUMsS0FBMUIsRUFBaUMsTUFBakM7TUFHUixXQUFBLEdBQWM7QUFFZCxXQUFBLHVDQUFBOztRQUNJLE9BQUEsR0FBVSxPQUFPLENBQUMsTUFBTyxDQUFBLElBQUE7UUFFekIsSUFBRyxDQUFBLENBQUEsT0FBQSxZQUF1QixLQUF2QixDQUFIO1VBQ0ksT0FBQSxHQUFVLENBQUMsT0FBRCxFQURkOztBQUdBLGFBQUEsMkNBQUE7O1VBQ0ksSUFBRyxjQUFBLElBQW1CLENBQUksY0FBQSxDQUFlLEdBQWYsQ0FBMUI7QUFDSSxxQkFESjs7VUFJQSxPQUFBLEdBQVU7VUFDVixXQUFBLEdBQWM7VUFDZCxnQkFBQSw0Q0FBcUMsQ0FBRSxjQUFwQixHQUE4QixHQUFHLENBQUMsSUFBSSxFQUFDLE1BQUQsRUFBTyxDQUFDLElBQUksQ0FBQyxLQUFyQixDQUEyQixJQUEzQixDQUE5QixHQUFvRTtVQUN2RixXQUFBLEdBQWMsZ0JBQWlCLENBQUEsZ0JBQWdCLENBQUMsTUFBakIsR0FBMEIsQ0FBMUI7VUFFL0IsSUFBRyxHQUFHLENBQUMsUUFBUDtZQUNJLElBQUEsR0FBTztZQUNQLE9BQUEsR0FBYSxtQkFBSCxHQUE0QixJQUFDLENBQUEsa0JBQUQsQ0FBb0IsSUFBcEIsRUFBMEIsR0FBRyxDQUFDLElBQTlCLENBQTVCLEdBQXFFO1lBQy9FLFdBQUEsR0FBYyxJQUFDLENBQUEsb0JBQUQsQ0FBc0IsSUFBdEIsRUFBNEIsR0FBRyxDQUFDLElBQWhDLEVBSGxCO1dBQUEsTUFLSyxJQUFHLEdBQUcsQ0FBQyxVQUFQO1lBQ0QsSUFBQSxHQUFPLFdBRE47V0FBQSxNQUFBO1lBSUQsSUFBQSxHQUFPLFdBSk47O1VBTUwsV0FBVyxDQUFDLElBQVosQ0FDSTtZQUFBLElBQUEsRUFBYyxJQUFkO1lBQ0EsSUFBQSxFQUFjLElBRGQ7WUFFQSxPQUFBLEVBQWMsT0FGZDtZQUdBLFdBQUEsRUFBYyxXQUhkO1lBSUEsU0FBQSxFQUFjLFdBSmQ7WUFLQSxXQUFBLEVBQWlCLG1DQUFILEdBQXFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQTNELEdBQXNFLEVBTHBGO1lBTUEsU0FBQSxFQUFpQixHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVosR0FBNEIsOEJBQTVCLEdBQWdFLEVBTjlFO1dBREo7QUFyQko7QUFOSjtBQW9DQSxhQUFPO0lBaERlOzs7O0tBakVEO0FBVjdCIiwic291cmNlc0NvbnRlbnQiOlsiZnV6emFsZHJpbiA9IHJlcXVpcmUgJ2Z1enphbGRyaW4nXG5leGVjID0gcmVxdWlyZSBcImNoaWxkX3Byb2Nlc3NcIlxuXG5wcm94eSA9IHJlcXVpcmUgXCIuLi9zZXJ2aWNlcy9waHAtcHJveHkuY29mZmVlXCJcbnBhcnNlciA9IHJlcXVpcmUgXCIuLi9zZXJ2aWNlcy9waHAtZmlsZS1wYXJzZXIuY29mZmVlXCJcbkFic3RyYWN0UHJvdmlkZXIgPSByZXF1aXJlIFwiLi9hYnN0cmFjdC1wcm92aWRlclwiXG5cbm1vZHVsZS5leHBvcnRzID1cblxuIyBBdXRvY29tcGxldGlvbiBmb3IgbWVtYmVycyBvZiB2YXJpYWJsZXMgc3VjaCBhcyBhZnRlciAtPiwgOjouXG5jbGFzcyBNZW1iZXJQcm92aWRlciBleHRlbmRzIEFic3RyYWN0UHJvdmlkZXJcbiAgICBtZXRob2RzOiBbXVxuXG4gICAgIyMjKlxuICAgICAqIEdldCBzdWdnZXN0aW9ucyBmcm9tIHRoZSBwcm92aWRlciAoQHNlZSBwcm92aWRlci1hcGkpXG4gICAgICogQHJldHVybiBhcnJheVxuICAgICMjI1xuICAgIGZldGNoU3VnZ2VzdGlvbnM6ICh7ZWRpdG9yLCBidWZmZXJQb3NpdGlvbiwgc2NvcGVEZXNjcmlwdG9yLCBwcmVmaXh9KSAtPlxuICAgICAgICAjIEF1dG9jb21wbGV0aW9uIGZvciBjbGFzcyBtZW1iZXJzLCBpLmUuIGFmdGVyIGEgOjosIC0+LCAuLi5cbiAgICAgICAgQHJlZ2V4ID0gLyg/Oig/OlthLXpBLVowLTlfXSopXFxzKig/OlxcKC4qXFwpKT9cXHMqKD86LT58OjopXFxzKikrKFthLXpBLVowLTlfXSopL2dcblxuICAgICAgICBwcmVmaXggPSBAZ2V0UHJlZml4KGVkaXRvciwgYnVmZmVyUG9zaXRpb24pXG4gICAgICAgIHJldHVybiB1bmxlc3MgcHJlZml4Lmxlbmd0aFxuXG4gICAgICAgIGVsZW1lbnRzID0gcGFyc2VyLmdldFN0YWNrQ2xhc3NlcyhlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uKVxuICAgICAgICByZXR1cm4gdW5sZXNzIGVsZW1lbnRzP1xuXG4gICAgICAgIGNsYXNzTmFtZSA9IHBhcnNlci5wYXJzZUVsZW1lbnRzKGVkaXRvciwgYnVmZmVyUG9zaXRpb24sIGVsZW1lbnRzKVxuICAgICAgICByZXR1cm4gdW5sZXNzIGNsYXNzTmFtZT9cblxuICAgICAgICBlbGVtZW50cyA9IHByZWZpeC5zcGxpdCgvKC0+fDo6KS8pXG5cbiAgICAgICAgIyBXZSBvbmx5IGF1dG9jb21wbGV0ZSBhZnRlciBzcGxpdHRlcnMsIHNvIHRoZXJlIG11c3QgYmUgYXQgbGVhc3Qgb25lIHdvcmQsIG9uZSBzcGxpdHRlciwgYW5kIGFub3RoZXIgd29yZFxuICAgICAgICAjICh0aGUgbGF0dGVyIHdoaWNoIGNvdWxkIGJlIGVtcHR5KS5cbiAgICAgICAgcmV0dXJuIHVubGVzcyBlbGVtZW50cy5sZW5ndGggPiAyXG5cbiAgICAgICAgY3VycmVudENsYXNzID0gcGFyc2VyLmdldEZ1bGxDbGFzc05hbWUoZWRpdG9yKVxuICAgICAgICBjdXJyZW50Q2xhc3NQYXJlbnRzID0gW11cblxuICAgICAgICBpZiBjdXJyZW50Q2xhc3NcbiAgICAgICAgICAgIGNsYXNzSW5mbyA9IHByb3h5Lm1ldGhvZHMoY3VycmVudENsYXNzKVxuICAgICAgICAgICAgY3VycmVudENsYXNzUGFyZW50cyA9IGlmIGNsYXNzSW5mbz8ucGFyZW50cyB0aGVuIGNsYXNzSW5mbz8ucGFyZW50cyBlbHNlIFtdXG5cbiAgICAgICAgbXVzdEJlU3RhdGljID0gZmFsc2VcblxuICAgICAgICBpZiBlbGVtZW50c1tlbGVtZW50cy5sZW5ndGggLSAyXSA9PSAnOjonIGFuZCBlbGVtZW50c1tlbGVtZW50cy5sZW5ndGggLSAzXS50cmltKCkgIT0gJ3BhcmVudCdcbiAgICAgICAgICAgIG11c3RCZVN0YXRpYyA9IHRydWVcblxuICAgICAgICBjaGFyYWN0ZXJBZnRlclByZWZpeCA9IGVkaXRvci5nZXRUZXh0SW5SYW5nZShbYnVmZmVyUG9zaXRpb24sIFtidWZmZXJQb3NpdGlvbi5yb3csIGJ1ZmZlclBvc2l0aW9uLmNvbHVtbiArIDFdXSlcbiAgICAgICAgaW5zZXJ0UGFyYW1ldGVyTGlzdCA9IGlmIGNoYXJhY3RlckFmdGVyUHJlZml4ID09ICcoJyB0aGVuIGZhbHNlIGVsc2UgdHJ1ZVxuXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gQGZpbmRTdWdnZXN0aW9uc0ZvclByZWZpeChjbGFzc05hbWUsIGVsZW1lbnRzW2VsZW1lbnRzLmxlbmd0aC0xXS50cmltKCksIChlbGVtZW50KSA9PlxuICAgICAgICAgICAgIyBTZWUgYWxzbyB0aWNrZXQgIzEyNy5cbiAgICAgICAgICAgIHJldHVybiBmYWxzZSBpZiBtdXN0QmVTdGF0aWMgYW5kIG5vdCBlbGVtZW50LmlzU3RhdGljXG4gICAgICAgICAgICByZXR1cm4gZmFsc2UgaWYgZWxlbWVudC5pc1ByaXZhdGUgYW5kIGVsZW1lbnQuZGVjbGFyaW5nQ2xhc3MubmFtZSAhPSBjdXJyZW50Q2xhc3NcbiAgICAgICAgICAgIHJldHVybiBmYWxzZSBpZiBlbGVtZW50LmlzUHJvdGVjdGVkIGFuZCBlbGVtZW50LmRlY2xhcmluZ0NsYXNzLm5hbWUgIT0gY3VycmVudENsYXNzIGFuZCBlbGVtZW50LmRlY2xhcmluZ0NsYXNzLm5hbWUgbm90IGluIGN1cnJlbnRDbGFzc1BhcmVudHNcblxuICAgICAgICAgICAgIyBDb25zdGFudHMgYXJlIG9ubHkgYXZhaWxhYmxlIHdoZW4gc3RhdGljYWxseSBhY2Nlc3NlZC5cbiAgICAgICAgICAgIHJldHVybiBmYWxzZSBpZiBub3QgZWxlbWVudC5pc01ldGhvZCBhbmQgbm90IGVsZW1lbnQuaXNQcm9wZXJ0eSBhbmQgbm90IG11c3RCZVN0YXRpY1xuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICAsIGluc2VydFBhcmFtZXRlckxpc3QpXG5cbiAgICAgICAgcmV0dXJuIHVubGVzcyBzdWdnZXN0aW9ucy5sZW5ndGhcbiAgICAgICAgcmV0dXJuIHN1Z2dlc3Rpb25zXG5cbiAgICAjIyMqXG4gICAgICogUmV0dXJucyBzdWdnZXN0aW9ucyBhdmFpbGFibGUgbWF0Y2hpbmcgdGhlIGdpdmVuIHByZWZpeFxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSAgIGNsYXNzTmFtZSAgICAgICAgICAgVGhlIG5hbWUgb2YgdGhlIGNsYXNzIHRvIHNob3cgbWVtYmVycyBvZi5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gICBwcmVmaXggICAgICAgICAgICAgIFByZWZpeCB0byBtYXRjaCAobWF5IGJlIGxlZnQgZW1wdHkgdG8gbGlzdCBhbGwgbWVtYmVycykuXG4gICAgICogQHBhcmFtIHtjYWxsYmFja30gZmlsdGVyQ2FsbGJhY2sgICAgICBBIGNhbGxiYWNrIHRoYXQgc2hvdWxkIHJldHVybiB0cnVlIGlmIHRoZSBpdGVtIHNob3VsZCBiZSBhZGRlZCB0byB0aGVcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb25zIGxpc3QuXG4gICAgICogQHBhcmFtIHtib29sfSAgICAgaW5zZXJ0UGFyYW1ldGVyTGlzdCBXaGV0aGVyIHRvIGluc2VydCBhIGxpc3Qgb2YgcGFyYW1ldGVycyBmb3IgbWV0aG9kcy5cbiAgICAgKiBAcmV0dXJuIGFycmF5XG4gICAgIyMjXG4gICAgZmluZFN1Z2dlc3Rpb25zRm9yUHJlZml4OiAoY2xhc3NOYW1lLCBwcmVmaXgsIGZpbHRlckNhbGxiYWNrLCBpbnNlcnRQYXJhbWV0ZXJMaXN0ID0gdHJ1ZSkgLT5cbiAgICAgICAgbWV0aG9kcyA9IHByb3h5Lm1ldGhvZHMoY2xhc3NOYW1lKVxuXG4gICAgICAgIGlmIG5vdCBtZXRob2RzPy5uYW1lc1xuICAgICAgICAgICAgcmV0dXJuIFtdXG5cbiAgICAgICAgIyBGaWx0ZXIgdGhlIHdvcmRzIHVzaW5nIGZ1enphbGRyaW5cbiAgICAgICAgd29yZHMgPSBmdXp6YWxkcmluLmZpbHRlcihtZXRob2RzLm5hbWVzLCBwcmVmaXgpXG5cbiAgICAgICAgIyBCdWlsZHMgc3VnZ2VzdGlvbnMgZm9yIHRoZSB3b3Jkc1xuICAgICAgICBzdWdnZXN0aW9ucyA9IFtdXG5cbiAgICAgICAgZm9yIHdvcmQgaW4gd29yZHNcbiAgICAgICAgICAgIGVsZW1lbnQgPSBtZXRob2RzLnZhbHVlc1t3b3JkXVxuXG4gICAgICAgICAgICBpZiBlbGVtZW50IG5vdCBpbnN0YW5jZW9mIEFycmF5XG4gICAgICAgICAgICAgICAgZWxlbWVudCA9IFtlbGVtZW50XVxuXG4gICAgICAgICAgICBmb3IgZWxlIGluIGVsZW1lbnRcbiAgICAgICAgICAgICAgICBpZiBmaWx0ZXJDYWxsYmFjayBhbmQgbm90IGZpbHRlckNhbGxiYWNrKGVsZSlcbiAgICAgICAgICAgICAgICAgICAgY29udGludWVcblxuICAgICAgICAgICAgICAgICMgRW5zdXJlIHdlIGRvbid0IGdldCB2ZXJ5IGxvbmcgcmV0dXJuIHR5cGVzIGJ5IGp1c3Qgc2hvd2luZyB0aGUgbGFzdCBwYXJ0LlxuICAgICAgICAgICAgICAgIHNuaXBwZXQgPSBudWxsXG4gICAgICAgICAgICAgICAgZGlzcGxheVRleHQgPSB3b3JkXG4gICAgICAgICAgICAgICAgcmV0dXJuVmFsdWVQYXJ0cyA9IGlmIGVsZS5hcmdzLnJldHVybj8udHlwZSB0aGVuIGVsZS5hcmdzLnJldHVybi50eXBlLnNwbGl0KCdcXFxcJykgZWxzZSBbXVxuICAgICAgICAgICAgICAgIHJldHVyblZhbHVlID0gcmV0dXJuVmFsdWVQYXJ0c1tyZXR1cm5WYWx1ZVBhcnRzLmxlbmd0aCAtIDFdXG5cbiAgICAgICAgICAgICAgICBpZiBlbGUuaXNNZXRob2RcbiAgICAgICAgICAgICAgICAgICAgdHlwZSA9ICdtZXRob2QnXG4gICAgICAgICAgICAgICAgICAgIHNuaXBwZXQgPSBpZiBpbnNlcnRQYXJhbWV0ZXJMaXN0IHRoZW4gQGdldEZ1bmN0aW9uU25pcHBldCh3b3JkLCBlbGUuYXJncykgZWxzZSBudWxsXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXlUZXh0ID0gQGdldEZ1bmN0aW9uU2lnbmF0dXJlKHdvcmQsIGVsZS5hcmdzKVxuXG4gICAgICAgICAgICAgICAgZWxzZSBpZiBlbGUuaXNQcm9wZXJ0eVxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ3Byb3BlcnR5J1xuXG4gICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2NvbnN0YW50J1xuXG4gICAgICAgICAgICAgICAgc3VnZ2VzdGlvbnMucHVzaFxuICAgICAgICAgICAgICAgICAgICB0ZXh0ICAgICAgICA6IHdvcmQsXG4gICAgICAgICAgICAgICAgICAgIHR5cGUgICAgICAgIDogdHlwZVxuICAgICAgICAgICAgICAgICAgICBzbmlwcGV0ICAgICA6IHNuaXBwZXRcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheVRleHQgOiBkaXNwbGF5VGV4dFxuICAgICAgICAgICAgICAgICAgICBsZWZ0TGFiZWwgICA6IHJldHVyblZhbHVlXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uIDogaWYgZWxlLmFyZ3MuZGVzY3JpcHRpb25zLnNob3J0PyB0aGVuIGVsZS5hcmdzLmRlc2NyaXB0aW9ucy5zaG9ydCBlbHNlICcnXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZSAgIDogaWYgZWxlLmFyZ3MuZGVwcmVjYXRlZCB0aGVuICdwaHAtYXRvbS1hdXRvY29tcGxldGUtc3RyaWtlJyBlbHNlICcnXG5cbiAgICAgICAgcmV0dXJuIHN1Z2dlc3Rpb25zXG4iXX0=
