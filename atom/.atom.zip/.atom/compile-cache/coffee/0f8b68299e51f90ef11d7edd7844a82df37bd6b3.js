(function() {
  var bashDirProvider, fs, os, path,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  fs = require('fs');

  path = require('path');

  os = require('os');

  module.exports = bashDirProvider = (function() {
    function bashDirProvider() {}

    bashDirProvider.prototype.selector = '.source.shell';

    bashDirProvider.prototype.disableForSelector = '.comment';

    bashDirProvider.prototype.inclusionPriority = 0;

    bashDirProvider.prototype.suggestionPriority = 2;

    bashDirProvider.prototype.filterSuggestions = true;

    bashDirProvider.prototype.excludeLowerPriority = false;

    bashDirProvider.prototype.regex_fn = /((?:(?:\.\.\/)|(?:\.\/)|\/|(?:\~\/))(?:(?:(?:\\\ )|\w|-|\.)+\/)*)((?:[\w\.](?:[\w\.-]|(?:\\\ ))*)*)$/;

    bashDirProvider.prototype.regex_fn_quoted = /((?:(?:\.\.\/)|(?:\.\/)|\/|(?:\~\/))(?:(?:\w|-|\.)(?:\ |\w|-|\.)*\/)*)((?:[\w\.](?:[\w-\.\ ])*)*)$/;

    bashDirProvider.prototype.getSuggestions = function(arg) {
      var bufferPosition, child, editor, err, file, files, parent, quoted, ref, rl, scopeDescriptor;
      editor = arg.editor, bufferPosition = arg.bufferPosition, scopeDescriptor = arg.scopeDescriptor;
      ref = this.getPrefix(editor, bufferPosition, scopeDescriptor), quoted = ref[0], parent = ref[1], child = ref[2];
      rl = null;
      if (parent) {
        try {
          parent = parent.replace(/\\ /g, " ");
          if (parent.startsWith("~")) {
            parent = path.resolve(os.homedir() + parent.slice(1));
          } else if (parent.startsWith(".")) {
            parent = path.resolve(editor.getPath(), "../" + parent + "/");
          }
          if (!fs.accessSync(path.resolve(parent), fs.F_OK | fs.R_OK)) {
            files = fs.readdirSync(path.resolve(parent));
            rl = (function() {
              var i, len, results;
              results = [];
              for (i = 0, len = files.length; i < len; i++) {
                file = files[i];
                try {
                  if (!fs.accessSync(path.resolve(parent + "/" + file), fs.F_OK | fs.R_OK)) {
                    results.push(this.buildDirValue(file, child, parent, quoted, fs.statSync(path.resolve(parent + "/" + file)).isDirectory()));
                  } else {
                    results.push(void 0);
                  }
                } catch (error) {
                  err = error;
                  continue;
                }
              }
              return results;
            }).call(this);
          }
        } catch (error) {
          err = error;
        }
      }
      return rl;
    };

    bashDirProvider.prototype.getPrefix = function(editor, bufferPosition, scopeDescriptor) {
      var line, ref, ref1;
      line = editor.getTextInRange([[bufferPosition.row, 0], bufferPosition]);
      if (indexOf.call(scopeDescriptor.scopes, "string.quoted.double.shell") >= 0) {
        return [true].concat((ref = line.match(this.regex_fn_quoted)) != null ? ref.slice(1, 3) : void 0) || [true, null, null];
      } else {
        return [false].concat((ref1 = line.match(this.regex_fn)) != null ? ref1.slice(1, 3) : void 0) || [false, null, null];
      }
    };

    bashDirProvider.prototype.buildDirValue = function(file, child, parent, quoted, isDir) {
      return {
        text: !quoted ? file.replace(/\ /g, "\\ ") : file,
        type: "constant",
        replacementPrefix: child,
        rightLabel: isDir ? "Directory" : "File",
        description: parent + file
      };
    };

    return bashDirProvider;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWJhc2gtYnVpbHRpbnMvbGliL2RpclByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtBQUFBLE1BQUEsNkJBQUE7SUFBQTs7RUFBQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVI7O0VBQ0wsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSOztFQUNQLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUjs7RUFFTCxNQUFNLENBQUMsT0FBUCxHQUNNOzs7OEJBQ0osUUFBQSxHQUFVOzs4QkFDVixrQkFBQSxHQUFvQjs7OEJBRXBCLGlCQUFBLEdBQW1COzs4QkFDbkIsa0JBQUEsR0FBb0I7OzhCQUNwQixpQkFBQSxHQUFtQjs7OEJBQ25CLG9CQUFBLEdBQXNCOzs4QkFFdEIsUUFBQSxHQUFVOzs4QkFDVixlQUFBLEdBQWlCOzs4QkFFakIsY0FBQSxHQUFnQixTQUFDLEdBQUQ7QUFDZCxVQUFBO01BRGdCLHFCQUFRLHFDQUFnQjtNQUN4QyxNQUEwQixJQUFDLENBQUEsU0FBRCxDQUFXLE1BQVgsRUFBbUIsY0FBbkIsRUFBbUMsZUFBbkMsQ0FBMUIsRUFBQyxlQUFELEVBQVMsZUFBVCxFQUFpQjtNQUNqQixFQUFBLEdBQUs7TUFDTCxJQUFHLE1BQUg7QUFDRTtVQUNFLE1BQUEsR0FBUyxNQUFNLENBQUMsT0FBUCxDQUFlLE1BQWYsRUFBc0IsR0FBdEI7VUFDVCxJQUFHLE1BQU0sQ0FBQyxVQUFQLENBQWtCLEdBQWxCLENBQUg7WUFDRSxNQUFBLEdBQVMsSUFBSSxDQUFDLE9BQUwsQ0FBYSxFQUFFLENBQUMsT0FBSCxDQUFBLENBQUEsR0FBZSxNQUFPLFNBQW5DLEVBRFg7V0FBQSxNQUVLLElBQUcsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsR0FBbEIsQ0FBSDtZQUNILE1BQUEsR0FBUyxJQUFJLENBQUMsT0FBTCxDQUFhLE1BQU0sQ0FBQyxPQUFQLENBQUEsQ0FBYixFQUErQixLQUFBLEdBQU0sTUFBTixHQUFhLEdBQTVDLEVBRE47O1VBRUwsSUFBQSxDQUFPLEVBQUUsQ0FBQyxVQUFILENBQWMsSUFBSSxDQUFDLE9BQUwsQ0FBYSxNQUFiLENBQWQsRUFBb0MsRUFBRSxDQUFDLElBQUgsR0FBVSxFQUFFLENBQUMsSUFBakQsQ0FBUDtZQUNFLEtBQUEsR0FBUSxFQUFFLENBQUMsV0FBSCxDQUFlLElBQUksQ0FBQyxPQUFMLENBQWEsTUFBYixDQUFmO1lBQ1IsRUFBQTs7QUFBSzttQkFBQSx1Q0FBQTs7QUFDSDtrQkFDRSxJQUFBLENBQWlILEVBQUUsQ0FBQyxVQUFILENBQWMsSUFBSSxDQUFDLE9BQUwsQ0FBZ0IsTUFBRCxHQUFRLEdBQVIsR0FBVyxJQUExQixDQUFkLEVBQWlELEVBQUUsQ0FBQyxJQUFILEdBQVUsRUFBRSxDQUFDLElBQTlELENBQWpIO2lDQUFBLElBQUMsQ0FBQSxhQUFELENBQWUsSUFBZixFQUFxQixLQUFyQixFQUE0QixNQUE1QixFQUFvQyxNQUFwQyxFQUE0QyxFQUFFLENBQUMsUUFBSCxDQUFZLElBQUksQ0FBQyxPQUFMLENBQWdCLE1BQUQsR0FBUSxHQUFSLEdBQVcsSUFBMUIsQ0FBWixDQUE4QyxDQUFDLFdBQS9DLENBQUEsQ0FBNUMsR0FBQTttQkFBQSxNQUFBO3lDQUFBO21CQURGO2lCQUFBLGFBQUE7a0JBRU07QUFFSiwyQkFKRjs7QUFERzs7MEJBRlA7V0FORjtTQUFBLGFBQUE7VUFjTSxZQWROO1NBREY7O0FBa0JBLGFBQU87SUFyQk87OzhCQXVCaEIsU0FBQSxHQUFXLFNBQUMsTUFBRCxFQUFTLGNBQVQsRUFBeUIsZUFBekI7QUFHVCxVQUFBO01BQUEsSUFBQSxHQUFPLE1BQU0sQ0FBQyxjQUFQLENBQXNCLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBaEIsRUFBcUIsQ0FBckIsQ0FBRCxFQUEwQixjQUExQixDQUF0QjtNQUVQLElBQUcsYUFBZ0MsZUFBZSxDQUFDLE1BQWhELEVBQUEsNEJBQUEsTUFBSDtlQUNFLENBQUMsSUFBRCxDQUFNLENBQUMsTUFBUCx1REFBNEMscUJBQTVDLENBQUEsSUFBc0QsQ0FBQyxJQUFELEVBQU8sSUFBUCxFQUFhLElBQWIsRUFEeEQ7T0FBQSxNQUFBO2VBR0UsQ0FBQyxLQUFELENBQU8sQ0FBQyxNQUFSLGtEQUFzQyxxQkFBdEMsQ0FBQSxJQUFnRCxDQUFDLEtBQUQsRUFBUSxJQUFSLEVBQWMsSUFBZCxFQUhsRDs7SUFMUzs7OEJBV1gsYUFBQSxHQUFlLFNBQUMsSUFBRCxFQUFPLEtBQVAsRUFBYyxNQUFkLEVBQXNCLE1BQXRCLEVBQThCLEtBQTlCO2FBQ2I7UUFBQSxJQUFBLEVBQVMsQ0FBSSxNQUFQLEdBQW1CLElBQUksQ0FBQyxPQUFMLENBQWEsS0FBYixFQUFvQixLQUFwQixDQUFuQixHQUFtRCxJQUF6RDtRQUNBLElBQUEsRUFBTSxVQUROO1FBRUEsaUJBQUEsRUFBbUIsS0FGbkI7UUFHQSxVQUFBLEVBQWUsS0FBSCxHQUFjLFdBQWQsR0FBK0IsTUFIM0M7UUFJQSxXQUFBLEVBQWEsTUFBQSxHQUFPLElBSnBCOztJQURhOzs7OztBQW5EakIiLCJzb3VyY2VzQ29udGVudCI6WyJcbmZzID0gcmVxdWlyZSAnZnMnXG5wYXRoID0gcmVxdWlyZSAncGF0aCdcbm9zID0gcmVxdWlyZSAnb3MnXG5cbm1vZHVsZS5leHBvcnRzID1cbmNsYXNzIGJhc2hEaXJQcm92aWRlclxuICBzZWxlY3RvcjogJy5zb3VyY2Uuc2hlbGwnXG4gIGRpc2FibGVGb3JTZWxlY3RvcjogJy5jb21tZW50J1xuXG4gIGluY2x1c2lvblByaW9yaXR5OiAwXG4gIHN1Z2dlc3Rpb25Qcmlvcml0eTogMlxuICBmaWx0ZXJTdWdnZXN0aW9uczogdHJ1ZVxuICBleGNsdWRlTG93ZXJQcmlvcml0eTogZmFsc2VcblxuICByZWdleF9mbjogLygoPzooPzpcXC5cXC5cXC8pfCg/OlxcLlxcLyl8XFwvfCg/OlxcflxcLykpKD86KD86KD86XFxcXFxcICl8XFx3fC18XFwuKStcXC8pKikoKD86W1xcd1xcLl0oPzpbXFx3XFwuLV18KD86XFxcXFxcICkpKikqKSQvXG4gIHJlZ2V4X2ZuX3F1b3RlZDogLygoPzooPzpcXC5cXC5cXC8pfCg/OlxcLlxcLyl8XFwvfCg/OlxcflxcLykpKD86KD86XFx3fC18XFwuKSg/OlxcIHxcXHd8LXxcXC4pKlxcLykqKSgoPzpbXFx3XFwuXSg/OltcXHctXFwuXFwgXSkqKSopJC9cblxuICBnZXRTdWdnZXN0aW9uczogKHtlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uLCBzY29wZURlc2NyaXB0b3J9KSAtPlxuICAgIFtxdW90ZWQsIHBhcmVudCwgY2hpbGRdID0gQGdldFByZWZpeChlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uLCBzY29wZURlc2NyaXB0b3IpXG4gICAgcmwgPSBudWxsXG4gICAgaWYgcGFyZW50XG4gICAgICB0cnlcbiAgICAgICAgcGFyZW50ID0gcGFyZW50LnJlcGxhY2UoL1xcXFwgL2csXCIgXCIpXG4gICAgICAgIGlmIHBhcmVudC5zdGFydHNXaXRoKFwiflwiKVxuICAgICAgICAgIHBhcmVudCA9IHBhdGgucmVzb2x2ZShvcy5ob21lZGlyKCkgKyBwYXJlbnRbMS4uLTFdKVxuICAgICAgICBlbHNlIGlmIHBhcmVudC5zdGFydHNXaXRoKFwiLlwiKVxuICAgICAgICAgIHBhcmVudCA9IHBhdGgucmVzb2x2ZShlZGl0b3IuZ2V0UGF0aCgpLCBcIi4uLyN7cGFyZW50fS9cIilcbiAgICAgICAgdW5sZXNzIGZzLmFjY2Vzc1N5bmMocGF0aC5yZXNvbHZlKHBhcmVudCksIGZzLkZfT0sgfCBmcy5SX09LKVxuICAgICAgICAgIGZpbGVzID0gZnMucmVhZGRpclN5bmMocGF0aC5yZXNvbHZlKHBhcmVudCkpXG4gICAgICAgICAgcmwgPSBmb3IgZmlsZSBpbiBmaWxlc1xuICAgICAgICAgICAgdHJ5XG4gICAgICAgICAgICAgIEBidWlsZERpclZhbHVlKGZpbGUsIGNoaWxkLCBwYXJlbnQsIHF1b3RlZCwgZnMuc3RhdFN5bmMocGF0aC5yZXNvbHZlKFwiI3twYXJlbnR9LyN7ZmlsZX1cIikpLmlzRGlyZWN0b3J5KCkpIHVubGVzcyBmcy5hY2Nlc3NTeW5jKHBhdGgucmVzb2x2ZShcIiN7cGFyZW50fS8je2ZpbGV9XCIpLCBmcy5GX09LIHwgZnMuUl9PSylcbiAgICAgICAgICAgIGNhdGNoIGVyclxuICAgICAgICAgICAgICAjIGNvbnNvbGUubG9nIGVyclxuICAgICAgICAgICAgICBjb250aW51ZVxuICAgICAgY2F0Y2ggZXJyXG4gICAgICAgICMgY29uc29sZS5sb2cgZXJyXG5cbiAgICByZXR1cm4gcmxcblxuICBnZXRQcmVmaXg6IChlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uLCBzY29wZURlc2NyaXB0b3IpIC0+XG5cbiAgICAjIEdldCB0aGUgdGV4dCBmb3IgdGhlIGxpbmUgdXAgdG8gdGhlIHRyaWdnZXJlZCBidWZmZXIgcG9zaXRpb25cbiAgICBsaW5lID0gZWRpdG9yLmdldFRleHRJblJhbmdlKFtbYnVmZmVyUG9zaXRpb24ucm93LCAwXSwgYnVmZmVyUG9zaXRpb25dKVxuICAgICMgTWF0Y2ggdGhlIHJlZ2V4IHRvIHRoZSBsaW5lLCBhbmQgcmV0dXJuIHRoZSBtYXRjaFxuICAgIGlmIFwic3RyaW5nLnF1b3RlZC5kb3VibGUuc2hlbGxcIiBpbiBzY29wZURlc2NyaXB0b3Iuc2NvcGVzXG4gICAgICBbdHJ1ZV0uY29uY2F0KGxpbmUubWF0Y2goQHJlZ2V4X2ZuX3F1b3RlZCk/WzEuLjJdKSBvciBbdHJ1ZSwgbnVsbCwgbnVsbF1cbiAgICBlbHNlXG4gICAgICBbZmFsc2VdLmNvbmNhdChsaW5lLm1hdGNoKEByZWdleF9mbik/WzEuLjJdKSBvciBbZmFsc2UsIG51bGwsIG51bGxdXG5cblxuICBidWlsZERpclZhbHVlOiAoZmlsZSwgY2hpbGQsIHBhcmVudCwgcXVvdGVkLCBpc0RpcikgLT5cbiAgICB0ZXh0OiBpZiBub3QgcXVvdGVkIHRoZW4gZmlsZS5yZXBsYWNlKC9cXCAvZywgXCJcXFxcIFwiKSBlbHNlIGZpbGVcbiAgICB0eXBlOiBcImNvbnN0YW50XCJcbiAgICByZXBsYWNlbWVudFByZWZpeDogY2hpbGRcbiAgICByaWdodExhYmVsOiBpZiBpc0RpciB0aGVuIFwiRGlyZWN0b3J5XCIgZWxzZSBcIkZpbGVcIlxuICAgIGRlc2NyaXB0aW9uOiBwYXJlbnQrZmlsZVxuIl19
