(function() {
  var ClassProvider, FunctionProvider, PropertyProvider, TooltipManager;

  ClassProvider = require('./class-provider.coffee');

  FunctionProvider = require('./function-provider.coffee');

  PropertyProvider = require('./property-provider.coffee');

  module.exports = TooltipManager = (function() {
    function TooltipManager() {}

    TooltipManager.prototype.providers = [];


    /**
     * Initializes the tooltip providers.
     */

    TooltipManager.prototype.init = function() {
      var i, len, provider, ref, results;
      this.providers.push(new ClassProvider());
      this.providers.push(new FunctionProvider());
      this.providers.push(new PropertyProvider());
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.init(this));
      }
      return results;
    };


    /**
     * Deactivates the tooltip providers.
     */

    TooltipManager.prototype.deactivate = function() {
      var i, len, provider, ref, results;
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.deactivate());
      }
      return results;
    };

    return TooltipManager;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi90b29sdGlwL3Rvb2x0aXAtbWFuYWdlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLGFBQUEsR0FBZ0IsT0FBQSxDQUFRLHlCQUFSOztFQUNoQixnQkFBQSxHQUFtQixPQUFBLENBQVEsNEJBQVI7O0VBQ25CLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSw0QkFBUjs7RUFFbkIsTUFBTSxDQUFDLE9BQVAsR0FFTTs7OzZCQUNGLFNBQUEsR0FBVzs7O0FBRVg7Ozs7NkJBR0EsSUFBQSxHQUFNLFNBQUE7QUFDRixVQUFBO01BQUEsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQW9CLElBQUEsYUFBQSxDQUFBLENBQXBCO01BQ0EsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQW9CLElBQUEsZ0JBQUEsQ0FBQSxDQUFwQjtNQUNBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFvQixJQUFBLGdCQUFBLENBQUEsQ0FBcEI7QUFFQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxJQUFULENBQWMsSUFBZDtBQURKOztJQUxFOzs7QUFRTjs7Ozs2QkFHQSxVQUFBLEdBQVksU0FBQTtBQUNSLFVBQUE7QUFBQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxVQUFULENBQUE7QUFESjs7SUFEUTs7Ozs7QUF2QmhCIiwic291cmNlc0NvbnRlbnQiOlsiQ2xhc3NQcm92aWRlciA9IHJlcXVpcmUgJy4vY2xhc3MtcHJvdmlkZXIuY29mZmVlJ1xuRnVuY3Rpb25Qcm92aWRlciA9IHJlcXVpcmUgJy4vZnVuY3Rpb24tcHJvdmlkZXIuY29mZmVlJ1xuUHJvcGVydHlQcm92aWRlciA9IHJlcXVpcmUgJy4vcHJvcGVydHktcHJvdmlkZXIuY29mZmVlJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5cbmNsYXNzIFRvb2x0aXBNYW5hZ2VyXG4gICAgcHJvdmlkZXJzOiBbXVxuXG4gICAgIyMjKlxuICAgICAqIEluaXRpYWxpemVzIHRoZSB0b29sdGlwIHByb3ZpZGVycy5cbiAgICAjIyNcbiAgICBpbml0OiAoKSAtPlxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IENsYXNzUHJvdmlkZXIoKVxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IEZ1bmN0aW9uUHJvdmlkZXIoKVxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IFByb3BlcnR5UHJvdmlkZXIoKVxuXG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5pbml0KEApXG5cbiAgICAjIyMqXG4gICAgICogRGVhY3RpdmF0ZXMgdGhlIHRvb2x0aXAgcHJvdmlkZXJzLlxuICAgICMjI1xuICAgIGRlYWN0aXZhdGU6ICgpIC0+XG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5kZWFjdGl2YXRlKClcbiJdfQ==
