(function() {
  var AbstractProvider, FunctionProvider,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  AbstractProvider = require('./abstract-provider');

  module.exports = FunctionProvider = (function(superClass) {
    extend(FunctionProvider, superClass);

    function FunctionProvider() {
      return FunctionProvider.__super__.constructor.apply(this, arguments);
    }

    FunctionProvider.prototype.regex = /(\s*(?:public|protected|private)\s+\$)(\w+)\s+/g;


    /**
     * @inheritdoc
     */

    FunctionProvider.prototype.extractAnnotationInfo = function(editor, row, rowText, match) {
      var context, currentClass, propertyName;
      currentClass = this.parser.getFullClassName(editor);
      propertyName = match[2];
      context = this.parser.getMemberContext(editor, propertyName, null, currentClass);
      if (!context || !context.override) {
        return null;
      }
      return {
        lineNumberClass: 'override',
        tooltipText: 'Overrides property from ' + context.override.declaringClass.name,
        extraData: context.override
      };
    };


    /**
     * @inheritdoc
     */

    FunctionProvider.prototype.handleMouseClick = function(event, editor, annotationInfo) {
      return atom.workspace.open(annotationInfo.extraData.declaringStructure.filename, {
        searchAllPanes: true
      });
    };

    return FunctionProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hbm5vdGF0aW9uL3Byb3BlcnR5LXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsa0NBQUE7SUFBQTs7O0VBQUEsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLHFCQUFSOztFQUVuQixNQUFNLENBQUMsT0FBUCxHQUdNOzs7Ozs7OytCQUNGLEtBQUEsR0FBTzs7O0FBRVA7Ozs7K0JBR0EscUJBQUEsR0FBdUIsU0FBQyxNQUFELEVBQVMsR0FBVCxFQUFjLE9BQWQsRUFBdUIsS0FBdkI7QUFDbkIsVUFBQTtNQUFBLFlBQUEsR0FBZSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE1BQXpCO01BRWYsWUFBQSxHQUFlLEtBQU0sQ0FBQSxDQUFBO01BRXJCLE9BQUEsR0FBVSxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE1BQXpCLEVBQWlDLFlBQWpDLEVBQStDLElBQS9DLEVBQXFELFlBQXJEO01BRVYsSUFBRyxDQUFJLE9BQUosSUFBZSxDQUFJLE9BQU8sQ0FBQyxRQUE5QjtBQUNJLGVBQU8sS0FEWDs7QUFJQSxhQUFPO1FBQ0gsZUFBQSxFQUFrQixVQURmO1FBRUgsV0FBQSxFQUFrQiwwQkFBQSxHQUE2QixPQUFPLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUY1RTtRQUdILFNBQUEsRUFBa0IsT0FBTyxDQUFDLFFBSHZCOztJQVhZOzs7QUFpQnZCOzs7OytCQUdBLGdCQUFBLEdBQWtCLFNBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsY0FBaEI7YUFDZCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQWYsQ0FBb0IsY0FBYyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFoRSxFQUEwRTtRQUV0RSxjQUFBLEVBQWlCLElBRnFEO09BQTFFO0lBRGM7Ozs7S0ExQlM7QUFML0IiLCJzb3VyY2VzQ29udGVudCI6WyJBYnN0cmFjdFByb3ZpZGVyID0gcmVxdWlyZSAnLi9hYnN0cmFjdC1wcm92aWRlcidcblxubW9kdWxlLmV4cG9ydHMgPVxuXG4jIFByb3ZpZGVzIGFubm90YXRpb25zIGZvciBvdmVycmlkaW5nIHByb3BlcnR5LlxuY2xhc3MgRnVuY3Rpb25Qcm92aWRlciBleHRlbmRzIEFic3RyYWN0UHJvdmlkZXJcbiAgICByZWdleDogLyhcXHMqKD86cHVibGljfHByb3RlY3RlZHxwcml2YXRlKVxccytcXCQpKFxcdyspXFxzKy9nXG5cbiAgICAjIyMqXG4gICAgICogQGluaGVyaXRkb2NcbiAgICAjIyNcbiAgICBleHRyYWN0QW5ub3RhdGlvbkluZm86IChlZGl0b3IsIHJvdywgcm93VGV4dCwgbWF0Y2gpIC0+XG4gICAgICAgIGN1cnJlbnRDbGFzcyA9IEBwYXJzZXIuZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IpXG5cbiAgICAgICAgcHJvcGVydHlOYW1lID0gbWF0Y2hbMl1cblxuICAgICAgICBjb250ZXh0ID0gQHBhcnNlci5nZXRNZW1iZXJDb250ZXh0KGVkaXRvciwgcHJvcGVydHlOYW1lLCBudWxsLCBjdXJyZW50Q2xhc3MpXG5cbiAgICAgICAgaWYgbm90IGNvbnRleHQgb3Igbm90IGNvbnRleHQub3ZlcnJpZGVcbiAgICAgICAgICAgIHJldHVybiBudWxsXG5cbiAgICAgICAgIyBOT1RFOiBXZSBkZWxpYmVyYXRlbHkgc2hvdyB0aGUgZGVjbGFyaW5nIGNsYXNzIGhlcmUsIG5vdCB0aGUgc3RydWN0dXJlICh3aGljaCBjb3VsZCBiZSBhIHRyYWl0KS5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGxpbmVOdW1iZXJDbGFzcyA6ICdvdmVycmlkZSdcbiAgICAgICAgICAgIHRvb2x0aXBUZXh0ICAgICA6ICdPdmVycmlkZXMgcHJvcGVydHkgZnJvbSAnICsgY29udGV4dC5vdmVycmlkZS5kZWNsYXJpbmdDbGFzcy5uYW1lXG4gICAgICAgICAgICBleHRyYURhdGEgICAgICAgOiBjb250ZXh0Lm92ZXJyaWRlXG4gICAgICAgIH1cblxuICAgICMjIypcbiAgICAgKiBAaW5oZXJpdGRvY1xuICAgICMjI1xuICAgIGhhbmRsZU1vdXNlQ2xpY2s6IChldmVudCwgZWRpdG9yLCBhbm5vdGF0aW9uSW5mbykgLT5cbiAgICAgICAgYXRvbS53b3Jrc3BhY2Uub3Blbihhbm5vdGF0aW9uSW5mby5leHRyYURhdGEuZGVjbGFyaW5nU3RydWN0dXJlLmZpbGVuYW1lLCB7XG4gICAgICAgICAgICAjIGluaXRpYWxMaW5lICAgIDogYW5ub3RhdGlvbkluZm8uc3RhcnRMaW5lIC0gMSxcbiAgICAgICAgICAgIHNlYXJjaEFsbFBhbmVzIDogdHJ1ZVxuICAgICAgICB9KVxuIl19
