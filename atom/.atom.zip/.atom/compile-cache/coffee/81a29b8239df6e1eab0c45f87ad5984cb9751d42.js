(function() {
  var AnnotationManager, MethodProvider, PropertyProvider;

  MethodProvider = require('./method-provider.coffee');

  PropertyProvider = require('./property-provider.coffee');

  module.exports = AnnotationManager = (function() {
    function AnnotationManager() {}

    AnnotationManager.prototype.providers = [];


    /**
     * Initializes the tooltip providers.
     */

    AnnotationManager.prototype.init = function() {
      var i, len, provider, ref, results;
      this.providers.push(new MethodProvider());
      this.providers.push(new PropertyProvider());
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.init(this));
      }
      return results;
    };


    /**
     * Deactivates the tooltip providers.
     */

    AnnotationManager.prototype.deactivate = function() {
      var i, len, provider, ref, results;
      ref = this.providers;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        provider = ref[i];
        results.push(provider.deactivate());
      }
      return results;
    };

    return AnnotationManager;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hbm5vdGF0aW9uL2Fubm90YXRpb24tbWFuYWdlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLGNBQUEsR0FBaUIsT0FBQSxDQUFRLDBCQUFSOztFQUNqQixnQkFBQSxHQUFtQixPQUFBLENBQVEsNEJBQVI7O0VBRW5CLE1BQU0sQ0FBQyxPQUFQLEdBRU07OztnQ0FDRixTQUFBLEdBQVc7OztBQUVYOzs7O2dDQUdBLElBQUEsR0FBTSxTQUFBO0FBQ0YsVUFBQTtNQUFBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFvQixJQUFBLGNBQUEsQ0FBQSxDQUFwQjtNQUNBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFvQixJQUFBLGdCQUFBLENBQUEsQ0FBcEI7QUFFQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxJQUFULENBQWMsSUFBZDtBQURKOztJQUpFOzs7QUFPTjs7OztnQ0FHQSxVQUFBLEdBQVksU0FBQTtBQUNSLFVBQUE7QUFBQTtBQUFBO1dBQUEscUNBQUE7O3FCQUNJLFFBQVEsQ0FBQyxVQUFULENBQUE7QUFESjs7SUFEUTs7Ozs7QUFyQmhCIiwic291cmNlc0NvbnRlbnQiOlsiTWV0aG9kUHJvdmlkZXIgPSByZXF1aXJlICcuL21ldGhvZC1wcm92aWRlci5jb2ZmZWUnXG5Qcm9wZXJ0eVByb3ZpZGVyID0gcmVxdWlyZSAnLi9wcm9wZXJ0eS1wcm92aWRlci5jb2ZmZWUnXG5cbm1vZHVsZS5leHBvcnRzID1cblxuY2xhc3MgQW5ub3RhdGlvbk1hbmFnZXJcbiAgICBwcm92aWRlcnM6IFtdXG5cbiAgICAjIyMqXG4gICAgICogSW5pdGlhbGl6ZXMgdGhlIHRvb2x0aXAgcHJvdmlkZXJzLlxuICAgICMjI1xuICAgIGluaXQ6ICgpIC0+XG4gICAgICAgIEBwcm92aWRlcnMucHVzaCBuZXcgTWV0aG9kUHJvdmlkZXIoKVxuICAgICAgICBAcHJvdmlkZXJzLnB1c2ggbmV3IFByb3BlcnR5UHJvdmlkZXIoKVxuXG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5pbml0KEApXG5cbiAgICAjIyMqXG4gICAgICogRGVhY3RpdmF0ZXMgdGhlIHRvb2x0aXAgcHJvdmlkZXJzLlxuICAgICMjI1xuICAgIGRlYWN0aXZhdGU6ICgpIC0+XG4gICAgICAgIGZvciBwcm92aWRlciBpbiBAcHJvdmlkZXJzXG4gICAgICAgICAgICBwcm92aWRlci5kZWFjdGl2YXRlKClcbiJdfQ==
