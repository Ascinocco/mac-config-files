(function() {
  var AbstractProvider, AttachedPopover, SubAtom, TextEditor;

  TextEditor = require('atom').TextEditor;

  SubAtom = require('sub-atom');

  AttachedPopover = require('../services/attached-popover');

  module.exports = AbstractProvider = (function() {
    function AbstractProvider() {}

    AbstractProvider.prototype.hoverEventSelectors = '';


    /**
     * Initializes this provider.
     */

    AbstractProvider.prototype.init = function() {
      this.$ = require('jquery');
      this.parser = require('../services/php-file-parser');
      this.subAtom = new SubAtom;
      atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          return _this.registerEvents(editor);
        };
      })(this));
      atom.workspace.onDidDestroyPane((function(_this) {
        return function(pane) {
          var i, len, paneItem, panes, ref, results;
          panes = atom.workspace.getPanes();
          if (panes.length === 1) {
            ref = panes[0].items;
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
              paneItem = ref[i];
              if (paneItem instanceof TextEditor) {
                results.push(_this.registerEvents(paneItem));
              } else {
                results.push(void 0);
              }
            }
            return results;
          }
        };
      })(this));
      return atom.workspace.onDidAddPane((function(_this) {
        return function(observedPane) {
          var i, len, pane, paneItem, panes, results;
          panes = atom.workspace.getPanes();
          results = [];
          for (i = 0, len = panes.length; i < len; i++) {
            pane = panes[i];
            if (pane === observedPane) {
              continue;
            }
            results.push((function() {
              var j, len1, ref, results1;
              ref = pane.items;
              results1 = [];
              for (j = 0, len1 = ref.length; j < len1; j++) {
                paneItem = ref[j];
                if (paneItem instanceof TextEditor) {
                  results1.push(this.registerEvents(paneItem));
                } else {
                  results1.push(void 0);
                }
              }
              return results1;
            }).call(_this));
          }
          return results;
        };
      })(this));
    };


    /**
     * Deactives the provider.
     */

    AbstractProvider.prototype.deactivate = function() {
      document.removeChild(this.popover);
      this.subAtom.dispose();
      return this.removePopover();
    };


    /**
     * Registers the necessary event handlers.
     *
     * @param {TextEditor} editor TextEditor to register events to.
     */

    AbstractProvider.prototype.registerEvents = function(editor) {
      var scrollViewElement, textEditorElement;
      if (editor.getGrammar().scopeName.match(/text.html.php$/)) {
        textEditorElement = atom.views.getView(editor);
        scrollViewElement = this.$(textEditorElement.shadowRoot).find('.scroll-view');
        this.subAtom.add(scrollViewElement, 'mouseover', this.hoverEventSelectors, (function(_this) {
          return function(event) {
            var cursorPosition, editorViewComponent, selector;
            if (_this.timeout) {
              clearTimeout(_this.timeout);
            }
            selector = _this.getSelectorFromEvent(event);
            if (selector === null) {
              return;
            }
            editorViewComponent = atom.views.getView(editor).component;
            if (editorViewComponent) {
              cursorPosition = editorViewComponent.screenPositionForMouseEvent(event);
              _this.removePopover();
              return _this.showPopoverFor(editor, selector, cursorPosition);
            }
          };
        })(this));
        this.subAtom.add(scrollViewElement, 'mouseout', this.hoverEventSelectors, (function(_this) {
          return function(event) {
            return _this.removePopover();
          };
        })(this));
        editor.onDidDestroy((function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        editor.onDidStopChanging((function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        this.$(textEditorElement.shadowRoot).find('.horizontal-scrollbar').on('scroll', (function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        return this.$(textEditorElement.shadowRoot).find('.vertical-scrollbar').on('scroll', (function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
      }
    };


    /**
     * Shows a popover containing the documentation of the specified element located at the specified location.
     *
     * @param {TextEditor} editor         TextEditor containing the elemment.
     * @param {string}     element        The element to search for.
     * @param {Point}      bufferPosition The cursor location the element is at.
     * @param {int}        delay          How long to wait before the popover shows up.
     * @param {int}        fadeInTime     The amount of time to take to fade in the tooltip.
     */

    AbstractProvider.prototype.showPopoverFor = function(editor, element, bufferPosition, delay, fadeInTime) {
      var popoverElement, term, tooltipText;
      if (delay == null) {
        delay = 500;
      }
      if (fadeInTime == null) {
        fadeInTime = 100;
      }
      term = this.$(element).text();
      tooltipText = this.getTooltipForWord(editor, term, bufferPosition);
      if ((tooltipText != null ? tooltipText.length : void 0) > 0) {
        popoverElement = this.getPopoverElementFromSelector(element);
        this.attachedPopover = new AttachedPopover(popoverElement);
        this.attachedPopover.setText('<div style="margin-top: -1em;">' + tooltipText + '</div>');
        return this.attachedPopover.showAfter(delay, fadeInTime);
      }
    };


    /**
     * Removes the popover, if it is displayed.
     */

    AbstractProvider.prototype.removePopover = function() {
      if (this.attachedPopover) {
        this.attachedPopover.dispose();
        return this.attachedPopover = null;
      }
    };


    /**
     * Retrieves a tooltip for the word given.
     *
     * @param {TextEditor} editor         TextEditor to search for namespace of term.
     * @param {string}     term           Term to search for.
     * @param {Point}      bufferPosition The cursor location the term is at.
     */

    AbstractProvider.prototype.getTooltipForWord = function(editor, term, bufferPosition) {};


    /**
     * Gets the correct selector when a selector is clicked.
     * @param  {jQuery.Event}  event  A jQuery event.
     * @return {object|null}          A selector to be used with jQuery.
     */

    AbstractProvider.prototype.getSelectorFromEvent = function(event) {
      return event.currentTarget;
    };


    /**
     * Gets the correct element to attach the popover to from the retrieved selector.
     * @param  {jQuery.Event}  event  A jQuery event.
     * @return {object|null}          A selector to be used with jQuery.
     */

    AbstractProvider.prototype.getPopoverElementFromSelector = function(selector) {
      return selector;
    };

    return AbstractProvider;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi90b29sdGlwL2Fic3RyYWN0LXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUMsYUFBYyxPQUFBLENBQVEsTUFBUjs7RUFFZixPQUFBLEdBQVUsT0FBQSxDQUFRLFVBQVI7O0VBQ1YsZUFBQSxHQUFrQixPQUFBLENBQVEsOEJBQVI7O0VBRWxCLE1BQU0sQ0FBQyxPQUFQLEdBRU07OzsrQkFDRixtQkFBQSxHQUFxQjs7O0FBRXJCOzs7OytCQUdBLElBQUEsR0FBTSxTQUFBO01BQ0YsSUFBQyxDQUFBLENBQUQsR0FBSyxPQUFBLENBQVEsUUFBUjtNQUNMLElBQUMsQ0FBQSxNQUFELEdBQVUsT0FBQSxDQUFRLDZCQUFSO01BRVYsSUFBQyxDQUFBLE9BQUQsR0FBVyxJQUFJO01BRWYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBZixDQUFrQyxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsTUFBRDtpQkFDOUIsS0FBQyxDQUFBLGNBQUQsQ0FBZ0IsTUFBaEI7UUFEOEI7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDO01BSUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZixDQUFnQyxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsSUFBRDtBQUM1QixjQUFBO1VBQUEsS0FBQSxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBZixDQUFBO1VBRVIsSUFBRyxLQUFLLENBQUMsTUFBTixLQUFnQixDQUFuQjtBQUNJO0FBQUE7aUJBQUEscUNBQUE7O2NBQ0ksSUFBRyxRQUFBLFlBQW9CLFVBQXZCOzZCQUNJLEtBQUMsQ0FBQSxjQUFELENBQWdCLFFBQWhCLEdBREo7ZUFBQSxNQUFBO3FDQUFBOztBQURKOzJCQURKOztRQUg0QjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBaEM7YUFTQSxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQWYsQ0FBNEIsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFDLFlBQUQ7QUFDeEIsY0FBQTtVQUFBLEtBQUEsR0FBUSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQWYsQ0FBQTtBQUVSO2VBQUEsdUNBQUE7O1lBQ0ksSUFBRyxJQUFBLEtBQVEsWUFBWDtBQUNJLHVCQURKOzs7O0FBR0E7QUFBQTttQkFBQSx1Q0FBQTs7Z0JBQ0ksSUFBRyxRQUFBLFlBQW9CLFVBQXZCO2dDQUNJLElBQUMsQ0FBQSxjQUFELENBQWdCLFFBQWhCLEdBREo7aUJBQUEsTUFBQTt3Q0FBQTs7QUFESjs7O0FBSko7O1FBSHdCO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE1QjtJQW5CRTs7O0FBOEJOOzs7OytCQUdBLFVBQUEsR0FBWSxTQUFBO01BQ1IsUUFBUSxDQUFDLFdBQVQsQ0FBcUIsSUFBQyxDQUFBLE9BQXRCO01BQ0EsSUFBQyxDQUFBLE9BQU8sQ0FBQyxPQUFULENBQUE7YUFDQSxJQUFDLENBQUEsYUFBRCxDQUFBO0lBSFE7OztBQUtaOzs7Ozs7K0JBS0EsY0FBQSxHQUFnQixTQUFDLE1BQUQ7QUFDWixVQUFBO01BQUEsSUFBRyxNQUFNLENBQUMsVUFBUCxDQUFBLENBQW1CLENBQUMsU0FBUyxDQUFDLEtBQTlCLENBQW9DLGdCQUFwQyxDQUFIO1FBQ0ksaUJBQUEsR0FBb0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLE1BQW5CO1FBQ3BCLGlCQUFBLEdBQW9CLElBQUMsQ0FBQSxDQUFELENBQUcsaUJBQWlCLENBQUMsVUFBckIsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxjQUF0QztRQUVwQixJQUFDLENBQUEsT0FBTyxDQUFDLEdBQVQsQ0FBYSxpQkFBYixFQUFnQyxXQUFoQyxFQUE2QyxJQUFDLENBQUEsbUJBQTlDLEVBQW1FLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUMsS0FBRDtBQUMvRCxnQkFBQTtZQUFBLElBQUcsS0FBQyxDQUFBLE9BQUo7Y0FDSSxZQUFBLENBQWEsS0FBQyxDQUFBLE9BQWQsRUFESjs7WUFHQSxRQUFBLEdBQVcsS0FBQyxDQUFBLG9CQUFELENBQXNCLEtBQXRCO1lBRVgsSUFBRyxRQUFBLEtBQVksSUFBZjtBQUNJLHFCQURKOztZQUdBLG1CQUFBLEdBQXNCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWCxDQUFtQixNQUFuQixDQUEwQixDQUFDO1lBR2pELElBQUcsbUJBQUg7Y0FDSSxjQUFBLEdBQWlCLG1CQUFtQixDQUFDLDJCQUFwQixDQUFnRCxLQUFoRDtjQUVqQixLQUFDLENBQUEsYUFBRCxDQUFBO3FCQUNBLEtBQUMsQ0FBQSxjQUFELENBQWdCLE1BQWhCLEVBQXdCLFFBQXhCLEVBQWtDLGNBQWxDLEVBSko7O1VBWitEO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFuRTtRQWtCQSxJQUFDLENBQUEsT0FBTyxDQUFDLEdBQVQsQ0FBYSxpQkFBYixFQUFnQyxVQUFoQyxFQUE0QyxJQUFDLENBQUEsbUJBQTdDLEVBQWtFLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUMsS0FBRDttQkFDOUQsS0FBQyxDQUFBLGFBQUQsQ0FBQTtVQUQ4RDtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEU7UUFNQSxNQUFNLENBQUMsWUFBUCxDQUFvQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUNoQixLQUFDLENBQUEsYUFBRCxDQUFBO1VBRGdCO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFwQjtRQUdBLE1BQU0sQ0FBQyxpQkFBUCxDQUF5QixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUNyQixLQUFDLENBQUEsYUFBRCxDQUFBO1VBRHFCO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QjtRQUdBLElBQUMsQ0FBQSxDQUFELENBQUcsaUJBQWlCLENBQUMsVUFBckIsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyx1QkFBdEMsQ0FBOEQsQ0FBQyxFQUEvRCxDQUFrRSxRQUFsRSxFQUE0RSxDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUN4RSxLQUFDLENBQUEsYUFBRCxDQUFBO1VBRHdFO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE1RTtlQUdBLElBQUMsQ0FBQSxDQUFELENBQUcsaUJBQWlCLENBQUMsVUFBckIsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxxQkFBdEMsQ0FBNEQsQ0FBQyxFQUE3RCxDQUFnRSxRQUFoRSxFQUEwRSxDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUN0RSxLQUFDLENBQUEsYUFBRCxDQUFBO1VBRHNFO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUExRSxFQXJDSjs7SUFEWTs7O0FBeUNoQjs7Ozs7Ozs7OzsrQkFTQSxjQUFBLEdBQWdCLFNBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsY0FBbEIsRUFBa0MsS0FBbEMsRUFBK0MsVUFBL0M7QUFDWixVQUFBOztRQUQ4QyxRQUFROzs7UUFBSyxhQUFhOztNQUN4RSxJQUFBLEdBQU8sSUFBQyxDQUFBLENBQUQsQ0FBRyxPQUFILENBQVcsQ0FBQyxJQUFaLENBQUE7TUFDUCxXQUFBLEdBQWMsSUFBQyxDQUFBLGlCQUFELENBQW1CLE1BQW5CLEVBQTJCLElBQTNCLEVBQWlDLGNBQWpDO01BRWQsMkJBQUcsV0FBVyxDQUFFLGdCQUFiLEdBQXNCLENBQXpCO1FBQ0ksY0FBQSxHQUFpQixJQUFDLENBQUEsNkJBQUQsQ0FBK0IsT0FBL0I7UUFFakIsSUFBQyxDQUFBLGVBQUQsR0FBdUIsSUFBQSxlQUFBLENBQWdCLGNBQWhCO1FBQ3ZCLElBQUMsQ0FBQSxlQUFlLENBQUMsT0FBakIsQ0FBeUIsaUNBQUEsR0FBb0MsV0FBcEMsR0FBa0QsUUFBM0U7ZUFDQSxJQUFDLENBQUEsZUFBZSxDQUFDLFNBQWpCLENBQTJCLEtBQTNCLEVBQWtDLFVBQWxDLEVBTEo7O0lBSlk7OztBQVdoQjs7OzsrQkFHQSxhQUFBLEdBQWUsU0FBQTtNQUNYLElBQUcsSUFBQyxDQUFBLGVBQUo7UUFDSSxJQUFDLENBQUEsZUFBZSxDQUFDLE9BQWpCLENBQUE7ZUFDQSxJQUFDLENBQUEsZUFBRCxHQUFtQixLQUZ2Qjs7SUFEVzs7O0FBS2Y7Ozs7Ozs7OytCQU9BLGlCQUFBLEdBQW1CLFNBQUMsTUFBRCxFQUFTLElBQVQsRUFBZSxjQUFmLEdBQUE7OztBQUVuQjs7Ozs7OytCQUtBLG9CQUFBLEdBQXNCLFNBQUMsS0FBRDtBQUNsQixhQUFPLEtBQUssQ0FBQztJQURLOzs7QUFHdEI7Ozs7OzsrQkFLQSw2QkFBQSxHQUErQixTQUFDLFFBQUQ7QUFDM0IsYUFBTztJQURvQjs7Ozs7QUFuSm5DIiwic291cmNlc0NvbnRlbnQiOlsie1RleHRFZGl0b3J9ID0gcmVxdWlyZSAnYXRvbSdcblxuU3ViQXRvbSA9IHJlcXVpcmUgJ3N1Yi1hdG9tJ1xuQXR0YWNoZWRQb3BvdmVyID0gcmVxdWlyZSAnLi4vc2VydmljZXMvYXR0YWNoZWQtcG9wb3ZlcidcblxubW9kdWxlLmV4cG9ydHMgPVxuXG5jbGFzcyBBYnN0cmFjdFByb3ZpZGVyXG4gICAgaG92ZXJFdmVudFNlbGVjdG9yczogJydcblxuICAgICMjIypcbiAgICAgKiBJbml0aWFsaXplcyB0aGlzIHByb3ZpZGVyLlxuICAgICMjI1xuICAgIGluaXQ6ICgpIC0+XG4gICAgICAgIEAkID0gcmVxdWlyZSAnanF1ZXJ5J1xuICAgICAgICBAcGFyc2VyID0gcmVxdWlyZSAnLi4vc2VydmljZXMvcGhwLWZpbGUtcGFyc2VyJ1xuXG4gICAgICAgIEBzdWJBdG9tID0gbmV3IFN1YkF0b21cblxuICAgICAgICBhdG9tLndvcmtzcGFjZS5vYnNlcnZlVGV4dEVkaXRvcnMgKGVkaXRvcikgPT5cbiAgICAgICAgICAgIEByZWdpc3RlckV2ZW50cyBlZGl0b3JcblxuICAgICAgICAjIFdoZW4geW91IGdvIGJhY2sgdG8gb25seSBoYXZlIG9uZSBwYW5lIHRoZSBldmVudHMgYXJlIGxvc3QsIHNvIG5lZWQgdG8gcmUtcmVnaXN0ZXIuXG4gICAgICAgIGF0b20ud29ya3NwYWNlLm9uRGlkRGVzdHJveVBhbmUgKHBhbmUpID0+XG4gICAgICAgICAgICBwYW5lcyA9IGF0b20ud29ya3NwYWNlLmdldFBhbmVzKClcblxuICAgICAgICAgICAgaWYgcGFuZXMubGVuZ3RoID09IDFcbiAgICAgICAgICAgICAgICBmb3IgcGFuZUl0ZW0gaW4gcGFuZXNbMF0uaXRlbXNcbiAgICAgICAgICAgICAgICAgICAgaWYgcGFuZUl0ZW0gaW5zdGFuY2VvZiBUZXh0RWRpdG9yXG4gICAgICAgICAgICAgICAgICAgICAgICBAcmVnaXN0ZXJFdmVudHMgcGFuZUl0ZW1cblxuICAgICAgICAjIEhhdmluZyB0byByZS1yZWdpc3RlciBldmVudHMgYXMgd2hlbiBhIG5ldyBwYW5lIGlzIGNyZWF0ZWQgdGhlIG9sZCBwYW5lcyBsb3NlIHRoZSBldmVudHMuXG4gICAgICAgIGF0b20ud29ya3NwYWNlLm9uRGlkQWRkUGFuZSAob2JzZXJ2ZWRQYW5lKSA9PlxuICAgICAgICAgICAgcGFuZXMgPSBhdG9tLndvcmtzcGFjZS5nZXRQYW5lcygpXG5cbiAgICAgICAgICAgIGZvciBwYW5lIGluIHBhbmVzXG4gICAgICAgICAgICAgICAgaWYgcGFuZSA9PSBvYnNlcnZlZFBhbmVcbiAgICAgICAgICAgICAgICAgICAgY29udGludWVcblxuICAgICAgICAgICAgICAgIGZvciBwYW5lSXRlbSBpbiBwYW5lLml0ZW1zXG4gICAgICAgICAgICAgICAgICAgIGlmIHBhbmVJdGVtIGluc3RhbmNlb2YgVGV4dEVkaXRvclxuICAgICAgICAgICAgICAgICAgICAgICAgQHJlZ2lzdGVyRXZlbnRzIHBhbmVJdGVtXG5cbiAgICAjIyMqXG4gICAgICogRGVhY3RpdmVzIHRoZSBwcm92aWRlci5cbiAgICAjIyNcbiAgICBkZWFjdGl2YXRlOiAoKSAtPlxuICAgICAgICBkb2N1bWVudC5yZW1vdmVDaGlsZChAcG9wb3ZlcilcbiAgICAgICAgQHN1YkF0b20uZGlzcG9zZSgpXG4gICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICMjIypcbiAgICAgKiBSZWdpc3RlcnMgdGhlIG5lY2Vzc2FyeSBldmVudCBoYW5kbGVycy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yIFRleHRFZGl0b3IgdG8gcmVnaXN0ZXIgZXZlbnRzIHRvLlxuICAgICMjI1xuICAgIHJlZ2lzdGVyRXZlbnRzOiAoZWRpdG9yKSAtPlxuICAgICAgICBpZiBlZGl0b3IuZ2V0R3JhbW1hcigpLnNjb3BlTmFtZS5tYXRjaCAvdGV4dC5odG1sLnBocCQvXG4gICAgICAgICAgICB0ZXh0RWRpdG9yRWxlbWVudCA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpXG4gICAgICAgICAgICBzY3JvbGxWaWV3RWxlbWVudCA9IEAkKHRleHRFZGl0b3JFbGVtZW50LnNoYWRvd1Jvb3QpLmZpbmQoJy5zY3JvbGwtdmlldycpXG5cbiAgICAgICAgICAgIEBzdWJBdG9tLmFkZCBzY3JvbGxWaWV3RWxlbWVudCwgJ21vdXNlb3ZlcicsIEBob3ZlckV2ZW50U2VsZWN0b3JzLCAoZXZlbnQpID0+XG4gICAgICAgICAgICAgICAgaWYgQHRpbWVvdXRcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KEB0aW1lb3V0KVxuXG4gICAgICAgICAgICAgICAgc2VsZWN0b3IgPSBAZ2V0U2VsZWN0b3JGcm9tRXZlbnQoZXZlbnQpXG5cbiAgICAgICAgICAgICAgICBpZiBzZWxlY3RvciA9PSBudWxsXG4gICAgICAgICAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgICAgICAgICAgZWRpdG9yVmlld0NvbXBvbmVudCA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpLmNvbXBvbmVudFxuXG4gICAgICAgICAgICAgICAgIyBUaWNrZXQgIzE0MCAtIEluIHJhcmUgY2FzZXMgdGhlIGNvbXBvbmVudCBpcyBudWxsLlxuICAgICAgICAgICAgICAgIGlmIGVkaXRvclZpZXdDb21wb25lbnRcbiAgICAgICAgICAgICAgICAgICAgY3Vyc29yUG9zaXRpb24gPSBlZGl0b3JWaWV3Q29tcG9uZW50LnNjcmVlblBvc2l0aW9uRm9yTW91c2VFdmVudChldmVudClcblxuICAgICAgICAgICAgICAgICAgICBAcmVtb3ZlUG9wb3ZlcigpXG4gICAgICAgICAgICAgICAgICAgIEBzaG93UG9wb3ZlckZvcihlZGl0b3IsIHNlbGVjdG9yLCBjdXJzb3JQb3NpdGlvbilcblxuICAgICAgICAgICAgQHN1YkF0b20uYWRkIHNjcm9sbFZpZXdFbGVtZW50LCAnbW91c2VvdXQnLCBAaG92ZXJFdmVudFNlbGVjdG9ycywgKGV2ZW50KSA9PlxuICAgICAgICAgICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICAgICAgICAgIyBUaWNrZXQgIzEwNyAtIE1vdXNlb3V0IGlzbid0IGdlbmVyYXRlZCB1bnRpbCB0aGUgbW91c2UgbW92ZXMsIGV2ZW4gd2hlbiBzY3JvbGxpbmcgKHdpdGggdGhlIGtleWJvYXJkIG9yXG4gICAgICAgICAgICAjIG1vdXNlKS4gSWYgdGhlIGVsZW1lbnQgZ29lcyBvdXQgb2YgdGhlIHZpZXcgaW4gdGhlIG1lYW50aW1lLCBpdHMgSFRNTCBlbGVtZW50IGRpc2FwcGVhcnMsIG5ldmVyIHJlbW92aW5nXG4gICAgICAgICAgICAjIGl0LlxuICAgICAgICAgICAgZWRpdG9yLm9uRGlkRGVzdHJveSAoKSA9PlxuICAgICAgICAgICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICAgICAgICAgZWRpdG9yLm9uRGlkU3RvcENoYW5naW5nICgpID0+XG4gICAgICAgICAgICAgICAgQHJlbW92ZVBvcG92ZXIoKVxuXG4gICAgICAgICAgICBAJCh0ZXh0RWRpdG9yRWxlbWVudC5zaGFkb3dSb290KS5maW5kKCcuaG9yaXpvbnRhbC1zY3JvbGxiYXInKS5vbiAnc2Nyb2xsJywgKCkgPT5cbiAgICAgICAgICAgICAgICBAcmVtb3ZlUG9wb3ZlcigpXG5cbiAgICAgICAgICAgIEAkKHRleHRFZGl0b3JFbGVtZW50LnNoYWRvd1Jvb3QpLmZpbmQoJy52ZXJ0aWNhbC1zY3JvbGxiYXInKS5vbiAnc2Nyb2xsJywgKCkgPT5cbiAgICAgICAgICAgICAgICBAcmVtb3ZlUG9wb3ZlcigpXG5cbiAgICAjIyMqXG4gICAgICogU2hvd3MgYSBwb3BvdmVyIGNvbnRhaW5pbmcgdGhlIGRvY3VtZW50YXRpb24gb2YgdGhlIHNwZWNpZmllZCBlbGVtZW50IGxvY2F0ZWQgYXQgdGhlIHNwZWNpZmllZCBsb2NhdGlvbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VGV4dEVkaXRvcn0gZWRpdG9yICAgICAgICAgVGV4dEVkaXRvciBjb250YWluaW5nIHRoZSBlbGVtbWVudC5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gICAgIGVsZW1lbnQgICAgICAgIFRoZSBlbGVtZW50IHRvIHNlYXJjaCBmb3IuXG4gICAgICogQHBhcmFtIHtQb2ludH0gICAgICBidWZmZXJQb3NpdGlvbiBUaGUgY3Vyc29yIGxvY2F0aW9uIHRoZSBlbGVtZW50IGlzIGF0LlxuICAgICAqIEBwYXJhbSB7aW50fSAgICAgICAgZGVsYXkgICAgICAgICAgSG93IGxvbmcgdG8gd2FpdCBiZWZvcmUgdGhlIHBvcG92ZXIgc2hvd3MgdXAuXG4gICAgICogQHBhcmFtIHtpbnR9ICAgICAgICBmYWRlSW5UaW1lICAgICBUaGUgYW1vdW50IG9mIHRpbWUgdG8gdGFrZSB0byBmYWRlIGluIHRoZSB0b29sdGlwLlxuICAgICMjI1xuICAgIHNob3dQb3BvdmVyRm9yOiAoZWRpdG9yLCBlbGVtZW50LCBidWZmZXJQb3NpdGlvbiwgZGVsYXkgPSA1MDAsIGZhZGVJblRpbWUgPSAxMDApIC0+XG4gICAgICAgIHRlcm0gPSBAJChlbGVtZW50KS50ZXh0KClcbiAgICAgICAgdG9vbHRpcFRleHQgPSBAZ2V0VG9vbHRpcEZvcldvcmQoZWRpdG9yLCB0ZXJtLCBidWZmZXJQb3NpdGlvbilcblxuICAgICAgICBpZiB0b29sdGlwVGV4dD8ubGVuZ3RoID4gMFxuICAgICAgICAgICAgcG9wb3ZlckVsZW1lbnQgPSBAZ2V0UG9wb3ZlckVsZW1lbnRGcm9tU2VsZWN0b3IoZWxlbWVudClcblxuICAgICAgICAgICAgQGF0dGFjaGVkUG9wb3ZlciA9IG5ldyBBdHRhY2hlZFBvcG92ZXIocG9wb3ZlckVsZW1lbnQpXG4gICAgICAgICAgICBAYXR0YWNoZWRQb3BvdmVyLnNldFRleHQoJzxkaXYgc3R5bGU9XCJtYXJnaW4tdG9wOiAtMWVtO1wiPicgKyB0b29sdGlwVGV4dCArICc8L2Rpdj4nKVxuICAgICAgICAgICAgQGF0dGFjaGVkUG9wb3Zlci5zaG93QWZ0ZXIoZGVsYXksIGZhZGVJblRpbWUpXG5cbiAgICAjIyMqXG4gICAgICogUmVtb3ZlcyB0aGUgcG9wb3ZlciwgaWYgaXQgaXMgZGlzcGxheWVkLlxuICAgICMjI1xuICAgIHJlbW92ZVBvcG92ZXI6ICgpIC0+XG4gICAgICAgIGlmIEBhdHRhY2hlZFBvcG92ZXJcbiAgICAgICAgICAgIEBhdHRhY2hlZFBvcG92ZXIuZGlzcG9zZSgpXG4gICAgICAgICAgICBAYXR0YWNoZWRQb3BvdmVyID0gbnVsbFxuXG4gICAgIyMjKlxuICAgICAqIFJldHJpZXZlcyBhIHRvb2x0aXAgZm9yIHRoZSB3b3JkIGdpdmVuLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSBlZGl0b3IgICAgICAgICBUZXh0RWRpdG9yIHRvIHNlYXJjaCBmb3IgbmFtZXNwYWNlIG9mIHRlcm0uXG4gICAgICogQHBhcmFtIHtzdHJpbmd9ICAgICB0ZXJtICAgICAgICAgICBUZXJtIHRvIHNlYXJjaCBmb3IuXG4gICAgICogQHBhcmFtIHtQb2ludH0gICAgICBidWZmZXJQb3NpdGlvbiBUaGUgY3Vyc29yIGxvY2F0aW9uIHRoZSB0ZXJtIGlzIGF0LlxuICAgICMjI1xuICAgIGdldFRvb2x0aXBGb3JXb3JkOiAoZWRpdG9yLCB0ZXJtLCBidWZmZXJQb3NpdGlvbikgLT5cblxuICAgICMjIypcbiAgICAgKiBHZXRzIHRoZSBjb3JyZWN0IHNlbGVjdG9yIHdoZW4gYSBzZWxlY3RvciBpcyBjbGlja2VkLlxuICAgICAqIEBwYXJhbSAge2pRdWVyeS5FdmVudH0gIGV2ZW50ICBBIGpRdWVyeSBldmVudC5cbiAgICAgKiBAcmV0dXJuIHtvYmplY3R8bnVsbH0gICAgICAgICAgQSBzZWxlY3RvciB0byBiZSB1c2VkIHdpdGggalF1ZXJ5LlxuICAgICMjI1xuICAgIGdldFNlbGVjdG9yRnJvbUV2ZW50OiAoZXZlbnQpIC0+XG4gICAgICAgIHJldHVybiBldmVudC5jdXJyZW50VGFyZ2V0XG5cbiAgICAjIyMqXG4gICAgICogR2V0cyB0aGUgY29ycmVjdCBlbGVtZW50IHRvIGF0dGFjaCB0aGUgcG9wb3ZlciB0byBmcm9tIHRoZSByZXRyaWV2ZWQgc2VsZWN0b3IuXG4gICAgICogQHBhcmFtICB7alF1ZXJ5LkV2ZW50fSAgZXZlbnQgIEEgalF1ZXJ5IGV2ZW50LlxuICAgICAqIEByZXR1cm4ge29iamVjdHxudWxsfSAgICAgICAgICBBIHNlbGVjdG9yIHRvIGJlIHVzZWQgd2l0aCBqUXVlcnkuXG4gICAgIyMjXG4gICAgZ2V0UG9wb3ZlckVsZW1lbnRGcm9tU2VsZWN0b3I6IChzZWxlY3RvcikgLT5cbiAgICAgICAgcmV0dXJuIHNlbGVjdG9yXG4iXX0=
