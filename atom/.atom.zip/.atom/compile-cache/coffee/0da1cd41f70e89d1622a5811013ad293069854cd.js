(function() {
  var args, coffee, execSync;

  execSync = require('child_process').execSync;

  args = ['-e'];

  try {
    coffee = execSync('coffee -h');
    if (coffee.toString().match(/--cli/)) {
      args.push('--cli');
    }
  } catch (_error) {}

  exports.args = args;

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ncmFtbWFyLXV0aWxzL2NvZmZlZS1zY3JpcHQtY29tcGlsZXIuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBRUE7QUFBQSxNQUFBLHNCQUFBOztBQUFBLEVBQUMsV0FBWSxPQUFBLENBQVEsZUFBUixFQUFaLFFBQUQsQ0FBQTs7QUFBQSxFQUVBLElBQUEsR0FBTyxDQUFDLElBQUQsQ0FGUCxDQUFBOztBQUdBO0FBQ0UsSUFBQSxNQUFBLEdBQVMsUUFBQSxDQUFTLFdBQVQsQ0FBVCxDQUFBO0FBQ0EsSUFBQSxJQUFHLE1BQU0sQ0FBQyxRQUFQLENBQUEsQ0FBaUIsQ0FBQyxLQUFsQixDQUF3QixPQUF4QixDQUFIO0FBQ0UsTUFBQSxJQUFJLENBQUMsSUFBTCxDQUFVLE9BQVYsQ0FBQSxDQURGO0tBRkY7R0FBQSxrQkFIQTs7QUFBQSxFQVFBLE9BQU8sQ0FBQyxJQUFSLEdBQWUsSUFSZixDQUFBO0FBQUEiCn0=

//# sourceURL=/Users/anthony/.atom/packages/script/lib/grammar-utils/coffee-script-compiler.coffee
