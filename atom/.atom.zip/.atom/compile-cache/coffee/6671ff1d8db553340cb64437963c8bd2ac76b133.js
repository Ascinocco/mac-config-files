(function() {
  var AnnotationManager, AutocompletionManager, GotoManager, StatusInProgress, TooltipManager, config, parser, plugins, proxy;

  GotoManager = require("./goto/goto-manager.coffee");

  TooltipManager = require("./tooltip/tooltip-manager.coffee");

  AnnotationManager = require("./annotation/annotation-manager.coffee");

  AutocompletionManager = require("./autocompletion/autocompletion-manager.coffee");

  StatusInProgress = require("./services/status-in-progress.coffee");

  config = require('./config.coffee');

  proxy = require('./services/php-proxy.coffee');

  parser = require('./services/php-file-parser.coffee');

  plugins = require('./services/plugin-manager.coffee');

  module.exports = {
    config: {
      binComposer: {
        title: 'Command to use composer',
        description: 'This plugin depends on composer in order to work. Specify the path to your composer bin (e.g : bin/composer, composer.phar, composer)',
        type: 'string',
        "default": '/usr/local/bin/composer',
        order: 1
      },
      binPhp: {
        title: 'Command php',
        description: 'This plugin use php CLI in order to work. Please specify your php command ("php" on UNIX systems)',
        type: 'string',
        "default": 'php',
        order: 2
      },
      autoloadPaths: {
        title: 'Autoloader file',
        description: 'Relative path to the files of autoload.php from composer (or an other one). You can specify multiple paths (comma separated) if you have different paths for some projects.',
        type: 'array',
        "default": ['vendor/autoload.php', 'autoload.php'],
        order: 3
      },
      classMapFiles: {
        title: 'Classmap files',
        description: 'Relative path to the files that contains a classmap (array with "className" => "fileName"). By default on composer it\'s vendor/composer/autoload_classmap.php',
        type: 'array',
        "default": ['vendor/composer/autoload_classmap.php', 'autoload/ezp_kernel.php'],
        order: 4
      },
      insertNewlinesForUseStatements: {
        title: 'Insert newlines for use statements.',
        description: 'When enabled, the plugin will add additional newlines before or after an automatically added use statement when it can\'t add them nicely to an existing group. This results in more cleanly separated use statements but will create additional vertical whitespace.',
        type: 'boolean',
        "default": false,
        order: 5
      },
      verboseErrors: {
        title: 'Errors on file saving showed',
        description: 'When enabled, you\'ll have a notification once an error occured on autocomplete. Otherwise, the message will just be logged in developer console',
        type: 'boolean',
        "default": false,
        order: 6
      }
    },
    activate: function() {
      config.testConfig();
      config.init();
      this.autocompletionManager = new AutocompletionManager();
      this.autocompletionManager.init();
      this.gotoManager = new GotoManager();
      this.gotoManager.init();
      this.tooltipManager = new TooltipManager();
      this.tooltipManager.init();
      this.annotationManager = new AnnotationManager();
      this.annotationManager.init();
      return proxy.init();
    },
    deactivate: function() {
      this.gotoManager.deactivate();
      this.tooltipManager.deactivate();
      this.annotationManager.deactivate();
      return this.autocompletionManager.deactivate();
    },
    consumeStatusBar: function(statusBar) {
      config.statusInProgress.initialize(statusBar);
      return config.statusInProgress.attach();
    },
    consumePlugin: function(plugin) {
      return plugins.plugins.push(plugin);
    },
    provideAutocompleteTools: function() {
      this.services = {
        proxy: proxy,
        parser: parser
      };
      return this.services;
    },
    getProvider: function() {
      return this.autocompletionManager.getProviders();
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9wZWVrbW8tcGhwLWF0b20tYXV0b2NvbXBsZXRlLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsV0FBQSxHQUFjLE9BQUEsQ0FBUSw0QkFBUjs7RUFDZCxjQUFBLEdBQWlCLE9BQUEsQ0FBUSxrQ0FBUjs7RUFDakIsaUJBQUEsR0FBb0IsT0FBQSxDQUFRLHdDQUFSOztFQUNwQixxQkFBQSxHQUF3QixPQUFBLENBQVEsZ0RBQVI7O0VBQ3hCLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSxzQ0FBUjs7RUFDbkIsTUFBQSxHQUFTLE9BQUEsQ0FBUSxpQkFBUjs7RUFDVCxLQUFBLEdBQVEsT0FBQSxDQUFRLDZCQUFSOztFQUNSLE1BQUEsR0FBUyxPQUFBLENBQVEsbUNBQVI7O0VBQ1QsT0FBQSxHQUFVLE9BQUEsQ0FBUSxrQ0FBUjs7RUFFVixNQUFNLENBQUMsT0FBUCxHQUNJO0lBQUEsTUFBQSxFQUNJO01BQUEsV0FBQSxFQUNJO1FBQUEsS0FBQSxFQUFPLHlCQUFQO1FBQ0EsV0FBQSxFQUFhLHVJQURiO1FBR0EsSUFBQSxFQUFNLFFBSE47UUFJQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLHlCQUpUO1FBS0EsS0FBQSxFQUFPLENBTFA7T0FESjtNQVFBLE1BQUEsRUFDSTtRQUFBLEtBQUEsRUFBTyxhQUFQO1FBQ0EsV0FBQSxFQUFhLG1HQURiO1FBR0EsSUFBQSxFQUFNLFFBSE47UUFJQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBSlQ7UUFLQSxLQUFBLEVBQU8sQ0FMUDtPQVRKO01BZ0JBLGFBQUEsRUFDSTtRQUFBLEtBQUEsRUFBTyxpQkFBUDtRQUNBLFdBQUEsRUFBYSw2S0FEYjtRQUdBLElBQUEsRUFBTSxPQUhOO1FBSUEsQ0FBQSxPQUFBLENBQUEsRUFBUyxDQUFDLHFCQUFELEVBQXdCLGNBQXhCLENBSlQ7UUFLQSxLQUFBLEVBQU8sQ0FMUDtPQWpCSjtNQXdCQSxhQUFBLEVBQ0k7UUFBQSxLQUFBLEVBQU8sZ0JBQVA7UUFDQSxXQUFBLEVBQWEsZ0tBRGI7UUFHQSxJQUFBLEVBQU0sT0FITjtRQUlBLENBQUEsT0FBQSxDQUFBLEVBQVMsQ0FBQyx1Q0FBRCxFQUEwQyx5QkFBMUMsQ0FKVDtRQUtBLEtBQUEsRUFBTyxDQUxQO09BekJKO01BZ0NBLDhCQUFBLEVBQ0k7UUFBQSxLQUFBLEVBQU8scUNBQVA7UUFDQSxXQUFBLEVBQWEsdVFBRGI7UUFJQSxJQUFBLEVBQU0sU0FKTjtRQUtBLENBQUEsT0FBQSxDQUFBLEVBQVMsS0FMVDtRQU1BLEtBQUEsRUFBTyxDQU5QO09BakNKO01BeUNBLGFBQUEsRUFDSTtRQUFBLEtBQUEsRUFBTyw4QkFBUDtRQUNBLFdBQUEsRUFBYSxrSkFEYjtRQUVBLElBQUEsRUFBTSxTQUZOO1FBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxLQUhUO1FBSUEsS0FBQSxFQUFPLENBSlA7T0ExQ0o7S0FESjtJQWlEQSxRQUFBLEVBQVUsU0FBQTtNQUNOLE1BQU0sQ0FBQyxVQUFQLENBQUE7TUFDQSxNQUFNLENBQUMsSUFBUCxDQUFBO01BRUEsSUFBQyxDQUFBLHFCQUFELEdBQTZCLElBQUEscUJBQUEsQ0FBQTtNQUM3QixJQUFDLENBQUEscUJBQXFCLENBQUMsSUFBdkIsQ0FBQTtNQUVBLElBQUMsQ0FBQSxXQUFELEdBQW1CLElBQUEsV0FBQSxDQUFBO01BQ25CLElBQUMsQ0FBQSxXQUFXLENBQUMsSUFBYixDQUFBO01BRUEsSUFBQyxDQUFBLGNBQUQsR0FBc0IsSUFBQSxjQUFBLENBQUE7TUFDdEIsSUFBQyxDQUFBLGNBQWMsQ0FBQyxJQUFoQixDQUFBO01BRUEsSUFBQyxDQUFBLGlCQUFELEdBQXlCLElBQUEsaUJBQUEsQ0FBQTtNQUN6QixJQUFDLENBQUEsaUJBQWlCLENBQUMsSUFBbkIsQ0FBQTthQUVBLEtBQUssQ0FBQyxJQUFOLENBQUE7SUFoQk0sQ0FqRFY7SUFtRUEsVUFBQSxFQUFZLFNBQUE7TUFDUixJQUFDLENBQUEsV0FBVyxDQUFDLFVBQWIsQ0FBQTtNQUNBLElBQUMsQ0FBQSxjQUFjLENBQUMsVUFBaEIsQ0FBQTtNQUNBLElBQUMsQ0FBQSxpQkFBaUIsQ0FBQyxVQUFuQixDQUFBO2FBQ0EsSUFBQyxDQUFBLHFCQUFxQixDQUFDLFVBQXZCLENBQUE7SUFKUSxDQW5FWjtJQXlFQSxnQkFBQSxFQUFrQixTQUFDLFNBQUQ7TUFDZCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsVUFBeEIsQ0FBbUMsU0FBbkM7YUFDQSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsTUFBeEIsQ0FBQTtJQUZjLENBekVsQjtJQTZFQSxhQUFBLEVBQWUsU0FBQyxNQUFEO2FBQ1gsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFoQixDQUFxQixNQUFyQjtJQURXLENBN0VmO0lBZ0ZBLHdCQUFBLEVBQTBCLFNBQUE7TUFDdEIsSUFBQyxDQUFBLFFBQUQsR0FDSTtRQUFBLEtBQUEsRUFBTyxLQUFQO1FBQ0EsTUFBQSxFQUFRLE1BRFI7O0FBR0osYUFBTyxJQUFDLENBQUE7SUFMYyxDQWhGMUI7SUF1RkEsV0FBQSxFQUFhLFNBQUE7QUFDVCxhQUFPLElBQUMsQ0FBQSxxQkFBcUIsQ0FBQyxZQUF2QixDQUFBO0lBREUsQ0F2RmI7O0FBWEoiLCJzb3VyY2VzQ29udGVudCI6WyJHb3RvTWFuYWdlciA9IHJlcXVpcmUgXCIuL2dvdG8vZ290by1tYW5hZ2VyLmNvZmZlZVwiXG5Ub29sdGlwTWFuYWdlciA9IHJlcXVpcmUgXCIuL3Rvb2x0aXAvdG9vbHRpcC1tYW5hZ2VyLmNvZmZlZVwiXG5Bbm5vdGF0aW9uTWFuYWdlciA9IHJlcXVpcmUgXCIuL2Fubm90YXRpb24vYW5ub3RhdGlvbi1tYW5hZ2VyLmNvZmZlZVwiXG5BdXRvY29tcGxldGlvbk1hbmFnZXIgPSByZXF1aXJlIFwiLi9hdXRvY29tcGxldGlvbi9hdXRvY29tcGxldGlvbi1tYW5hZ2VyLmNvZmZlZVwiXG5TdGF0dXNJblByb2dyZXNzID0gcmVxdWlyZSBcIi4vc2VydmljZXMvc3RhdHVzLWluLXByb2dyZXNzLmNvZmZlZVwiXG5jb25maWcgPSByZXF1aXJlICcuL2NvbmZpZy5jb2ZmZWUnXG5wcm94eSA9IHJlcXVpcmUgJy4vc2VydmljZXMvcGhwLXByb3h5LmNvZmZlZSdcbnBhcnNlciA9IHJlcXVpcmUgJy4vc2VydmljZXMvcGhwLWZpbGUtcGFyc2VyLmNvZmZlZSdcbnBsdWdpbnMgPSByZXF1aXJlICcuL3NlcnZpY2VzL3BsdWdpbi1tYW5hZ2VyLmNvZmZlZSdcblxubW9kdWxlLmV4cG9ydHMgPVxuICAgIGNvbmZpZzpcbiAgICAgICAgYmluQ29tcG9zZXI6XG4gICAgICAgICAgICB0aXRsZTogJ0NvbW1hbmQgdG8gdXNlIGNvbXBvc2VyJ1xuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdUaGlzIHBsdWdpbiBkZXBlbmRzIG9uIGNvbXBvc2VyIGluIG9yZGVyIHRvIHdvcmsuIFNwZWNpZnkgdGhlIHBhdGhcbiAgICAgICAgICAgICB0byB5b3VyIGNvbXBvc2VyIGJpbiAoZS5nIDogYmluL2NvbXBvc2VyLCBjb21wb3Nlci5waGFyLCBjb21wb3NlciknXG4gICAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgICAgZGVmYXVsdDogJy91c3IvbG9jYWwvYmluL2NvbXBvc2VyJ1xuICAgICAgICAgICAgb3JkZXI6IDFcblxuICAgICAgICBiaW5QaHA6XG4gICAgICAgICAgICB0aXRsZTogJ0NvbW1hbmQgcGhwJ1xuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdUaGlzIHBsdWdpbiB1c2UgcGhwIENMSSBpbiBvcmRlciB0byB3b3JrLiBQbGVhc2Ugc3BlY2lmeSB5b3VyIHBocFxuICAgICAgICAgICAgIGNvbW1hbmQgKFwicGhwXCIgb24gVU5JWCBzeXN0ZW1zKSdcbiAgICAgICAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICAgICAgICBkZWZhdWx0OiAncGhwJ1xuICAgICAgICAgICAgb3JkZXI6IDJcblxuICAgICAgICBhdXRvbG9hZFBhdGhzOlxuICAgICAgICAgICAgdGl0bGU6ICdBdXRvbG9hZGVyIGZpbGUnXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1JlbGF0aXZlIHBhdGggdG8gdGhlIGZpbGVzIG9mIGF1dG9sb2FkLnBocCBmcm9tIGNvbXBvc2VyIChvciBhbiBvdGhlciBvbmUpLiBZb3UgY2FuIHNwZWNpZnkgbXVsdGlwbGVcbiAgICAgICAgICAgICBwYXRocyAoY29tbWEgc2VwYXJhdGVkKSBpZiB5b3UgaGF2ZSBkaWZmZXJlbnQgcGF0aHMgZm9yIHNvbWUgcHJvamVjdHMuJ1xuICAgICAgICAgICAgdHlwZTogJ2FycmF5J1xuICAgICAgICAgICAgZGVmYXVsdDogWyd2ZW5kb3IvYXV0b2xvYWQucGhwJywgJ2F1dG9sb2FkLnBocCddXG4gICAgICAgICAgICBvcmRlcjogM1xuXG4gICAgICAgIGNsYXNzTWFwRmlsZXM6XG4gICAgICAgICAgICB0aXRsZTogJ0NsYXNzbWFwIGZpbGVzJ1xuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdSZWxhdGl2ZSBwYXRoIHRvIHRoZSBmaWxlcyB0aGF0IGNvbnRhaW5zIGEgY2xhc3NtYXAgKGFycmF5IHdpdGggXCJjbGFzc05hbWVcIiA9PiBcImZpbGVOYW1lXCIpLiBCeSBkZWZhdWx0XG4gICAgICAgICAgICAgb24gY29tcG9zZXIgaXRcXCdzIHZlbmRvci9jb21wb3Nlci9hdXRvbG9hZF9jbGFzc21hcC5waHAnXG4gICAgICAgICAgICB0eXBlOiAnYXJyYXknXG4gICAgICAgICAgICBkZWZhdWx0OiBbJ3ZlbmRvci9jb21wb3Nlci9hdXRvbG9hZF9jbGFzc21hcC5waHAnLCAnYXV0b2xvYWQvZXpwX2tlcm5lbC5waHAnXVxuICAgICAgICAgICAgb3JkZXI6IDRcblxuICAgICAgICBpbnNlcnROZXdsaW5lc0ZvclVzZVN0YXRlbWVudHM6XG4gICAgICAgICAgICB0aXRsZTogJ0luc2VydCBuZXdsaW5lcyBmb3IgdXNlIHN0YXRlbWVudHMuJ1xuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdXaGVuIGVuYWJsZWQsIHRoZSBwbHVnaW4gd2lsbCBhZGQgYWRkaXRpb25hbCBuZXdsaW5lcyBiZWZvcmUgb3IgYWZ0ZXIgYW4gYXV0b21hdGljYWxseSBhZGRlZFxuICAgICAgICAgICAgICAgIHVzZSBzdGF0ZW1lbnQgd2hlbiBpdCBjYW5cXCd0IGFkZCB0aGVtIG5pY2VseSB0byBhbiBleGlzdGluZyBncm91cC4gVGhpcyByZXN1bHRzIGluIG1vcmUgY2xlYW5seVxuICAgICAgICAgICAgICAgIHNlcGFyYXRlZCB1c2Ugc3RhdGVtZW50cyBidXQgd2lsbCBjcmVhdGUgYWRkaXRpb25hbCB2ZXJ0aWNhbCB3aGl0ZXNwYWNlLidcbiAgICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICAgICAgICAgIG9yZGVyOiA1XG5cbiAgICAgICAgdmVyYm9zZUVycm9yczpcbiAgICAgICAgICAgIHRpdGxlOiAnRXJyb3JzIG9uIGZpbGUgc2F2aW5nIHNob3dlZCdcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnV2hlbiBlbmFibGVkLCB5b3VcXCdsbCBoYXZlIGEgbm90aWZpY2F0aW9uIG9uY2UgYW4gZXJyb3Igb2NjdXJlZCBvbiBhdXRvY29tcGxldGUuIE90aGVyd2lzZSwgdGhlIG1lc3NhZ2Ugd2lsbCBqdXN0IGJlIGxvZ2dlZCBpbiBkZXZlbG9wZXIgY29uc29sZSdcbiAgICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICAgICAgICAgIG9yZGVyOiA2XG5cbiAgICBhY3RpdmF0ZTogLT5cbiAgICAgICAgY29uZmlnLnRlc3RDb25maWcoKVxuICAgICAgICBjb25maWcuaW5pdCgpXG5cbiAgICAgICAgQGF1dG9jb21wbGV0aW9uTWFuYWdlciA9IG5ldyBBdXRvY29tcGxldGlvbk1hbmFnZXIoKVxuICAgICAgICBAYXV0b2NvbXBsZXRpb25NYW5hZ2VyLmluaXQoKVxuXG4gICAgICAgIEBnb3RvTWFuYWdlciA9IG5ldyBHb3RvTWFuYWdlcigpXG4gICAgICAgIEBnb3RvTWFuYWdlci5pbml0KClcblxuICAgICAgICBAdG9vbHRpcE1hbmFnZXIgPSBuZXcgVG9vbHRpcE1hbmFnZXIoKVxuICAgICAgICBAdG9vbHRpcE1hbmFnZXIuaW5pdCgpXG5cbiAgICAgICAgQGFubm90YXRpb25NYW5hZ2VyID0gbmV3IEFubm90YXRpb25NYW5hZ2VyKClcbiAgICAgICAgQGFubm90YXRpb25NYW5hZ2VyLmluaXQoKVxuXG4gICAgICAgIHByb3h5LmluaXQoKVxuXG4gICAgZGVhY3RpdmF0ZTogLT5cbiAgICAgICAgQGdvdG9NYW5hZ2VyLmRlYWN0aXZhdGUoKVxuICAgICAgICBAdG9vbHRpcE1hbmFnZXIuZGVhY3RpdmF0ZSgpXG4gICAgICAgIEBhbm5vdGF0aW9uTWFuYWdlci5kZWFjdGl2YXRlKClcbiAgICAgICAgQGF1dG9jb21wbGV0aW9uTWFuYWdlci5kZWFjdGl2YXRlKClcblxuICAgIGNvbnN1bWVTdGF0dXNCYXI6IChzdGF0dXNCYXIpIC0+XG4gICAgICAgIGNvbmZpZy5zdGF0dXNJblByb2dyZXNzLmluaXRpYWxpemUoc3RhdHVzQmFyKVxuICAgICAgICBjb25maWcuc3RhdHVzSW5Qcm9ncmVzcy5hdHRhY2goKVxuXG4gICAgY29uc3VtZVBsdWdpbjogKHBsdWdpbikgLT5cbiAgICAgICAgcGx1Z2lucy5wbHVnaW5zLnB1c2gocGx1Z2luKVxuXG4gICAgcHJvdmlkZUF1dG9jb21wbGV0ZVRvb2xzOiAtPlxuICAgICAgICBAc2VydmljZXMgPVxuICAgICAgICAgICAgcHJveHk6IHByb3h5XG4gICAgICAgICAgICBwYXJzZXI6IHBhcnNlclxuXG4gICAgICAgIHJldHVybiBAc2VydmljZXNcblxuICAgIGdldFByb3ZpZGVyOiAtPlxuICAgICAgICByZXR1cm4gQGF1dG9jb21wbGV0aW9uTWFuYWdlci5nZXRQcm92aWRlcnMoKVxuIl19
