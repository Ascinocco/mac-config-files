(function() {
  var AbstractProvider, AttachedPopover, Point, Range, SubAtom, TextEditor, ref;

  ref = require('atom'), Range = ref.Range, Point = ref.Point, TextEditor = ref.TextEditor;

  SubAtom = require('sub-atom');

  AttachedPopover = require('../services/attached-popover');

  module.exports = AbstractProvider = (function() {
    function AbstractProvider() {}

    AbstractProvider.prototype.regex = null;

    AbstractProvider.prototype.markers = [];

    AbstractProvider.prototype.subAtoms = [];


    /**
     * Initializes this provider.
     */

    AbstractProvider.prototype.init = function() {
      this.$ = require('jquery');
      this.parser = require('../services/php-file-parser');
      atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          editor.onDidSave(function(event) {
            return _this.rescan(editor);
          });
          _this.registerAnnotations(editor);
          return _this.registerEvents(editor);
        };
      })(this));
      atom.workspace.onDidDestroyPane((function(_this) {
        return function(pane) {
          var j, len, paneItem, panes, ref1, results;
          panes = atom.workspace.getPanes();
          if (panes.length === 1) {
            ref1 = panes[0].items;
            results = [];
            for (j = 0, len = ref1.length; j < len; j++) {
              paneItem = ref1[j];
              if (paneItem instanceof TextEditor) {
                results.push(_this.registerEvents(paneItem));
              } else {
                results.push(void 0);
              }
            }
            return results;
          }
        };
      })(this));
      return atom.workspace.onDidAddPane((function(_this) {
        return function(observedPane) {
          var j, len, pane, paneItem, panes, results;
          panes = atom.workspace.getPanes();
          results = [];
          for (j = 0, len = panes.length; j < len; j++) {
            pane = panes[j];
            if (pane === observedPane) {
              continue;
            }
            results.push((function() {
              var k, len1, ref1, results1;
              ref1 = pane.items;
              results1 = [];
              for (k = 0, len1 = ref1.length; k < len1; k++) {
                paneItem = ref1[k];
                if (paneItem instanceof TextEditor) {
                  results1.push(this.registerEvents(paneItem));
                } else {
                  results1.push(void 0);
                }
              }
              return results1;
            }).call(_this));
          }
          return results;
        };
      })(this));
    };


    /**
     * Deactives the provider.
     */

    AbstractProvider.prototype.deactivate = function() {
      return this.removeAnnotations();
    };


    /**
     * Registers event handlers.
     *
     * @param {TextEditor} editor TextEditor to register events to.
     */

    AbstractProvider.prototype.registerEvents = function(editor) {
      var textEditorElement;
      if (editor.getGrammar().scopeName.match(/text.html.php$/)) {
        editor.onDidDestroy((function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        editor.onDidStopChanging((function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        textEditorElement = atom.views.getView(editor);
        this.$(textEditorElement.shadowRoot).find('.horizontal-scrollbar').on('scroll', (function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
        return this.$(textEditorElement.shadowRoot).find('.vertical-scrollbar').on('scroll', (function(_this) {
          return function() {
            return _this.removePopover();
          };
        })(this));
      }
    };


    /**
     * Registers the annotations.
     *
     * @param {TextEditor} editor The editor to search through.
     */

    AbstractProvider.prototype.registerAnnotations = function(editor) {
      var match, results, row, rowNum, rows, text;
      text = editor.getText();
      rows = text.split('\n');
      this.subAtoms[editor.getLongTitle()] = new SubAtom;
      results = [];
      for (rowNum in rows) {
        row = rows[rowNum];
        results.push((function() {
          var results1;
          results1 = [];
          while ((match = this.regex.exec(row))) {
            results1.push(this.placeAnnotation(editor, rowNum, row, match));
          }
          return results1;
        }).call(this));
      }
      return results;
    };


    /**
     * Places an annotation at the specified line and row text.
     *
     * @param {TextEditor} editor
     * @param {int}        row
     * @param {String}     rowText
     * @param {Array}      match
     */

    AbstractProvider.prototype.placeAnnotation = function(editor, row, rowText, match) {
      var annotationInfo, decoration, longTitle, marker, markerLayer, range;
      annotationInfo = this.extractAnnotationInfo(editor, row, rowText, match);
      if (!annotationInfo) {
        return;
      }
      range = new Range(new Point(parseInt(row), 0), new Point(parseInt(row), rowText.length));
      if (typeof editor.addMarkerLayer === 'function') {
        if (this.markerLayers == null) {
          this.markerLayers = new WeakMap;
        }
        if (!(markerLayer = this.markerLayers.get(editor))) {
          markerLayer = editor.addMarkerLayer({
            maintainHistory: true
          });
          this.markerLayers.set(editor, markerLayer);
        }
      }
      marker = (markerLayer != null ? markerLayer : editor).markBufferRange(range, {
        maintainHistory: true,
        invalidate: 'touch'
      });
      decoration = editor.decorateMarker(marker, {
        type: 'line-number',
        "class": annotationInfo.lineNumberClass
      });
      longTitle = editor.getLongTitle();
      if (this.markers[longTitle] === void 0) {
        this.markers[longTitle] = [];
      }
      this.markers[longTitle].push(marker);
      return this.registerAnnotationEventHandlers(editor, row, annotationInfo);
    };


    /**
     * Exracts information about the annotation match.
     *
     * @param {TextEditor} editor
     * @param {int}        row
     * @param {String}     rowText
     * @param {Array}      match
     */

    AbstractProvider.prototype.extractAnnotationInfo = function(editor, row, rowText, match) {};


    /**
     * Registers annotation event handlers for the specified row.
     *
     * @param {TextEditor} editor
     * @param {int}        row
     * @param {Object}     annotationInfo
     */

    AbstractProvider.prototype.registerAnnotationEventHandlers = function(editor, row, annotationInfo) {
      var gutterContainerElement, textEditorElement;
      textEditorElement = atom.views.getView(editor);
      gutterContainerElement = this.$(textEditorElement.shadowRoot).find('.gutter-container');
      return (function(_this) {
        return function(editor, gutterContainerElement, annotationInfo) {
          var longTitle, selector;
          longTitle = editor.getLongTitle();
          selector = '.line-number' + '.' + annotationInfo.lineNumberClass + '[data-buffer-row=' + row + '] .icon-right';
          _this.subAtoms[longTitle].add(gutterContainerElement, 'mouseover', selector, function(event) {
            return _this.handleMouseOver(event, editor, annotationInfo);
          });
          _this.subAtoms[longTitle].add(gutterContainerElement, 'mouseout', selector, function(event) {
            return _this.handleMouseOut(event, editor, annotationInfo);
          });
          return _this.subAtoms[longTitle].add(gutterContainerElement, 'click', selector, function(event) {
            return _this.handleMouseClick(event, editor, annotationInfo);
          });
        };
      })(this)(editor, gutterContainerElement, annotationInfo);
    };


    /**
     * Handles the mouse over event on an annotation.
     *
     * @param {jQuery.Event} event
     * @param {TextEditor}   editor
     * @param {Object}       annotationInfo
     */

    AbstractProvider.prototype.handleMouseOver = function(event, editor, annotationInfo) {
      if (annotationInfo.tooltipText) {
        this.removePopover();
        this.attachedPopover = new AttachedPopover(event.target);
        this.attachedPopover.setText(annotationInfo.tooltipText);
        return this.attachedPopover.show();
      }
    };


    /**
     * Handles the mouse out event on an annotation.
     *
     * @param {jQuery.Event} event
     * @param {TextEditor}   editor
     * @param {Object}       annotationInfo
     */

    AbstractProvider.prototype.handleMouseOut = function(event, editor, annotationInfo) {
      return this.removePopover();
    };


    /**
     * Handles the mouse click event on an annotation.
     *
     * @param {jQuery.Event} event
     * @param {TextEditor}   editor
     * @param {Object}       annotationInfo
     */

    AbstractProvider.prototype.handleMouseClick = function(event, editor, annotationInfo) {};


    /**
     * Removes the existing popover, if any.
     */

    AbstractProvider.prototype.removePopover = function() {
      if (this.attachedPopover) {
        this.attachedPopover.dispose();
        return this.attachedPopover = null;
      }
    };


    /**
     * Removes any annotations that were created.
     *
     * @param {TextEditor} editor The editor to search through.
     */

    AbstractProvider.prototype.removeAnnotations = function(editor) {
      var i, marker, ref1, ref2;
      ref1 = this.markers[editor.getLongTitle()];
      for (i in ref1) {
        marker = ref1[i];
        marker.destroy();
      }
      this.markers[editor.getLongTitle()] = [];
      return (ref2 = this.subAtoms[editor.getLongTitle()]) != null ? ref2.dispose() : void 0;
    };


    /**
     * Rescans the editor, updating all annotations.
     *
     * @param {TextEditor} editor The editor to search through.
     */

    AbstractProvider.prototype.rescan = function(editor) {
      this.removeAnnotations(editor);
      return this.registerAnnotations(editor);
    };

    return AbstractProvider;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9hbm5vdGF0aW9uL2Fic3RyYWN0LXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsTUFBNkIsT0FBQSxDQUFRLE1BQVIsQ0FBN0IsRUFBQyxpQkFBRCxFQUFRLGlCQUFSLEVBQWU7O0VBRWYsT0FBQSxHQUFVLE9BQUEsQ0FBUSxVQUFSOztFQUVWLGVBQUEsR0FBa0IsT0FBQSxDQUFRLDhCQUFSOztFQUVsQixNQUFNLENBQUMsT0FBUCxHQUVNOzs7K0JBRUYsS0FBQSxHQUFPOzsrQkFDUCxPQUFBLEdBQVM7OytCQUNULFFBQUEsR0FBVTs7O0FBRVY7Ozs7K0JBR0EsSUFBQSxHQUFNLFNBQUE7TUFDRixJQUFDLENBQUEsQ0FBRCxHQUFLLE9BQUEsQ0FBUSxRQUFSO01BQ0wsSUFBQyxDQUFBLE1BQUQsR0FBVSxPQUFBLENBQVEsNkJBQVI7TUFFVixJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFmLENBQWtDLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxNQUFEO1VBQzlCLE1BQU0sQ0FBQyxTQUFQLENBQWlCLFNBQUMsS0FBRDttQkFDYixLQUFDLENBQUEsTUFBRCxDQUFRLE1BQVI7VUFEYSxDQUFqQjtVQUdBLEtBQUMsQ0FBQSxtQkFBRCxDQUFxQixNQUFyQjtpQkFDQSxLQUFDLENBQUEsY0FBRCxDQUFnQixNQUFoQjtRQUw4QjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEM7TUFRQSxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFmLENBQWdDLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxJQUFEO0FBQzVCLGNBQUE7VUFBQSxLQUFBLEdBQVEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFmLENBQUE7VUFFUixJQUFHLEtBQUssQ0FBQyxNQUFOLEtBQWdCLENBQW5CO0FBQ0k7QUFBQTtpQkFBQSxzQ0FBQTs7Y0FDSSxJQUFHLFFBQUEsWUFBb0IsVUFBdkI7NkJBQ0ksS0FBQyxDQUFBLGNBQUQsQ0FBZ0IsUUFBaEIsR0FESjtlQUFBLE1BQUE7cUNBQUE7O0FBREo7MkJBREo7O1FBSDRCO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQzthQVNBLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBZixDQUE0QixDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsWUFBRDtBQUN4QixjQUFBO1VBQUEsS0FBQSxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBZixDQUFBO0FBRVI7ZUFBQSx1Q0FBQTs7WUFDSSxJQUFHLElBQUEsS0FBUSxZQUFYO0FBQ0ksdUJBREo7Ozs7QUFHQTtBQUFBO21CQUFBLHdDQUFBOztnQkFDSSxJQUFHLFFBQUEsWUFBb0IsVUFBdkI7Z0NBQ0ksSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsUUFBaEIsR0FESjtpQkFBQSxNQUFBO3dDQUFBOztBQURKOzs7QUFKSjs7UUFId0I7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTVCO0lBckJFOzs7QUFnQ047Ozs7K0JBR0EsVUFBQSxHQUFZLFNBQUE7YUFDUixJQUFDLENBQUEsaUJBQUQsQ0FBQTtJQURROzs7QUFHWjs7Ozs7OytCQUtBLGNBQUEsR0FBZ0IsU0FBQyxNQUFEO0FBQ1osVUFBQTtNQUFBLElBQUcsTUFBTSxDQUFDLFVBQVAsQ0FBQSxDQUFtQixDQUFDLFNBQVMsQ0FBQyxLQUE5QixDQUFvQyxnQkFBcEMsQ0FBSDtRQUlJLE1BQU0sQ0FBQyxZQUFQLENBQW9CLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUE7bUJBQ2hCLEtBQUMsQ0FBQSxhQUFELENBQUE7VUFEZ0I7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXBCO1FBR0EsTUFBTSxDQUFDLGlCQUFQLENBQXlCLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUE7bUJBQ3JCLEtBQUMsQ0FBQSxhQUFELENBQUE7VUFEcUI7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpCO1FBR0EsaUJBQUEsR0FBb0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLE1BQW5CO1FBRXBCLElBQUMsQ0FBQSxDQUFELENBQUcsaUJBQWlCLENBQUMsVUFBckIsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyx1QkFBdEMsQ0FBOEQsQ0FBQyxFQUEvRCxDQUFrRSxRQUFsRSxFQUE0RSxDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUN4RSxLQUFDLENBQUEsYUFBRCxDQUFBO1VBRHdFO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE1RTtlQUdBLElBQUMsQ0FBQSxDQUFELENBQUcsaUJBQWlCLENBQUMsVUFBckIsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxxQkFBdEMsQ0FBNEQsQ0FBQyxFQUE3RCxDQUFnRSxRQUFoRSxFQUEwRSxDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUN0RSxLQUFDLENBQUEsYUFBRCxDQUFBO1VBRHNFO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUExRSxFQWZKOztJQURZOzs7QUFtQmhCOzs7Ozs7K0JBS0EsbUJBQUEsR0FBcUIsU0FBQyxNQUFEO0FBQ2pCLFVBQUE7TUFBQSxJQUFBLEdBQU8sTUFBTSxDQUFDLE9BQVAsQ0FBQTtNQUNQLElBQUEsR0FBTyxJQUFJLENBQUMsS0FBTCxDQUFXLElBQVg7TUFDUCxJQUFDLENBQUEsUUFBUyxDQUFBLE1BQU0sQ0FBQyxZQUFQLENBQUEsQ0FBQSxDQUFWLEdBQW1DLElBQUk7QUFFdkM7V0FBQSxjQUFBOzs7O0FBQ0k7aUJBQU0sQ0FBQyxLQUFBLEdBQVEsSUFBQyxDQUFBLEtBQUssQ0FBQyxJQUFQLENBQVksR0FBWixDQUFULENBQU47MEJBQ0ksSUFBQyxDQUFBLGVBQUQsQ0FBaUIsTUFBakIsRUFBeUIsTUFBekIsRUFBaUMsR0FBakMsRUFBc0MsS0FBdEM7VUFESixDQUFBOzs7QUFESjs7SUFMaUI7OztBQVNyQjs7Ozs7Ozs7OytCQVFBLGVBQUEsR0FBaUIsU0FBQyxNQUFELEVBQVMsR0FBVCxFQUFjLE9BQWQsRUFBdUIsS0FBdkI7QUFDYixVQUFBO01BQUEsY0FBQSxHQUFpQixJQUFDLENBQUEscUJBQUQsQ0FBdUIsTUFBdkIsRUFBK0IsR0FBL0IsRUFBb0MsT0FBcEMsRUFBNkMsS0FBN0M7TUFFakIsSUFBRyxDQUFJLGNBQVA7QUFDSSxlQURKOztNQUdBLEtBQUEsR0FBWSxJQUFBLEtBQUEsQ0FDSixJQUFBLEtBQUEsQ0FBTSxRQUFBLENBQVMsR0FBVCxDQUFOLEVBQXFCLENBQXJCLENBREksRUFFSixJQUFBLEtBQUEsQ0FBTSxRQUFBLENBQVMsR0FBVCxDQUFOLEVBQXFCLE9BQU8sQ0FBQyxNQUE3QixDQUZJO01BUVosSUFBRyxPQUFPLE1BQU0sQ0FBQyxjQUFkLEtBQWdDLFVBQW5DOztVQUNJLElBQUMsQ0FBQSxlQUFnQixJQUFJOztRQUNyQixJQUFBLENBQU8sQ0FBQSxXQUFBLEdBQWMsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQWtCLE1BQWxCLENBQWQsQ0FBUDtVQUNJLFdBQUEsR0FBYyxNQUFNLENBQUMsY0FBUCxDQUFzQjtZQUFBLGVBQUEsRUFBaUIsSUFBakI7V0FBdEI7VUFDZCxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBa0IsTUFBbEIsRUFBMEIsV0FBMUIsRUFGSjtTQUZKOztNQU1BLE1BQUEsR0FBUyx1QkFBQyxjQUFjLE1BQWYsQ0FBc0IsQ0FBQyxlQUF2QixDQUF1QyxLQUF2QyxFQUE4QztRQUNuRCxlQUFBLEVBQWtCLElBRGlDO1FBRW5ELFVBQUEsRUFBa0IsT0FGaUM7T0FBOUM7TUFLVCxVQUFBLEdBQWEsTUFBTSxDQUFDLGNBQVAsQ0FBc0IsTUFBdEIsRUFBOEI7UUFDdkMsSUFBQSxFQUFNLGFBRGlDO1FBRXZDLENBQUEsS0FBQSxDQUFBLEVBQU8sY0FBYyxDQUFDLGVBRmlCO09BQTlCO01BS2IsU0FBQSxHQUFZLE1BQU0sQ0FBQyxZQUFQLENBQUE7TUFFWixJQUFHLElBQUMsQ0FBQSxPQUFRLENBQUEsU0FBQSxDQUFULEtBQXVCLE1BQTFCO1FBQ0ksSUFBQyxDQUFBLE9BQVEsQ0FBQSxTQUFBLENBQVQsR0FBc0IsR0FEMUI7O01BR0EsSUFBQyxDQUFBLE9BQVEsQ0FBQSxTQUFBLENBQVUsQ0FBQyxJQUFwQixDQUF5QixNQUF6QjthQUVBLElBQUMsQ0FBQSwrQkFBRCxDQUFpQyxNQUFqQyxFQUF5QyxHQUF6QyxFQUE4QyxjQUE5QztJQXJDYTs7O0FBdUNqQjs7Ozs7Ozs7OytCQVFBLHFCQUFBLEdBQXVCLFNBQUMsTUFBRCxFQUFTLEdBQVQsRUFBYyxPQUFkLEVBQXVCLEtBQXZCLEdBQUE7OztBQUV2Qjs7Ozs7Ozs7K0JBT0EsK0JBQUEsR0FBaUMsU0FBQyxNQUFELEVBQVMsR0FBVCxFQUFjLGNBQWQ7QUFDN0IsVUFBQTtNQUFBLGlCQUFBLEdBQW9CLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWCxDQUFtQixNQUFuQjtNQUNwQixzQkFBQSxHQUF5QixJQUFDLENBQUEsQ0FBRCxDQUFHLGlCQUFpQixDQUFDLFVBQXJCLENBQWdDLENBQUMsSUFBakMsQ0FBc0MsbUJBQXRDO2FBRXRCLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxNQUFELEVBQVMsc0JBQVQsRUFBaUMsY0FBakM7QUFDQyxjQUFBO1VBQUEsU0FBQSxHQUFZLE1BQU0sQ0FBQyxZQUFQLENBQUE7VUFDWixRQUFBLEdBQVcsY0FBQSxHQUFpQixHQUFqQixHQUF1QixjQUFjLENBQUMsZUFBdEMsR0FBd0QsbUJBQXhELEdBQThFLEdBQTlFLEdBQW9GO1VBRS9GLEtBQUMsQ0FBQSxRQUFTLENBQUEsU0FBQSxDQUFVLENBQUMsR0FBckIsQ0FBeUIsc0JBQXpCLEVBQWlELFdBQWpELEVBQThELFFBQTlELEVBQXdFLFNBQUMsS0FBRDttQkFDcEUsS0FBQyxDQUFBLGVBQUQsQ0FBaUIsS0FBakIsRUFBd0IsTUFBeEIsRUFBZ0MsY0FBaEM7VUFEb0UsQ0FBeEU7VUFHQSxLQUFDLENBQUEsUUFBUyxDQUFBLFNBQUEsQ0FBVSxDQUFDLEdBQXJCLENBQXlCLHNCQUF6QixFQUFpRCxVQUFqRCxFQUE2RCxRQUE3RCxFQUF1RSxTQUFDLEtBQUQ7bUJBQ25FLEtBQUMsQ0FBQSxjQUFELENBQWdCLEtBQWhCLEVBQXVCLE1BQXZCLEVBQStCLGNBQS9CO1VBRG1FLENBQXZFO2lCQUdBLEtBQUMsQ0FBQSxRQUFTLENBQUEsU0FBQSxDQUFVLENBQUMsR0FBckIsQ0FBeUIsc0JBQXpCLEVBQWlELE9BQWpELEVBQTBELFFBQTFELEVBQW9FLFNBQUMsS0FBRDttQkFDaEUsS0FBQyxDQUFBLGdCQUFELENBQWtCLEtBQWxCLEVBQXlCLE1BQXpCLEVBQWlDLGNBQWpDO1VBRGdFLENBQXBFO1FBVkQ7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQUgsQ0FBSSxNQUFKLEVBQVksc0JBQVosRUFBb0MsY0FBcEM7SUFKNkI7OztBQWlCakM7Ozs7Ozs7OytCQU9BLGVBQUEsR0FBaUIsU0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixjQUFoQjtNQUNiLElBQUcsY0FBYyxDQUFDLFdBQWxCO1FBQ0ksSUFBQyxDQUFBLGFBQUQsQ0FBQTtRQUVBLElBQUMsQ0FBQSxlQUFELEdBQXVCLElBQUEsZUFBQSxDQUFnQixLQUFLLENBQUMsTUFBdEI7UUFDdkIsSUFBQyxDQUFBLGVBQWUsQ0FBQyxPQUFqQixDQUF5QixjQUFjLENBQUMsV0FBeEM7ZUFDQSxJQUFDLENBQUEsZUFBZSxDQUFDLElBQWpCLENBQUEsRUFMSjs7SUFEYTs7O0FBUWpCOzs7Ozs7OzsrQkFPQSxjQUFBLEdBQWdCLFNBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsY0FBaEI7YUFDWixJQUFDLENBQUEsYUFBRCxDQUFBO0lBRFk7OztBQUdoQjs7Ozs7Ozs7K0JBT0EsZ0JBQUEsR0FBa0IsU0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixjQUFoQixHQUFBOzs7QUFFbEI7Ozs7K0JBR0EsYUFBQSxHQUFlLFNBQUE7TUFDWCxJQUFHLElBQUMsQ0FBQSxlQUFKO1FBQ0ksSUFBQyxDQUFBLGVBQWUsQ0FBQyxPQUFqQixDQUFBO2VBQ0EsSUFBQyxDQUFBLGVBQUQsR0FBbUIsS0FGdkI7O0lBRFc7OztBQUtmOzs7Ozs7K0JBS0EsaUJBQUEsR0FBbUIsU0FBQyxNQUFEO0FBQ2YsVUFBQTtBQUFBO0FBQUEsV0FBQSxTQUFBOztRQUNJLE1BQU0sQ0FBQyxPQUFQLENBQUE7QUFESjtNQUdBLElBQUMsQ0FBQSxPQUFRLENBQUEsTUFBTSxDQUFDLFlBQVAsQ0FBQSxDQUFBLENBQVQsR0FBa0M7eUVBQ0YsQ0FBRSxPQUFsQyxDQUFBO0lBTGU7OztBQU9uQjs7Ozs7OytCQUtBLE1BQUEsR0FBUSxTQUFDLE1BQUQ7TUFDSixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsTUFBbkI7YUFDQSxJQUFDLENBQUEsbUJBQUQsQ0FBcUIsTUFBckI7SUFGSTs7Ozs7QUF6T1oiLCJzb3VyY2VzQ29udGVudCI6WyJ7UmFuZ2UsIFBvaW50LCBUZXh0RWRpdG9yfSA9IHJlcXVpcmUgJ2F0b20nXG5cblN1YkF0b20gPSByZXF1aXJlICdzdWItYXRvbSdcblxuQXR0YWNoZWRQb3BvdmVyID0gcmVxdWlyZSAnLi4vc2VydmljZXMvYXR0YWNoZWQtcG9wb3ZlcidcblxubW9kdWxlLmV4cG9ydHMgPVxuXG5jbGFzcyBBYnN0cmFjdFByb3ZpZGVyXG4gICAgIyBUaGUgcmVndWxhciBleHByZXNzaW9uIHRoYXQgYSBsaW5lIG11c3QgbWF0Y2ggaW4gb3JkZXIgZm9yIGl0IHRvIGJlIGNoZWNrZWQgaWYgaXQgcmVxdWlyZXMgYW4gYW5ub3RhdGlvbi5cbiAgICByZWdleDogbnVsbFxuICAgIG1hcmtlcnM6IFtdXG4gICAgc3ViQXRvbXM6IFtdXG5cbiAgICAjIyMqXG4gICAgICogSW5pdGlhbGl6ZXMgdGhpcyBwcm92aWRlci5cbiAgICAjIyNcbiAgICBpbml0OiAoKSAtPlxuICAgICAgICBAJCA9IHJlcXVpcmUgJ2pxdWVyeSdcbiAgICAgICAgQHBhcnNlciA9IHJlcXVpcmUgJy4uL3NlcnZpY2VzL3BocC1maWxlLXBhcnNlcidcblxuICAgICAgICBhdG9tLndvcmtzcGFjZS5vYnNlcnZlVGV4dEVkaXRvcnMgKGVkaXRvcikgPT5cbiAgICAgICAgICAgIGVkaXRvci5vbkRpZFNhdmUgKGV2ZW50KSA9PlxuICAgICAgICAgICAgICAgIEByZXNjYW4oZWRpdG9yKVxuXG4gICAgICAgICAgICBAcmVnaXN0ZXJBbm5vdGF0aW9ucyBlZGl0b3JcbiAgICAgICAgICAgIEByZWdpc3RlckV2ZW50cyBlZGl0b3JcblxuICAgICAgICAjIFdoZW4geW91IGdvIGJhY2sgdG8gb25seSBoYXZlIDEgcGFuZSB0aGUgZXZlbnRzIGFyZSBsb3N0LCBzbyBuZWVkIHRvIHJlLXJlZ2lzdGVyLlxuICAgICAgICBhdG9tLndvcmtzcGFjZS5vbkRpZERlc3Ryb3lQYW5lIChwYW5lKSA9PlxuICAgICAgICAgICAgcGFuZXMgPSBhdG9tLndvcmtzcGFjZS5nZXRQYW5lcygpXG5cbiAgICAgICAgICAgIGlmIHBhbmVzLmxlbmd0aCA9PSAxXG4gICAgICAgICAgICAgICAgZm9yIHBhbmVJdGVtIGluIHBhbmVzWzBdLml0ZW1zXG4gICAgICAgICAgICAgICAgICAgIGlmIHBhbmVJdGVtIGluc3RhbmNlb2YgVGV4dEVkaXRvclxuICAgICAgICAgICAgICAgICAgICAgICAgQHJlZ2lzdGVyRXZlbnRzIHBhbmVJdGVtXG5cbiAgICAgICAgIyBIYXZpbmcgdG8gcmUtcmVnaXN0ZXIgZXZlbnRzIGFzIHdoZW4gYSBuZXcgcGFuZSBpcyBjcmVhdGVkIHRoZSBvbGQgcGFuZXMgbG9zZSB0aGUgZXZlbnRzLlxuICAgICAgICBhdG9tLndvcmtzcGFjZS5vbkRpZEFkZFBhbmUgKG9ic2VydmVkUGFuZSkgPT5cbiAgICAgICAgICAgIHBhbmVzID0gYXRvbS53b3Jrc3BhY2UuZ2V0UGFuZXMoKVxuXG4gICAgICAgICAgICBmb3IgcGFuZSBpbiBwYW5lc1xuICAgICAgICAgICAgICAgIGlmIHBhbmUgPT0gb2JzZXJ2ZWRQYW5lXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlXG5cbiAgICAgICAgICAgICAgICBmb3IgcGFuZUl0ZW0gaW4gcGFuZS5pdGVtc1xuICAgICAgICAgICAgICAgICAgICBpZiBwYW5lSXRlbSBpbnN0YW5jZW9mIFRleHRFZGl0b3JcbiAgICAgICAgICAgICAgICAgICAgICAgIEByZWdpc3RlckV2ZW50cyBwYW5lSXRlbVxuXG4gICAgIyMjKlxuICAgICAqIERlYWN0aXZlcyB0aGUgcHJvdmlkZXIuXG4gICAgIyMjXG4gICAgZGVhY3RpdmF0ZTogKCkgLT5cbiAgICAgICAgQHJlbW92ZUFubm90YXRpb25zKClcblxuICAgICMjIypcbiAgICAgKiBSZWdpc3RlcnMgZXZlbnQgaGFuZGxlcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvciBUZXh0RWRpdG9yIHRvIHJlZ2lzdGVyIGV2ZW50cyB0by5cbiAgICAjIyNcbiAgICByZWdpc3RlckV2ZW50czogKGVkaXRvcikgLT5cbiAgICAgICAgaWYgZWRpdG9yLmdldEdyYW1tYXIoKS5zY29wZU5hbWUubWF0Y2ggL3RleHQuaHRtbC5waHAkL1xuICAgICAgICAgICAgIyBUaWNrZXQgIzEwNyAtIE1vdXNlb3V0IGlzbid0IGdlbmVyYXRlZCB1bnRpbCB0aGUgbW91c2UgbW92ZXMsIGV2ZW4gd2hlbiBzY3JvbGxpbmcgKHdpdGggdGhlIGtleWJvYXJkIG9yXG4gICAgICAgICAgICAjIG1vdXNlKS4gSWYgdGhlIGVsZW1lbnQgZ29lcyBvdXQgb2YgdGhlIHZpZXcgaW4gdGhlIG1lYW50aW1lLCBpdHMgSFRNTCBlbGVtZW50IGRpc2FwcGVhcnMsIG5ldmVyIHJlbW92aW5nXG4gICAgICAgICAgICAjIGl0LlxuICAgICAgICAgICAgZWRpdG9yLm9uRGlkRGVzdHJveSAoKSA9PlxuICAgICAgICAgICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICAgICAgICAgZWRpdG9yLm9uRGlkU3RvcENoYW5naW5nICgpID0+XG4gICAgICAgICAgICAgICAgQHJlbW92ZVBvcG92ZXIoKVxuXG4gICAgICAgICAgICB0ZXh0RWRpdG9yRWxlbWVudCA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpXG5cbiAgICAgICAgICAgIEAkKHRleHRFZGl0b3JFbGVtZW50LnNoYWRvd1Jvb3QpLmZpbmQoJy5ob3Jpem9udGFsLXNjcm9sbGJhcicpLm9uICdzY3JvbGwnLCAoKSA9PlxuICAgICAgICAgICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICAgICAgICAgQCQodGV4dEVkaXRvckVsZW1lbnQuc2hhZG93Um9vdCkuZmluZCgnLnZlcnRpY2FsLXNjcm9sbGJhcicpLm9uICdzY3JvbGwnLCAoKSA9PlxuICAgICAgICAgICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICMjIypcbiAgICAgKiBSZWdpc3RlcnMgdGhlIGFubm90YXRpb25zLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSBlZGl0b3IgVGhlIGVkaXRvciB0byBzZWFyY2ggdGhyb3VnaC5cbiAgICAjIyNcbiAgICByZWdpc3RlckFubm90YXRpb25zOiAoZWRpdG9yKSAtPlxuICAgICAgICB0ZXh0ID0gZWRpdG9yLmdldFRleHQoKVxuICAgICAgICByb3dzID0gdGV4dC5zcGxpdCgnXFxuJylcbiAgICAgICAgQHN1YkF0b21zW2VkaXRvci5nZXRMb25nVGl0bGUoKV0gPSBuZXcgU3ViQXRvbVxuXG4gICAgICAgIGZvciByb3dOdW0scm93IG9mIHJvd3NcbiAgICAgICAgICAgIHdoaWxlIChtYXRjaCA9IEByZWdleC5leGVjKHJvdykpXG4gICAgICAgICAgICAgICAgQHBsYWNlQW5ub3RhdGlvbihlZGl0b3IsIHJvd051bSwgcm93LCBtYXRjaClcblxuICAgICMjIypcbiAgICAgKiBQbGFjZXMgYW4gYW5ub3RhdGlvbiBhdCB0aGUgc3BlY2lmaWVkIGxpbmUgYW5kIHJvdyB0ZXh0LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSBlZGl0b3JcbiAgICAgKiBAcGFyYW0ge2ludH0gICAgICAgIHJvd1xuICAgICAqIEBwYXJhbSB7U3RyaW5nfSAgICAgcm93VGV4dFxuICAgICAqIEBwYXJhbSB7QXJyYXl9ICAgICAgbWF0Y2hcbiAgICAjIyNcbiAgICBwbGFjZUFubm90YXRpb246IChlZGl0b3IsIHJvdywgcm93VGV4dCwgbWF0Y2gpIC0+XG4gICAgICAgIGFubm90YXRpb25JbmZvID0gQGV4dHJhY3RBbm5vdGF0aW9uSW5mbyhlZGl0b3IsIHJvdywgcm93VGV4dCwgbWF0Y2gpXG5cbiAgICAgICAgaWYgbm90IGFubm90YXRpb25JbmZvXG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgICByYW5nZSA9IG5ldyBSYW5nZShcbiAgICAgICAgICAgIG5ldyBQb2ludChwYXJzZUludChyb3cpLCAwKSxcbiAgICAgICAgICAgIG5ldyBQb2ludChwYXJzZUludChyb3cpLCByb3dUZXh0Lmxlbmd0aClcbiAgICAgICAgKVxuXG4gICAgICAgICMgRm9yIEF0b20gMS4zIG9yIGdyZWF0ZXIsIG1haW50YWluSGlzdG9yeSBjYW4gb25seSBiZSBhcHBsaWVkIHRvIGVudGlyZVxuICAgICAgICAjIG1hcmtlciBsYXllcnMuIExheWVycyBkb24ndCBleGlzdCBpbiBlYXJsaWVyIHZlcnNpb25zLCBoZW5jZSB0aGVcbiAgICAgICAgIyBjb25kaXRpb25hbCBsb2dpYy5cbiAgICAgICAgaWYgdHlwZW9mIGVkaXRvci5hZGRNYXJrZXJMYXllciBpcyAnZnVuY3Rpb24nXG4gICAgICAgICAgICBAbWFya2VyTGF5ZXJzID89IG5ldyBXZWFrTWFwXG4gICAgICAgICAgICB1bmxlc3MgbWFya2VyTGF5ZXIgPSBAbWFya2VyTGF5ZXJzLmdldChlZGl0b3IpXG4gICAgICAgICAgICAgICAgbWFya2VyTGF5ZXIgPSBlZGl0b3IuYWRkTWFya2VyTGF5ZXIobWFpbnRhaW5IaXN0b3J5OiB0cnVlKVxuICAgICAgICAgICAgICAgIEBtYXJrZXJMYXllcnMuc2V0KGVkaXRvciwgbWFya2VyTGF5ZXIpXG5cbiAgICAgICAgbWFya2VyID0gKG1hcmtlckxheWVyID8gZWRpdG9yKS5tYXJrQnVmZmVyUmFuZ2UocmFuZ2UsIHtcbiAgICAgICAgICAgIG1haW50YWluSGlzdG9yeSA6IHRydWUsXG4gICAgICAgICAgICBpbnZhbGlkYXRlICAgICAgOiAndG91Y2gnXG4gICAgICAgIH0pXG5cbiAgICAgICAgZGVjb3JhdGlvbiA9IGVkaXRvci5kZWNvcmF0ZU1hcmtlcihtYXJrZXIsIHtcbiAgICAgICAgICAgIHR5cGU6ICdsaW5lLW51bWJlcicsXG4gICAgICAgICAgICBjbGFzczogYW5ub3RhdGlvbkluZm8ubGluZU51bWJlckNsYXNzXG4gICAgICAgIH0pXG5cbiAgICAgICAgbG9uZ1RpdGxlID0gZWRpdG9yLmdldExvbmdUaXRsZSgpXG5cbiAgICAgICAgaWYgQG1hcmtlcnNbbG9uZ1RpdGxlXSA9PSB1bmRlZmluZWRcbiAgICAgICAgICAgIEBtYXJrZXJzW2xvbmdUaXRsZV0gPSBbXVxuXG4gICAgICAgIEBtYXJrZXJzW2xvbmdUaXRsZV0ucHVzaChtYXJrZXIpXG5cbiAgICAgICAgQHJlZ2lzdGVyQW5ub3RhdGlvbkV2ZW50SGFuZGxlcnMoZWRpdG9yLCByb3csIGFubm90YXRpb25JbmZvKVxuXG4gICAgIyMjKlxuICAgICAqIEV4cmFjdHMgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGFubm90YXRpb24gbWF0Y2guXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvclxuICAgICAqIEBwYXJhbSB7aW50fSAgICAgICAgcm93XG4gICAgICogQHBhcmFtIHtTdHJpbmd9ICAgICByb3dUZXh0XG4gICAgICogQHBhcmFtIHtBcnJheX0gICAgICBtYXRjaFxuICAgICMjI1xuICAgIGV4dHJhY3RBbm5vdGF0aW9uSW5mbzogKGVkaXRvciwgcm93LCByb3dUZXh0LCBtYXRjaCkgLT5cblxuICAgICMjIypcbiAgICAgKiBSZWdpc3RlcnMgYW5ub3RhdGlvbiBldmVudCBoYW5kbGVycyBmb3IgdGhlIHNwZWNpZmllZCByb3cuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvclxuICAgICAqIEBwYXJhbSB7aW50fSAgICAgICAgcm93XG4gICAgICogQHBhcmFtIHtPYmplY3R9ICAgICBhbm5vdGF0aW9uSW5mb1xuICAgICMjI1xuICAgIHJlZ2lzdGVyQW5ub3RhdGlvbkV2ZW50SGFuZGxlcnM6IChlZGl0b3IsIHJvdywgYW5ub3RhdGlvbkluZm8pIC0+XG4gICAgICAgIHRleHRFZGl0b3JFbGVtZW50ID0gYXRvbS52aWV3cy5nZXRWaWV3KGVkaXRvcilcbiAgICAgICAgZ3V0dGVyQ29udGFpbmVyRWxlbWVudCA9IEAkKHRleHRFZGl0b3JFbGVtZW50LnNoYWRvd1Jvb3QpLmZpbmQoJy5ndXR0ZXItY29udGFpbmVyJylcblxuICAgICAgICBkbyAoZWRpdG9yLCBndXR0ZXJDb250YWluZXJFbGVtZW50LCBhbm5vdGF0aW9uSW5mbykgPT5cbiAgICAgICAgICAgIGxvbmdUaXRsZSA9IGVkaXRvci5nZXRMb25nVGl0bGUoKVxuICAgICAgICAgICAgc2VsZWN0b3IgPSAnLmxpbmUtbnVtYmVyJyArICcuJyArIGFubm90YXRpb25JbmZvLmxpbmVOdW1iZXJDbGFzcyArICdbZGF0YS1idWZmZXItcm93PScgKyByb3cgKyAnXSAuaWNvbi1yaWdodCdcblxuICAgICAgICAgICAgQHN1YkF0b21zW2xvbmdUaXRsZV0uYWRkIGd1dHRlckNvbnRhaW5lckVsZW1lbnQsICdtb3VzZW92ZXInLCBzZWxlY3RvciwgKGV2ZW50KSA9PlxuICAgICAgICAgICAgICAgIEBoYW5kbGVNb3VzZU92ZXIoZXZlbnQsIGVkaXRvciwgYW5ub3RhdGlvbkluZm8pXG5cbiAgICAgICAgICAgIEBzdWJBdG9tc1tsb25nVGl0bGVdLmFkZCBndXR0ZXJDb250YWluZXJFbGVtZW50LCAnbW91c2VvdXQnLCBzZWxlY3RvciwgKGV2ZW50KSA9PlxuICAgICAgICAgICAgICAgIEBoYW5kbGVNb3VzZU91dChldmVudCwgZWRpdG9yLCBhbm5vdGF0aW9uSW5mbylcblxuICAgICAgICAgICAgQHN1YkF0b21zW2xvbmdUaXRsZV0uYWRkIGd1dHRlckNvbnRhaW5lckVsZW1lbnQsICdjbGljaycsIHNlbGVjdG9yLCAoZXZlbnQpID0+XG4gICAgICAgICAgICAgICAgQGhhbmRsZU1vdXNlQ2xpY2soZXZlbnQsIGVkaXRvciwgYW5ub3RhdGlvbkluZm8pXG5cbiAgICAjIyMqXG4gICAgICogSGFuZGxlcyB0aGUgbW91c2Ugb3ZlciBldmVudCBvbiBhbiBhbm5vdGF0aW9uLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtqUXVlcnkuRXZlbnR9IGV2ZW50XG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSAgIGVkaXRvclxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSAgICAgICBhbm5vdGF0aW9uSW5mb1xuICAgICMjI1xuICAgIGhhbmRsZU1vdXNlT3ZlcjogKGV2ZW50LCBlZGl0b3IsIGFubm90YXRpb25JbmZvKSAtPlxuICAgICAgICBpZiBhbm5vdGF0aW9uSW5mby50b29sdGlwVGV4dFxuICAgICAgICAgICAgQHJlbW92ZVBvcG92ZXIoKVxuXG4gICAgICAgICAgICBAYXR0YWNoZWRQb3BvdmVyID0gbmV3IEF0dGFjaGVkUG9wb3ZlcihldmVudC50YXJnZXQpXG4gICAgICAgICAgICBAYXR0YWNoZWRQb3BvdmVyLnNldFRleHQoYW5ub3RhdGlvbkluZm8udG9vbHRpcFRleHQpXG4gICAgICAgICAgICBAYXR0YWNoZWRQb3BvdmVyLnNob3coKVxuXG4gICAgIyMjKlxuICAgICAqIEhhbmRsZXMgdGhlIG1vdXNlIG91dCBldmVudCBvbiBhbiBhbm5vdGF0aW9uLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtqUXVlcnkuRXZlbnR9IGV2ZW50XG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSAgIGVkaXRvclxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSAgICAgICBhbm5vdGF0aW9uSW5mb1xuICAgICMjI1xuICAgIGhhbmRsZU1vdXNlT3V0OiAoZXZlbnQsIGVkaXRvciwgYW5ub3RhdGlvbkluZm8pIC0+XG4gICAgICAgIEByZW1vdmVQb3BvdmVyKClcblxuICAgICMjIypcbiAgICAgKiBIYW5kbGVzIHRoZSBtb3VzZSBjbGljayBldmVudCBvbiBhbiBhbm5vdGF0aW9uLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtqUXVlcnkuRXZlbnR9IGV2ZW50XG4gICAgICogQHBhcmFtIHtUZXh0RWRpdG9yfSAgIGVkaXRvclxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSAgICAgICBhbm5vdGF0aW9uSW5mb1xuICAgICMjI1xuICAgIGhhbmRsZU1vdXNlQ2xpY2s6IChldmVudCwgZWRpdG9yLCBhbm5vdGF0aW9uSW5mbykgLT5cblxuICAgICMjIypcbiAgICAgKiBSZW1vdmVzIHRoZSBleGlzdGluZyBwb3BvdmVyLCBpZiBhbnkuXG4gICAgIyMjXG4gICAgcmVtb3ZlUG9wb3ZlcjogKCkgLT5cbiAgICAgICAgaWYgQGF0dGFjaGVkUG9wb3ZlclxuICAgICAgICAgICAgQGF0dGFjaGVkUG9wb3Zlci5kaXNwb3NlKClcbiAgICAgICAgICAgIEBhdHRhY2hlZFBvcG92ZXIgPSBudWxsXG5cbiAgICAjIyMqXG4gICAgICogUmVtb3ZlcyBhbnkgYW5ub3RhdGlvbnMgdGhhdCB3ZXJlIGNyZWF0ZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvciBUaGUgZWRpdG9yIHRvIHNlYXJjaCB0aHJvdWdoLlxuICAgICMjI1xuICAgIHJlbW92ZUFubm90YXRpb25zOiAoZWRpdG9yKSAtPlxuICAgICAgICBmb3IgaSxtYXJrZXIgb2YgQG1hcmtlcnNbZWRpdG9yLmdldExvbmdUaXRsZSgpXVxuICAgICAgICAgICAgbWFya2VyLmRlc3Ryb3koKVxuXG4gICAgICAgIEBtYXJrZXJzW2VkaXRvci5nZXRMb25nVGl0bGUoKV0gPSBbXVxuICAgICAgICBAc3ViQXRvbXNbZWRpdG9yLmdldExvbmdUaXRsZSgpXT8uZGlzcG9zZSgpXG5cbiAgICAjIyMqXG4gICAgICogUmVzY2FucyB0aGUgZWRpdG9yLCB1cGRhdGluZyBhbGwgYW5ub3RhdGlvbnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvciBUaGUgZWRpdG9yIHRvIHNlYXJjaCB0aHJvdWdoLlxuICAgICMjI1xuICAgIHJlc2NhbjogKGVkaXRvcikgLT5cbiAgICAgICAgQHJlbW92ZUFubm90YXRpb25zKGVkaXRvcilcbiAgICAgICAgQHJlZ2lzdGVyQW5ub3RhdGlvbnMoZWRpdG9yKVxuIl19
