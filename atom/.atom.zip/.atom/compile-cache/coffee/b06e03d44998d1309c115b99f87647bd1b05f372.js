(function() {
  var AbstractProvider, ClassProvider, TextEditor, proxy,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  TextEditor = require('atom').TextEditor;

  proxy = require('./abstract-provider');

  AbstractProvider = require('./abstract-provider');

  module.exports = ClassProvider = (function(superClass) {
    extend(ClassProvider, superClass);

    function ClassProvider() {
      return ClassProvider.__super__.constructor.apply(this, arguments);
    }

    ClassProvider.prototype.hoverEventSelectors = '.entity.inherited-class, .support.namespace, .support.class, .comment-clickable .region';


    /**
     * Retrieves a tooltip for the word given.
     * @param  {TextEditor} editor         TextEditor to search for namespace of term.
     * @param  {string}     term           Term to search for.
     * @param  {Point}      bufferPosition The cursor location the term is at.
     */

    ClassProvider.prototype.getTooltipForWord = function(editor, term, bufferPosition) {
      var classInfo, description, fullClassName, ref, type;
      fullClassName = this.parser.getFullClassName(editor, term);
      proxy = require('../services/php-proxy.coffee');
      classInfo = proxy.methods(fullClassName);
      if (!classInfo || !classInfo.wasFound) {
        return;
      }
      type = '';
      if (classInfo.isClass) {
        type = (classInfo.isAbstract ? 'abstract ' : '') + 'class';
      } else if (classInfo.isTrait) {
        type = 'trait';
      } else if (classInfo.isInterface) {
        type = 'interface';
      }
      description = '';
      description += "<p><div>";
      description += type + ' ' + '<strong>' + classInfo.shortName + '</strong> &mdash; ' + classInfo["class"];
      description += '</div></p>';
      description += '<div>';
      description += (classInfo.args.descriptions.short ? classInfo.args.descriptions.short : '(No documentation available)');
      description += '</div>';
      if (((ref = classInfo.args.descriptions.long) != null ? ref.length : void 0) > 0) {
        description += '<div class="section">';
        description += "<h4>Description</h4>";
        description += "<div>" + classInfo.args.descriptions.long + "</div>";
        description += "</div>";
      }
      return description;
    };


    /**
     * Gets the correct selector when a class or namespace is clicked.
     *
     * @param  {jQuery.Event}  event  A jQuery event.
     *
     * @return {object|null} A selector to be used with jQuery.
     */

    ClassProvider.prototype.getSelectorFromEvent = function(event) {
      return this.parser.getClassSelectorFromEvent(event);
    };


    /**
     * Gets the correct element to attach the popover to from the retrieved selector.
     * @param  {jQuery.Event}  event  A jQuery event.
     * @return {object|null}          A selector to be used with jQuery.
     */

    ClassProvider.prototype.getPopoverElementFromSelector = function(selector) {
      var array;
      array = this.$(selector).toArray();
      return array[array.length - 1];
    };

    return ClassProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi90b29sdGlwL2NsYXNzLXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsa0RBQUE7SUFBQTs7O0VBQUMsYUFBYyxPQUFBLENBQVEsTUFBUjs7RUFFZixLQUFBLEdBQVEsT0FBQSxDQUFRLHFCQUFSOztFQUNSLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSxxQkFBUjs7RUFFbkIsTUFBTSxDQUFDLE9BQVAsR0FFTTs7Ozs7Ozs0QkFDRixtQkFBQSxHQUFxQjs7O0FBRXJCOzs7Ozs7OzRCQU1BLGlCQUFBLEdBQW1CLFNBQUMsTUFBRCxFQUFTLElBQVQsRUFBZSxjQUFmO0FBQ2YsVUFBQTtNQUFBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLE1BQU0sQ0FBQyxnQkFBUixDQUF5QixNQUF6QixFQUFpQyxJQUFqQztNQUVoQixLQUFBLEdBQVEsT0FBQSxDQUFRLDhCQUFSO01BQ1IsU0FBQSxHQUFZLEtBQUssQ0FBQyxPQUFOLENBQWMsYUFBZDtNQUVaLElBQUcsQ0FBSSxTQUFKLElBQWlCLENBQUksU0FBUyxDQUFDLFFBQWxDO0FBQ0ksZUFESjs7TUFHQSxJQUFBLEdBQU87TUFFUCxJQUFHLFNBQVMsQ0FBQyxPQUFiO1FBQ0ksSUFBQSxHQUFPLENBQUksU0FBUyxDQUFDLFVBQWIsR0FBNkIsV0FBN0IsR0FBOEMsRUFBL0MsQ0FBQSxHQUFxRCxRQURoRTtPQUFBLE1BR0ssSUFBRyxTQUFTLENBQUMsT0FBYjtRQUNELElBQUEsR0FBTyxRQUROO09BQUEsTUFHQSxJQUFHLFNBQVMsQ0FBQyxXQUFiO1FBQ0QsSUFBQSxHQUFPLFlBRE47O01BSUwsV0FBQSxHQUFjO01BRWQsV0FBQSxJQUFlO01BQ2YsV0FBQSxJQUFtQixJQUFBLEdBQU8sR0FBUCxHQUFhLFVBQWIsR0FBMEIsU0FBUyxDQUFDLFNBQXBDLEdBQWdELG9CQUFoRCxHQUF1RSxTQUFTLEVBQUMsS0FBRDtNQUNuRyxXQUFBLElBQWU7TUFHZixXQUFBLElBQWU7TUFDZixXQUFBLElBQW1CLENBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBL0IsR0FBMEMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBdEUsR0FBaUYsOEJBQWxGO01BQ25CLFdBQUEsSUFBZTtNQUdmLDJEQUFtQyxDQUFFLGdCQUFsQyxHQUEyQyxDQUE5QztRQUNJLFdBQUEsSUFBZTtRQUNmLFdBQUEsSUFBbUI7UUFDbkIsV0FBQSxJQUFtQixPQUFBLEdBQVUsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBdEMsR0FBNkM7UUFDaEUsV0FBQSxJQUFlLFNBSm5COztBQU1BLGFBQU87SUF2Q1E7OztBQXlDbkI7Ozs7Ozs7OzRCQU9BLG9CQUFBLEdBQXNCLFNBQUMsS0FBRDtBQUNsQixhQUFPLElBQUMsQ0FBQSxNQUFNLENBQUMseUJBQVIsQ0FBa0MsS0FBbEM7SUFEVzs7O0FBR3RCOzs7Ozs7NEJBS0EsNkJBQUEsR0FBK0IsU0FBQyxRQUFEO0FBRzNCLFVBQUE7TUFBQSxLQUFBLEdBQVEsSUFBQyxDQUFBLENBQUQsQ0FBRyxRQUFILENBQVksQ0FBQyxPQUFiLENBQUE7QUFDUixhQUFPLEtBQU0sQ0FBQSxLQUFLLENBQUMsTUFBTixHQUFlLENBQWY7SUFKYzs7OztLQWpFUDtBQVA1QiIsInNvdXJjZXNDb250ZW50IjpbIntUZXh0RWRpdG9yfSA9IHJlcXVpcmUgJ2F0b20nXG5cbnByb3h5ID0gcmVxdWlyZSAnLi9hYnN0cmFjdC1wcm92aWRlcidcbkFic3RyYWN0UHJvdmlkZXIgPSByZXF1aXJlICcuL2Fic3RyYWN0LXByb3ZpZGVyJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5cbmNsYXNzIENsYXNzUHJvdmlkZXIgZXh0ZW5kcyBBYnN0cmFjdFByb3ZpZGVyXG4gICAgaG92ZXJFdmVudFNlbGVjdG9yczogJy5lbnRpdHkuaW5oZXJpdGVkLWNsYXNzLCAuc3VwcG9ydC5uYW1lc3BhY2UsIC5zdXBwb3J0LmNsYXNzLCAuY29tbWVudC1jbGlja2FibGUgLnJlZ2lvbidcblxuICAgICMjIypcbiAgICAgKiBSZXRyaWV2ZXMgYSB0b29sdGlwIGZvciB0aGUgd29yZCBnaXZlbi5cbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgICAgICAgICBUZXh0RWRpdG9yIHRvIHNlYXJjaCBmb3IgbmFtZXNwYWNlIG9mIHRlcm0uXG4gICAgICogQHBhcmFtICB7c3RyaW5nfSAgICAgdGVybSAgICAgICAgICAgVGVybSB0byBzZWFyY2ggZm9yLlxuICAgICAqIEBwYXJhbSAge1BvaW50fSAgICAgIGJ1ZmZlclBvc2l0aW9uIFRoZSBjdXJzb3IgbG9jYXRpb24gdGhlIHRlcm0gaXMgYXQuXG4gICAgIyMjXG4gICAgZ2V0VG9vbHRpcEZvcldvcmQ6IChlZGl0b3IsIHRlcm0sIGJ1ZmZlclBvc2l0aW9uKSAtPlxuICAgICAgICBmdWxsQ2xhc3NOYW1lID0gQHBhcnNlci5nZXRGdWxsQ2xhc3NOYW1lKGVkaXRvciwgdGVybSlcblxuICAgICAgICBwcm94eSA9IHJlcXVpcmUgJy4uL3NlcnZpY2VzL3BocC1wcm94eS5jb2ZmZWUnXG4gICAgICAgIGNsYXNzSW5mbyA9IHByb3h5Lm1ldGhvZHMoZnVsbENsYXNzTmFtZSlcblxuICAgICAgICBpZiBub3QgY2xhc3NJbmZvIG9yIG5vdCBjbGFzc0luZm8ud2FzRm91bmRcbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgIHR5cGUgPSAnJ1xuXG4gICAgICAgIGlmIGNsYXNzSW5mby5pc0NsYXNzXG4gICAgICAgICAgICB0eXBlID0gKGlmIGNsYXNzSW5mby5pc0Fic3RyYWN0IHRoZW4gJ2Fic3RyYWN0ICcgZWxzZSAnJykgKyAnY2xhc3MnXG5cbiAgICAgICAgZWxzZSBpZiBjbGFzc0luZm8uaXNUcmFpdFxuICAgICAgICAgICAgdHlwZSA9ICd0cmFpdCdcblxuICAgICAgICBlbHNlIGlmIGNsYXNzSW5mby5pc0ludGVyZmFjZVxuICAgICAgICAgICAgdHlwZSA9ICdpbnRlcmZhY2UnXG5cbiAgICAgICAgIyBDcmVhdGUgYSB1c2VmdWwgZGVzY3JpcHRpb24gdG8gc2hvdyBpbiB0aGUgdG9vbHRpcC5cbiAgICAgICAgZGVzY3JpcHRpb24gPSAnJ1xuXG4gICAgICAgIGRlc2NyaXB0aW9uICs9IFwiPHA+PGRpdj5cIlxuICAgICAgICBkZXNjcmlwdGlvbiArPSAgICAgdHlwZSArICcgJyArICc8c3Ryb25nPicgKyBjbGFzc0luZm8uc2hvcnROYW1lICsgJzwvc3Ryb25nPiAmbWRhc2g7ICcgKyBjbGFzc0luZm8uY2xhc3NcbiAgICAgICAgZGVzY3JpcHRpb24gKz0gJzwvZGl2PjwvcD4nXG5cbiAgICAgICAgIyBTaG93IHRoZSBzdW1tYXJ5IChzaG9ydCBkZXNjcmlwdGlvbikuXG4gICAgICAgIGRlc2NyaXB0aW9uICs9ICc8ZGl2PidcbiAgICAgICAgZGVzY3JpcHRpb24gKz0gICAgIChpZiBjbGFzc0luZm8uYXJncy5kZXNjcmlwdGlvbnMuc2hvcnQgdGhlbiBjbGFzc0luZm8uYXJncy5kZXNjcmlwdGlvbnMuc2hvcnQgZWxzZSAnKE5vIGRvY3VtZW50YXRpb24gYXZhaWxhYmxlKScpXG4gICAgICAgIGRlc2NyaXB0aW9uICs9ICc8L2Rpdj4nXG5cbiAgICAgICAgIyBTaG93IHRoZSAobG9uZykgZGVzY3JpcHRpb24uXG4gICAgICAgIGlmIGNsYXNzSW5mby5hcmdzLmRlc2NyaXB0aW9ucy5sb25nPy5sZW5ndGggPiAwXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSAnPGRpdiBjbGFzcz1cInNlY3Rpb25cIj4nXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSAgICAgXCI8aDQ+RGVzY3JpcHRpb248L2g0PlwiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSAgICAgXCI8ZGl2PlwiICsgY2xhc3NJbmZvLmFyZ3MuZGVzY3JpcHRpb25zLmxvbmcgKyBcIjwvZGl2PlwiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbiArPSBcIjwvZGl2PlwiXG5cbiAgICAgICAgcmV0dXJuIGRlc2NyaXB0aW9uXG5cbiAgICAjIyMqXG4gICAgICogR2V0cyB0aGUgY29ycmVjdCBzZWxlY3RvciB3aGVuIGEgY2xhc3Mgb3IgbmFtZXNwYWNlIGlzIGNsaWNrZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gIHtqUXVlcnkuRXZlbnR9ICBldmVudCAgQSBqUXVlcnkgZXZlbnQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtvYmplY3R8bnVsbH0gQSBzZWxlY3RvciB0byBiZSB1c2VkIHdpdGggalF1ZXJ5LlxuICAgICMjI1xuICAgIGdldFNlbGVjdG9yRnJvbUV2ZW50OiAoZXZlbnQpIC0+XG4gICAgICAgIHJldHVybiBAcGFyc2VyLmdldENsYXNzU2VsZWN0b3JGcm9tRXZlbnQoZXZlbnQpXG5cbiAgICAjIyMqXG4gICAgICogR2V0cyB0aGUgY29ycmVjdCBlbGVtZW50IHRvIGF0dGFjaCB0aGUgcG9wb3ZlciB0byBmcm9tIHRoZSByZXRyaWV2ZWQgc2VsZWN0b3IuXG4gICAgICogQHBhcmFtICB7alF1ZXJ5LkV2ZW50fSAgZXZlbnQgIEEgalF1ZXJ5IGV2ZW50LlxuICAgICAqIEByZXR1cm4ge29iamVjdHxudWxsfSAgICAgICAgICBBIHNlbGVjdG9yIHRvIGJlIHVzZWQgd2l0aCBqUXVlcnkuXG4gICAgIyMjXG4gICAgZ2V0UG9wb3ZlckVsZW1lbnRGcm9tU2VsZWN0b3I6IChzZWxlY3RvcikgLT5cbiAgICAgICAgIyBnZXRTZWxlY3RvckZyb21FdmVudCBjYW4gcmV0dXJuIG11bHRpcGxlIGl0ZW1zIGJlY2F1c2UgbmFtZXNwYWNlcyBhbmQgY2xhc3MgbmFtZXMgYXJlIGRpZmZlcmVudCBIVE1MIGVsZW1lbnRzLlxuICAgICAgICAjIFdlIGhhdmUgdG8gc2VsZWN0IG9uZSB0byBhdHRhY2ggdGhlIHBvcG92ZXIgdG8uXG4gICAgICAgIGFycmF5ID0gQCQoc2VsZWN0b3IpLnRvQXJyYXkoKVxuICAgICAgICByZXR1cm4gYXJyYXlbYXJyYXkubGVuZ3RoIC0gMV1cbiJdfQ==
