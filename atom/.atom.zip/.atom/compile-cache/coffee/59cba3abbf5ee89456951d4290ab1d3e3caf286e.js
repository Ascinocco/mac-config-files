(function() {
  var AbstractProvider, ClassProvider,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  AbstractProvider = require('./abstract-provider');

  module.exports = ClassProvider = (function(superClass) {
    extend(ClassProvider, superClass);

    function ClassProvider() {
      return ClassProvider.__super__.constructor.apply(this, arguments);
    }

    ClassProvider.prototype.hoverEventSelectors = '.entity.inherited-class, .support.namespace, .support.class, .comment-clickable .region';

    ClassProvider.prototype.clickEventSelectors = '.entity.inherited-class, .support.namespace, .support.class';

    ClassProvider.prototype.gotoRegex = /^\\?[A-Z][A-za-z0-9_]*(\\[A-Z][A-Za-z0-9_])*$/;


    /**
     * Goto the class from the term given.
     *
     * @param  {TextEditor} editor TextEditor to search for namespace of term.
     * @param  {string}     term   Term to search for.
     */

    ClassProvider.prototype.gotoFromWord = function(editor, term) {
      var classInfo, classesResponse, matches, proxy, regexMatches;
      if (term === void 0 || term.indexOf('$') === 0) {
        return;
      }
      term = this.parser.getFullClassName(editor, term);
      proxy = require('../services/php-proxy.coffee');
      classesResponse = proxy.classes();
      if (!classesResponse.autocomplete) {
        return;
      }
      this.manager.addBackTrack(editor.getPath(), editor.getCursorBufferPosition());
      matches = this.fuzzaldrin.filter(classesResponse.autocomplete, term);
      if (matches[0] === term) {
        regexMatches = /(?:\\)(\w+)$/i.exec(matches[0]);
        if (regexMatches === null || regexMatches.length === 0) {
          this.jumpWord = matches[0];
        } else {
          this.jumpWord = regexMatches[1];
        }
        classInfo = proxy.methods(matches[0]);
        return atom.workspace.open(classInfo.filename, {
          searchAllPanes: true
        });
      }
    };


    /**
     * Gets the correct selector when a class or namespace is clicked.
     *
     * @param  {jQuery.Event}  event  A jQuery event.
     *
     * @return {object|null} A selector to be used with jQuery.
     */

    ClassProvider.prototype.getSelectorFromEvent = function(event) {
      return this.parser.getClassSelectorFromEvent(event);
    };


    /**
     * Goes through all the lines within the editor looking for classes within comments. More specifically if they have
     * @var, @param or @return prefixed.
     *
     * @param  {TextEditor} editor The editor to search through.
     */

    ClassProvider.prototype.registerMarkers = function(editor) {
      var key, regex, results, row, rows, text;
      text = editor.getText();
      rows = text.split('\n');
      results = [];
      for (key in rows) {
        row = rows[key];
        regex = /@param|@var|@return|@throws|@see/gi;
        if (regex.test(row)) {
          results.push(this.addMarkerToCommentLine(row.split(' '), parseInt(key), editor, true));
        } else {
          results.push(void 0);
        }
      }
      return results;
    };


    /**
     * Removes any markers previously created by registerMarkers.
     *
     * @param {TextEditor} editor The editor to search through
     */

    ClassProvider.prototype.cleanMarkers = function(editor) {
      var i, marker, ref;
      ref = this.allMarkers[editor.getLongTitle()];
      for (i in ref) {
        marker = ref[i];
        marker.destroy();
      }
      return this.allMarkers = [];
    };


    /**
     * Analyses the words array given for any classes and then creates a marker for them.
     *
     * @param {array} words           The array of words to check.
     * @param {int} rowIndex          The current row the words are on within the editor.
     * @param {TextEditor} editor     The editor the words are from.
     * @param {bool} shouldBreak      Flag to say whether the search should break after finding 1 class.
     * @param {int} currentIndex  = 0 The current column index the search is on.
     * @param {int} offset        = 0 Any offset that should be applied when creating the marker.
     */

    ClassProvider.prototype.addMarkerToCommentLine = function(words, rowIndex, editor, shouldBreak, currentIndex, offset) {
      var key, keywordRegex, marker, markerProperties, options, range, regex, results, value;
      if (currentIndex == null) {
        currentIndex = 0;
      }
      if (offset == null) {
        offset = 0;
      }
      results = [];
      for (key in words) {
        value = words[key];
        regex = /^\\?([A-Za-z0-9_]+)\\?([A-Za-zA-Z_\\]*)?/g;
        keywordRegex = /^(array|object|bool|string|static|null|boolean|void|int|integer|mixed|callable)$/gi;
        if (value && regex.test(value) && keywordRegex.test(value) === false) {
          if (value.includes('|')) {
            this.addMarkerToCommentLine(value.split('|'), rowIndex, editor, false, currentIndex, parseInt(key));
          } else {
            range = [[rowIndex, currentIndex + parseInt(key) + offset], [rowIndex, currentIndex + parseInt(key) + value.length + offset]];
            marker = editor.markBufferRange(range);
            markerProperties = {
              term: value
            };
            marker.setProperties(markerProperties);
            options = {
              type: 'highlight',
              "class": 'comment-clickable comment'
            };
            if (!marker.isDestroyed()) {
              editor.decorateMarker(marker, options);
            }
            if (this.allMarkers[editor.getLongTitle()] === void 0) {
              this.allMarkers[editor.getLongTitle()] = [];
            }
            this.allMarkers[editor.getLongTitle()].push(marker);
          }
          if (shouldBreak === true) {
            break;
          }
        }
        results.push(currentIndex += value.length);
      }
      return results;
    };


    /**
     * Gets the regex used when looking for a word within the editor
     *
     * @param  {string} term Term being search.
     *
     * @return {regex} Regex to be used.
     */

    ClassProvider.prototype.getJumpToRegex = function(term) {
      return RegExp("^(class|interface|abstractclass|trait) +" + term, "i");
    };

    return ClassProvider;

  })(AbstractProvider);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL1VzZXJzL2FudGhvbnkvLmF0b20vcGFja2FnZXMvYXRvbS1hdXRvY29tcGxldGUtcGhwL2xpYi9nb3RvL2NsYXNzLXByb3ZpZGVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUEsK0JBQUE7SUFBQTs7O0VBQUEsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLHFCQUFSOztFQUVuQixNQUFNLENBQUMsT0FBUCxHQUVNOzs7Ozs7OzRCQUNGLG1CQUFBLEdBQXFCOzs0QkFDckIsbUJBQUEsR0FBcUI7OzRCQUNyQixTQUFBLEdBQVc7OztBQUVYOzs7Ozs7OzRCQU1BLFlBQUEsR0FBYyxTQUFDLE1BQUQsRUFBUyxJQUFUO0FBQ1YsVUFBQTtNQUFBLElBQUcsSUFBQSxLQUFRLE1BQVIsSUFBcUIsSUFBSSxDQUFDLE9BQUwsQ0FBYSxHQUFiLENBQUEsS0FBcUIsQ0FBN0M7QUFDSSxlQURKOztNQUdBLElBQUEsR0FBTyxJQUFDLENBQUEsTUFBTSxDQUFDLGdCQUFSLENBQXlCLE1BQXpCLEVBQWlDLElBQWpDO01BRVAsS0FBQSxHQUFRLE9BQUEsQ0FBUSw4QkFBUjtNQUNSLGVBQUEsR0FBa0IsS0FBSyxDQUFDLE9BQU4sQ0FBQTtNQUVsQixJQUFBLENBQWMsZUFBZSxDQUFDLFlBQTlCO0FBQUEsZUFBQTs7TUFFQSxJQUFDLENBQUEsT0FBTyxDQUFDLFlBQVQsQ0FBc0IsTUFBTSxDQUFDLE9BQVAsQ0FBQSxDQUF0QixFQUF3QyxNQUFNLENBQUMsdUJBQVAsQ0FBQSxDQUF4QztNQUdBLE9BQUEsR0FBVSxJQUFDLENBQUEsVUFBVSxDQUFDLE1BQVosQ0FBbUIsZUFBZSxDQUFDLFlBQW5DLEVBQWlELElBQWpEO01BRVYsSUFBRyxPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsSUFBakI7UUFDSSxZQUFBLEdBQWUsZUFBZSxDQUFDLElBQWhCLENBQXFCLE9BQVEsQ0FBQSxDQUFBLENBQTdCO1FBRWYsSUFBRyxZQUFBLEtBQWdCLElBQWhCLElBQXdCLFlBQVksQ0FBQyxNQUFiLEtBQXVCLENBQWxEO1VBQ0ksSUFBQyxDQUFBLFFBQUQsR0FBWSxPQUFRLENBQUEsQ0FBQSxFQUR4QjtTQUFBLE1BQUE7VUFJSSxJQUFDLENBQUEsUUFBRCxHQUFZLFlBQWEsQ0FBQSxDQUFBLEVBSjdCOztRQU1BLFNBQUEsR0FBWSxLQUFLLENBQUMsT0FBTixDQUFjLE9BQVEsQ0FBQSxDQUFBLENBQXRCO2VBRVosSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFmLENBQW9CLFNBQVMsQ0FBQyxRQUE5QixFQUF3QztVQUNwQyxjQUFBLEVBQWdCLElBRG9CO1NBQXhDLEVBWEo7O0lBaEJVOzs7QUErQmQ7Ozs7Ozs7OzRCQU9BLG9CQUFBLEdBQXNCLFNBQUMsS0FBRDtBQUNsQixhQUFPLElBQUMsQ0FBQSxNQUFNLENBQUMseUJBQVIsQ0FBa0MsS0FBbEM7SUFEVzs7O0FBR3RCOzs7Ozs7OzRCQU1BLGVBQUEsR0FBaUIsU0FBQyxNQUFEO0FBQ2IsVUFBQTtNQUFBLElBQUEsR0FBTyxNQUFNLENBQUMsT0FBUCxDQUFBO01BQ1AsSUFBQSxHQUFPLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWDtBQUVQO1dBQUEsV0FBQTs7UUFDSSxLQUFBLEdBQVE7UUFFUixJQUFHLEtBQUssQ0FBQyxJQUFOLENBQVcsR0FBWCxDQUFIO3VCQUNJLElBQUMsQ0FBQSxzQkFBRCxDQUF3QixHQUFHLENBQUMsS0FBSixDQUFVLEdBQVYsQ0FBeEIsRUFBd0MsUUFBQSxDQUFTLEdBQVQsQ0FBeEMsRUFBdUQsTUFBdkQsRUFBK0QsSUFBL0QsR0FESjtTQUFBLE1BQUE7K0JBQUE7O0FBSEo7O0lBSmE7OztBQVVqQjs7Ozs7OzRCQUtBLFlBQUEsR0FBYyxTQUFDLE1BQUQ7QUFDVixVQUFBO0FBQUE7QUFBQSxXQUFBLFFBQUE7O1FBQ0ksTUFBTSxDQUFDLE9BQVAsQ0FBQTtBQURKO2FBR0EsSUFBQyxDQUFBLFVBQUQsR0FBYztJQUpKOzs7QUFNZDs7Ozs7Ozs7Ozs7NEJBVUEsc0JBQUEsR0FBd0IsU0FBQyxLQUFELEVBQVEsUUFBUixFQUFrQixNQUFsQixFQUEwQixXQUExQixFQUF1QyxZQUF2QyxFQUF5RCxNQUF6RDtBQUNwQixVQUFBOztRQUQyRCxlQUFlOzs7UUFBRyxTQUFTOztBQUN0RjtXQUFBLFlBQUE7O1FBQ0ksS0FBQSxHQUFRO1FBQ1IsWUFBQSxHQUFlO1FBRWYsSUFBRyxLQUFBLElBQVMsS0FBSyxDQUFDLElBQU4sQ0FBVyxLQUFYLENBQVQsSUFBOEIsWUFBWSxDQUFDLElBQWIsQ0FBa0IsS0FBbEIsQ0FBQSxLQUE0QixLQUE3RDtVQUNJLElBQUcsS0FBSyxDQUFDLFFBQU4sQ0FBZSxHQUFmLENBQUg7WUFDSSxJQUFDLENBQUEsc0JBQUQsQ0FBd0IsS0FBSyxDQUFDLEtBQU4sQ0FBWSxHQUFaLENBQXhCLEVBQTBDLFFBQTFDLEVBQW9ELE1BQXBELEVBQTRELEtBQTVELEVBQW1FLFlBQW5FLEVBQWlGLFFBQUEsQ0FBUyxHQUFULENBQWpGLEVBREo7V0FBQSxNQUFBO1lBSUksS0FBQSxHQUFRLENBQUMsQ0FBQyxRQUFELEVBQVcsWUFBQSxHQUFlLFFBQUEsQ0FBUyxHQUFULENBQWYsR0FBK0IsTUFBMUMsQ0FBRCxFQUFvRCxDQUFDLFFBQUQsRUFBVyxZQUFBLEdBQWUsUUFBQSxDQUFTLEdBQVQsQ0FBZixHQUErQixLQUFLLENBQUMsTUFBckMsR0FBOEMsTUFBekQsQ0FBcEQ7WUFFUixNQUFBLEdBQVMsTUFBTSxDQUFDLGVBQVAsQ0FBdUIsS0FBdkI7WUFFVCxnQkFBQSxHQUNJO2NBQUEsSUFBQSxFQUFNLEtBQU47O1lBRUosTUFBTSxDQUFDLGFBQVAsQ0FBcUIsZ0JBQXJCO1lBRUEsT0FBQSxHQUNJO2NBQUEsSUFBQSxFQUFNLFdBQU47Y0FDQSxDQUFBLEtBQUEsQ0FBQSxFQUFPLDJCQURQOztZQUdKLElBQUcsQ0FBQyxNQUFNLENBQUMsV0FBUCxDQUFBLENBQUo7Y0FDSSxNQUFNLENBQUMsY0FBUCxDQUFzQixNQUF0QixFQUE4QixPQUE5QixFQURKOztZQUdBLElBQUcsSUFBQyxDQUFBLFVBQVcsQ0FBQSxNQUFNLENBQUMsWUFBUCxDQUFBLENBQUEsQ0FBWixLQUFzQyxNQUF6QztjQUNJLElBQUMsQ0FBQSxVQUFXLENBQUEsTUFBTSxDQUFDLFlBQVAsQ0FBQSxDQUFBLENBQVosR0FBcUMsR0FEekM7O1lBR0EsSUFBQyxDQUFBLFVBQVcsQ0FBQSxNQUFNLENBQUMsWUFBUCxDQUFBLENBQUEsQ0FBc0IsQ0FBQyxJQUFuQyxDQUF3QyxNQUF4QyxFQXZCSjs7VUF5QkEsSUFBRyxXQUFBLEtBQWUsSUFBbEI7QUFDSSxrQkFESjtXQTFCSjs7cUJBNkJBLFlBQUEsSUFBZ0IsS0FBSyxDQUFDO0FBakMxQjs7SUFEb0I7OztBQW9DeEI7Ozs7Ozs7OzRCQU9BLGNBQUEsR0FBZ0IsU0FBQyxJQUFEO0FBQ1osYUFBTyxNQUFBLENBQUEsMENBQUEsR0FBK0MsSUFBL0MsRUFBdUQsR0FBdkQ7SUFESzs7OztLQXBJUTtBQUo1QiIsInNvdXJjZXNDb250ZW50IjpbIkFic3RyYWN0UHJvdmlkZXIgPSByZXF1aXJlICcuL2Fic3RyYWN0LXByb3ZpZGVyJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5cbmNsYXNzIENsYXNzUHJvdmlkZXIgZXh0ZW5kcyBBYnN0cmFjdFByb3ZpZGVyXG4gICAgaG92ZXJFdmVudFNlbGVjdG9yczogJy5lbnRpdHkuaW5oZXJpdGVkLWNsYXNzLCAuc3VwcG9ydC5uYW1lc3BhY2UsIC5zdXBwb3J0LmNsYXNzLCAuY29tbWVudC1jbGlja2FibGUgLnJlZ2lvbidcbiAgICBjbGlja0V2ZW50U2VsZWN0b3JzOiAnLmVudGl0eS5pbmhlcml0ZWQtY2xhc3MsIC5zdXBwb3J0Lm5hbWVzcGFjZSwgLnN1cHBvcnQuY2xhc3MnXG4gICAgZ290b1JlZ2V4OiAvXlxcXFw/W0EtWl1bQS16YS16MC05X10qKFxcXFxbQS1aXVtBLVphLXowLTlfXSkqJC9cblxuICAgICMjIypcbiAgICAgKiBHb3RvIHRoZSBjbGFzcyBmcm9tIHRoZSB0ZXJtIGdpdmVuLlxuICAgICAqXG4gICAgICogQHBhcmFtICB7VGV4dEVkaXRvcn0gZWRpdG9yIFRleHRFZGl0b3IgdG8gc2VhcmNoIGZvciBuYW1lc3BhY2Ugb2YgdGVybS5cbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9ICAgICB0ZXJtICAgVGVybSB0byBzZWFyY2ggZm9yLlxuICAgICMjI1xuICAgIGdvdG9Gcm9tV29yZDogKGVkaXRvciwgdGVybSkgLT5cbiAgICAgICAgaWYgdGVybSA9PSB1bmRlZmluZWQgfHwgdGVybS5pbmRleE9mKCckJykgPT0gMFxuICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgdGVybSA9IEBwYXJzZXIuZ2V0RnVsbENsYXNzTmFtZShlZGl0b3IsIHRlcm0pXG5cbiAgICAgICAgcHJveHkgPSByZXF1aXJlICcuLi9zZXJ2aWNlcy9waHAtcHJveHkuY29mZmVlJ1xuICAgICAgICBjbGFzc2VzUmVzcG9uc2UgPSBwcm94eS5jbGFzc2VzKClcblxuICAgICAgICByZXR1cm4gdW5sZXNzIGNsYXNzZXNSZXNwb25zZS5hdXRvY29tcGxldGVcblxuICAgICAgICBAbWFuYWdlci5hZGRCYWNrVHJhY2soZWRpdG9yLmdldFBhdGgoKSwgZWRpdG9yLmdldEN1cnNvckJ1ZmZlclBvc2l0aW9uKCkpXG5cbiAgICAgICAgIyBTZWUgd2hhdCBtYXRjaGVzIHdlIGhhdmUgZm9yIHRoaXMgY2xhc3MgbmFtZS5cbiAgICAgICAgbWF0Y2hlcyA9IEBmdXp6YWxkcmluLmZpbHRlcihjbGFzc2VzUmVzcG9uc2UuYXV0b2NvbXBsZXRlLCB0ZXJtKVxuXG4gICAgICAgIGlmIG1hdGNoZXNbMF0gPT0gdGVybVxuICAgICAgICAgICAgcmVnZXhNYXRjaGVzID0gLyg/OlxcXFwpKFxcdyspJC9pLmV4ZWMobWF0Y2hlc1swXSlcblxuICAgICAgICAgICAgaWYgcmVnZXhNYXRjaGVzID09IG51bGwgfHwgcmVnZXhNYXRjaGVzLmxlbmd0aCA9PSAwXG4gICAgICAgICAgICAgICAgQGp1bXBXb3JkID0gbWF0Y2hlc1swXVxuXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgQGp1bXBXb3JkID0gcmVnZXhNYXRjaGVzWzFdXG5cbiAgICAgICAgICAgIGNsYXNzSW5mbyA9IHByb3h5Lm1ldGhvZHMobWF0Y2hlc1swXSlcblxuICAgICAgICAgICAgYXRvbS53b3Jrc3BhY2Uub3BlbihjbGFzc0luZm8uZmlsZW5hbWUsIHtcbiAgICAgICAgICAgICAgICBzZWFyY2hBbGxQYW5lczogdHJ1ZVxuICAgICAgICAgICAgfSlcblxuICAgICMjIypcbiAgICAgKiBHZXRzIHRoZSBjb3JyZWN0IHNlbGVjdG9yIHdoZW4gYSBjbGFzcyBvciBuYW1lc3BhY2UgaXMgY2xpY2tlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSAge2pRdWVyeS5FdmVudH0gIGV2ZW50ICBBIGpRdWVyeSBldmVudC5cbiAgICAgKlxuICAgICAqIEByZXR1cm4ge29iamVjdHxudWxsfSBBIHNlbGVjdG9yIHRvIGJlIHVzZWQgd2l0aCBqUXVlcnkuXG4gICAgIyMjXG4gICAgZ2V0U2VsZWN0b3JGcm9tRXZlbnQ6IChldmVudCkgLT5cbiAgICAgICAgcmV0dXJuIEBwYXJzZXIuZ2V0Q2xhc3NTZWxlY3RvckZyb21FdmVudChldmVudClcblxuICAgICMjIypcbiAgICAgKiBHb2VzIHRocm91Z2ggYWxsIHRoZSBsaW5lcyB3aXRoaW4gdGhlIGVkaXRvciBsb29raW5nIGZvciBjbGFzc2VzIHdpdGhpbiBjb21tZW50cy4gTW9yZSBzcGVjaWZpY2FsbHkgaWYgdGhleSBoYXZlXG4gICAgICogQHZhciwgQHBhcmFtIG9yIEByZXR1cm4gcHJlZml4ZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gIHtUZXh0RWRpdG9yfSBlZGl0b3IgVGhlIGVkaXRvciB0byBzZWFyY2ggdGhyb3VnaC5cbiAgICAjIyNcbiAgICByZWdpc3Rlck1hcmtlcnM6IChlZGl0b3IpIC0+XG4gICAgICAgIHRleHQgPSBlZGl0b3IuZ2V0VGV4dCgpXG4gICAgICAgIHJvd3MgPSB0ZXh0LnNwbGl0KCdcXG4nKVxuXG4gICAgICAgIGZvciBrZXkscm93IG9mIHJvd3NcbiAgICAgICAgICAgIHJlZ2V4ID0gL0BwYXJhbXxAdmFyfEByZXR1cm58QHRocm93c3xAc2VlL2dpXG5cbiAgICAgICAgICAgIGlmIHJlZ2V4LnRlc3Qocm93KVxuICAgICAgICAgICAgICAgIEBhZGRNYXJrZXJUb0NvbW1lbnRMaW5lIHJvdy5zcGxpdCgnICcpLCBwYXJzZUludChrZXkpLCBlZGl0b3IsIHRydWVcblxuICAgICMjIypcbiAgICAgKiBSZW1vdmVzIGFueSBtYXJrZXJzIHByZXZpb3VzbHkgY3JlYXRlZCBieSByZWdpc3Rlck1hcmtlcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvciBUaGUgZWRpdG9yIHRvIHNlYXJjaCB0aHJvdWdoXG4gICAgIyMjXG4gICAgY2xlYW5NYXJrZXJzOiAoZWRpdG9yKSAtPlxuICAgICAgICBmb3IgaSxtYXJrZXIgb2YgQGFsbE1hcmtlcnNbZWRpdG9yLmdldExvbmdUaXRsZSgpXVxuICAgICAgICAgICAgbWFya2VyLmRlc3Ryb3koKVxuXG4gICAgICAgIEBhbGxNYXJrZXJzID0gW11cblxuICAgICMjIypcbiAgICAgKiBBbmFseXNlcyB0aGUgd29yZHMgYXJyYXkgZ2l2ZW4gZm9yIGFueSBjbGFzc2VzIGFuZCB0aGVuIGNyZWF0ZXMgYSBtYXJrZXIgZm9yIHRoZW0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge2FycmF5fSB3b3JkcyAgICAgICAgICAgVGhlIGFycmF5IG9mIHdvcmRzIHRvIGNoZWNrLlxuICAgICAqIEBwYXJhbSB7aW50fSByb3dJbmRleCAgICAgICAgICBUaGUgY3VycmVudCByb3cgdGhlIHdvcmRzIGFyZSBvbiB3aXRoaW4gdGhlIGVkaXRvci5cbiAgICAgKiBAcGFyYW0ge1RleHRFZGl0b3J9IGVkaXRvciAgICAgVGhlIGVkaXRvciB0aGUgd29yZHMgYXJlIGZyb20uXG4gICAgICogQHBhcmFtIHtib29sfSBzaG91bGRCcmVhayAgICAgIEZsYWcgdG8gc2F5IHdoZXRoZXIgdGhlIHNlYXJjaCBzaG91bGQgYnJlYWsgYWZ0ZXIgZmluZGluZyAxIGNsYXNzLlxuICAgICAqIEBwYXJhbSB7aW50fSBjdXJyZW50SW5kZXggID0gMCBUaGUgY3VycmVudCBjb2x1bW4gaW5kZXggdGhlIHNlYXJjaCBpcyBvbi5cbiAgICAgKiBAcGFyYW0ge2ludH0gb2Zmc2V0ICAgICAgICA9IDAgQW55IG9mZnNldCB0aGF0IHNob3VsZCBiZSBhcHBsaWVkIHdoZW4gY3JlYXRpbmcgdGhlIG1hcmtlci5cbiAgICAjIyNcbiAgICBhZGRNYXJrZXJUb0NvbW1lbnRMaW5lOiAod29yZHMsIHJvd0luZGV4LCBlZGl0b3IsIHNob3VsZEJyZWFrLCBjdXJyZW50SW5kZXggPSAwLCBvZmZzZXQgPSAwKSAtPlxuICAgICAgICBmb3Iga2V5LHZhbHVlIG9mIHdvcmRzXG4gICAgICAgICAgICByZWdleCA9IC9eXFxcXD8oW0EtWmEtejAtOV9dKylcXFxcPyhbQS1aYS16QS1aX1xcXFxdKik/L2dcbiAgICAgICAgICAgIGtleXdvcmRSZWdleCA9IC9eKGFycmF5fG9iamVjdHxib29sfHN0cmluZ3xzdGF0aWN8bnVsbHxib29sZWFufHZvaWR8aW50fGludGVnZXJ8bWl4ZWR8Y2FsbGFibGUpJC9naVxuXG4gICAgICAgICAgICBpZiB2YWx1ZSAmJiByZWdleC50ZXN0KHZhbHVlKSAmJiBrZXl3b3JkUmVnZXgudGVzdCh2YWx1ZSkgPT0gZmFsc2VcbiAgICAgICAgICAgICAgICBpZiB2YWx1ZS5pbmNsdWRlcygnfCcpXG4gICAgICAgICAgICAgICAgICAgIEBhZGRNYXJrZXJUb0NvbW1lbnRMaW5lIHZhbHVlLnNwbGl0KCd8JyksIHJvd0luZGV4LCBlZGl0b3IsIGZhbHNlLCBjdXJyZW50SW5kZXgsIHBhcnNlSW50KGtleSlcblxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcmFuZ2UgPSBbW3Jvd0luZGV4LCBjdXJyZW50SW5kZXggKyBwYXJzZUludChrZXkpICsgb2Zmc2V0XSwgW3Jvd0luZGV4LCBjdXJyZW50SW5kZXggKyBwYXJzZUludChrZXkpICsgdmFsdWUubGVuZ3RoICsgb2Zmc2V0XV07XG5cbiAgICAgICAgICAgICAgICAgICAgbWFya2VyID0gZWRpdG9yLm1hcmtCdWZmZXJSYW5nZShyYW5nZSlcblxuICAgICAgICAgICAgICAgICAgICBtYXJrZXJQcm9wZXJ0aWVzID1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRlcm06IHZhbHVlXG5cbiAgICAgICAgICAgICAgICAgICAgbWFya2VyLnNldFByb3BlcnRpZXMgbWFya2VyUHJvcGVydGllc1xuXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMgPVxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2hpZ2hsaWdodCdcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnY29tbWVudC1jbGlja2FibGUgY29tbWVudCdcblxuICAgICAgICAgICAgICAgICAgICBpZiAhbWFya2VyLmlzRGVzdHJveWVkKClcbiAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRvci5kZWNvcmF0ZU1hcmtlciBtYXJrZXIsIG9wdGlvbnNcblxuICAgICAgICAgICAgICAgICAgICBpZiBAYWxsTWFya2Vyc1tlZGl0b3IuZ2V0TG9uZ1RpdGxlKCldID09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICAgICAgQGFsbE1hcmtlcnNbZWRpdG9yLmdldExvbmdUaXRsZSgpXSA9IFtdXG5cbiAgICAgICAgICAgICAgICAgICAgQGFsbE1hcmtlcnNbZWRpdG9yLmdldExvbmdUaXRsZSgpXS5wdXNoKG1hcmtlcilcblxuICAgICAgICAgICAgICAgIGlmIHNob3VsZEJyZWFrID09IHRydWVcbiAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgY3VycmVudEluZGV4ICs9IHZhbHVlLmxlbmd0aDtcblxuICAgICMjIypcbiAgICAgKiBHZXRzIHRoZSByZWdleCB1c2VkIHdoZW4gbG9va2luZyBmb3IgYSB3b3JkIHdpdGhpbiB0aGUgZWRpdG9yXG4gICAgICpcbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9IHRlcm0gVGVybSBiZWluZyBzZWFyY2guXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtyZWdleH0gUmVnZXggdG8gYmUgdXNlZC5cbiAgICAjIyNcbiAgICBnZXRKdW1wVG9SZWdleDogKHRlcm0pIC0+XG4gICAgICAgIHJldHVybiAvLy9eKGNsYXNzfGludGVyZmFjZXxhYnN0cmFjdCBjbGFzc3x0cmFpdClcXCArI3t0ZXJtfS8vL2lcbiJdfQ==
